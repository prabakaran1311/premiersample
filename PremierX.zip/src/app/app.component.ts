import {Component, OnInit, HostListener } from "@angular/core";
import {AwsUtil} from "./service/aws.service";
import {UserLoginService} from "./service/user-login.service";
import {CognitoUtil, LoggedInCallback} from "./service/cognito.service";
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  
})
export class AppComponent implements OnInit {
  /*  @HostListener("window:onbeforeunload",["$event"])
    clearLocalStorage(event){
        localStorage.clear();
    }*/

    constructor(public awsUtil: AwsUtil, public userService: UserLoginService, public cognito: CognitoUtil, private translate: TranslateService) {
        translate.addLangs(["en", "fr", "ar"]);
        translate.setDefaultLang("en");

        let browserlang = translate.getBrowserLang();
       // translate.use(browserlang.match(/en|ar/) ? browserlang :"en")
        translate.use("en")
       //console.log("AppComponent: constructor");

        let currentUser = JSON.parse(localStorage.getItem('currentUser'));   
        let userDetails =  JSON.parse(sessionStorage.getItem('currentUser'));  
        if(currentUser != null) {
            if(userDetails === null) {
                sessionStorage.setItem('currentUser',JSON.stringify(currentUser));
            }          
        }
        
    }

    changeLanguage(lang){
        this.translate.use(lang);
    }

    ngOnInit() {
      //  console.log("AppComponent: Checking if the user is already authenticated");
       // this.userService.isAuthenticated(this);
    }

   

    /*isLoggedIn(message: string, isLoggedIn: boolean) {
        console.log("AppComponent: the user is authenticated: " + isLoggedIn);
        let mythis = this;
        this.cognito.getIdToken({
            callback() {

            },
            callbackWithParam(token: any) {
                // Include the passed-in callback here as well so that it's executed downstream
                console.log("AppComponent: calling initAwsService in callback")
                mythis.awsUtil.initAwsService(null, isLoggedIn, token);
            }
        });
    }*/
}