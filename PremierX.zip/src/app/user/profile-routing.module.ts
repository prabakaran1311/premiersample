import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PROFILE_ROUTES } from './components';

const ProfileRoutes: Routes = [...PROFILE_ROUTES];

@NgModule({
  imports: [RouterModule.forChild(ProfileRoutes)],
  exports: [RouterModule]
})
export class ProfileRoutingModule { }
