import { Component, OnInit, NgZone } from '@angular/core';
import { InternationalPhoneModule } from 'ng4-intl-phone';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { EventRegistrationService } from '../../../eventreg/service/eventregistration.service';
import { userProfileService } from '../../service/user.service';
import { FacebookService, InitParams, LoginResponse } from 'ngx-facebook';
import { Router, ActivatedRoute } from "@angular/router";
import {CognitoCallback, LoggedInCallback, CognitoUtil} from "../../../service/cognito.service";
import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { AppSettings } from '../../../core/app-setting';

import { RegistrationService } from '../../../auth/services/registration.service';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';


import 'aws-sdk/dist/aws-sdk';
declare const AWS: any;
import 'amazon-cognito-js';
import { setTimeout } from 'timers';

declare let window: any;

@Component({
  selector: 'app-usersetting',
  templateUrl: './usersetting.component.html',
  styleUrls: ['./usersetting.component.css']
})
export class UsersettingComponent implements OnInit {
  editEmailId: any;
  emails: any;
  languages: any;
  userLanguage: any;
  userFullDetails: any;
  demoChk: any = [];
  eventSubTopic: any;
  subEventType: any;
  eventSubType: any;
  eventTypes: any;
  eventType: any;
  loading: boolean = false;
  active_css: any;
  errorMessage: any = null;
  successMessage: string = null;
  country: any;
  userId: any;
  username : string;
  prefDetails: any = [];
  personalDetails: any = [];
  addressDetails: any = [];
  medicalDetails: any = [];
  eventDetails: any = [];
  communicationDetails:any = [];
  userEmail: string;
  userPassword: string = "*********";
  userLoginStatusFB: boolean = true;
  public actionUrl: string; 
  public headers: Headers;
  public options: RequestOptions;
  fbUserName: string;
  email:string;
  mainEmailChange: boolean = false;
  linkEmailChange: boolean = false;
  cognitoidentityserviceprovider: any;
  accessToken: any;
  changeUserPassword: boolean = false;
  previousPassword: string;
  newPassword: string;
  fbUserCheck: boolean = true;
  fbid: string;
  emailEditLink: any;
  emailEditLinkSet: boolean = false;

  constructor(public router: Router, public eventRegistrationService:EventRegistrationService, public userProfileService:userProfileService, public http: Http,  
     private zone:NgZone, public fb: FacebookService, public registrationService:RegistrationService) { 

      this.actionUrl = AppSettings.API_ENDPOINT;
      this.headers = new Headers({ 'Content-Type': 'application/json' });
      this.options = new RequestOptions({ headers: this.headers });


      AWS.config.update({
        accessKeyId: "AKIAJDPMAZUJXANJEJSQ",
        secretAccessKey: "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",
        region: 'eu-central-1' // change region if required
      });   
  
      this.cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider(); 
      
      fb.init({
          appId: '165158957377830',
          xfbml: true,
          version : 'v2.10'
      });

      (function(d, s, id){
          let js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) {return;}
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/en_US/sdk.js";
          fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    
    let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));    
    if(currentUser != null) {
      this.username = currentUser.username;   
      this.userId = currentUser.userid;
      this.userEmail = currentUser.email;
      this.accessToken = currentUser.jwtToken;
      this.fbid = currentUser.fbid;
    }

    let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
    if(currentUserFB != null) {
      this.username = currentUserFB.username;   
      this.userId = currentUserFB.userid;
      this.userLoginStatusFB = false;
      this.userEmail = currentUserFB.email;
      this.fbUserCheck = false;
      this.fbid = currentUserFB.fbid;
    }    
    this.getCountryList();
    this.getEventType();
    this.getListofLanguages();
    
  }

  ngOnInit() {
    this.getLoginStatus();
    this.getUserAfterLoading();
  }

  editLinkEmail(email,editEmailId){
    this.emailEditLinkSet = true;
    this.emailEditLink = email;
    this.editEmailId = editEmailId;
  }

  editLinkedEmail(){
    this.userProfileService.saveEditLinkEmail(this.editEmailId,this.emailEditLink)
    .subscribe((res)=>{
      if(res.status === 'OK') {
        this.successMessage = 'Email Saved Successfully';
        this.errorMessage = null;
        this.emailEditLink = '';
        this.emailEditLinkSet = false;
        this.getUserDetails();
      } else if(res.status === 'ERROR') {
        this.errorMessage = res.message;
      }
    })
  }

  editMainEmail(){
    this.mainEmailChange = true;
  }

  getUserAfterLoading(){
    let self = this;
    setTimeout(function(){
      self.getUserDetails();
      console.log('function started');
    }, 2000);
  
  }

  getLoginStatus() {
     let self = this;
      this.fb.getLoginStatus()
        .then((res: LoginResponse)=>{
          this.fb.api('/me')
          .then((res: any) => {
            console.log('Got the users profile', res);
            if(this.fbid === res.id) {
              self.fbUserName = res.name;
              console.log('self.fbUserName',self.fbUserName)
              self.userLoginStatusFB = false;
            }
          })
          .catch(this.handleError);
        })
        .catch(console.error.bind(console));
  }

  getCountryList(){
    this.eventRegistrationService.getCountryList()
    .subscribe((res)=> {
      if(res.status === 'OK') {
        this.country = res.data;        
      }
    })
  }

  getGender(gen){
    this.personalDetails.gender = gen.target.value;
  }

  getBlood(blood){
    this.medicalDetails.bloodtype = blood.target.value;
  }

  getEventtype(eventtype){
    this.eventTypes = eventtype.target.value;
    this.prefDetails.eventType = eventtype.target.value;
    this.getEventSubType(this.eventTypes);
  }

  getEventSubtype(eventsubtype){
    let subEventTopic = eventsubtype.target.value;
    this.getEventSubTopic(subEventTopic);
    this.prefDetails.subType = eventsubtype.target.value;
  }

  getNation(nation){
    //console.log('trest', nation.target.value);
    this.personalDetails.nationality = nation.target.value;
    //this.personalDetails.nationality = this.userFullDetails.nationality;
  }

  getCountry(nation){
    //console.log('trest', nation.target.value);
    this.addressDetails.country = nation.target.value;    
    //this.addressDetails.country = this.userFullDetails.countryId;
  }
  getLanguage(lang){
    let language = lang.target.value;    
    this.userProfileService.saveLanguage(lang.target.value)
    .subscribe((res)=>{
      if(res.status === 'OK') {
        this.successMessage = 'Language Saved Successfully';
        this.errorMessage = null;
        this.getUserDetails();
      } else if(res.status === 'ERROR') {
        this.errorMessage = res.message;
      }
    })
  }

  savePersonalData(){
    //console.log('personalDetails',this.personalDetails);
    this.loading = true;
    this.userProfileService.savePersonalDetails(this.personalDetails)
    .subscribe((res)=>{
      this.loading = false;
      if(res.status === 'OK') {
        this.successMessage = 'Your personal details Saved Successfully';
        this.errorMessage = null;
        this.getUserDetails();        
      } else if(res.status === 'ERROR') {
        this.errorMessage = res.message;
      }
    }, (err) => {
      if(err.message === '') {
        this.errorMessage = 'Something happend strange please try again later';
      } else {
        this.errorMessage = err.message;
      }
    })
  }

  saveAddressDetails(){
    this.loading = true;
    console.log('addressDetails',this.addressDetails);
    this.userProfileService.saveAddressDetails(this.addressDetails)
    .subscribe((res)=>{
      this.loading = false;
      if(res.status === 'OK') {
        this.successMessage = 'Address Saved Successfully';
        this.errorMessage = null;
        this.getUserDetails();
      } else if(res.status === 'ERROR') {
        this.errorMessage = res.message;
      }
    }, (err) => {
      if(err.message === '') {
        this.errorMessage = 'Something happend strange please try again later';
      } else {
        this.errorMessage = err.message;
      }
    })
  }

  saveMedicalDetails(){
    this.loading = true;
    //console.log('medicalDetails',this.medicalDetails);    
    this.userProfileService.saveMedicalDetails(this.medicalDetails)
    .subscribe((res)=>{
      this.loading = false;
      if(res.status === 'OK') {
        this.successMessage = 'Medical details are Saved Successfully';
        this.errorMessage = null;
        this.getUserDetails();
      } else if(res.status === 'ERROR') {
        this.errorMessage = res.message;
      }
    }, (err) => {
      if(err.message === '') {
        this.errorMessage = 'Something happend strange please try again later';
      } else {
        this.errorMessage = err.message;
      }
    })
  }

  saveCommunicationDetails(){
    this.loading = true;
   // console.log('communicationDetails',this.communicationDetails);
    this.userProfileService.saveCommunicationDetails(this.communicationDetails)
    .subscribe((res)=>{
      this.loading = false;
      if(res.status === 'OK') {
        this.successMessage = 'Communication details are Saved Successfully';
        this.errorMessage = null;
        this.getUserDetails();
      } else if(res.status === 'ERROR') {
        this.errorMessage = res.message;
      }
    }, (err) => {
      if(err.message === '') {
        this.errorMessage = 'Something happend strange please try again later';
      } else {
        this.errorMessage = err.message;
      }
    })
  }

  savePreferenceDetails(){
    this.loading = true;
    console.log('prefDetails',this.prefDetails);
    this.userProfileService.savePreferenceDetails(this.prefDetails)
    .subscribe((res)=>{
      
      if(res.status === 'OK') {
        this.successMessage = 'Prefereneces details are Saved Successfully';
        this.errorMessage = null;
        this.loading = false;
        this.getUserDetails()
      } else if(res.status === 'ERROR') {
        this.errorMessage = res.message;
        this.loading = false;
      }
    }, (err) => {
      if(err.message === '') {
        this.errorMessage = 'Something happend strange please try again later';
      } else {
        this.errorMessage = err.message;
      }
    })
  }

 

  updateChecked2(value,event){
    if(event.target.checked){
      this.demoChk.push(value);
    }
    else if (!event.target.checked){
      let indexx = this.demoChk.indexOf(value);
      this.demoChk.splice(indexx,1);
    }
    this.demoChk.toString();
    this.prefDetails.eventsubtopic = this.demoChk.toString();
    //console.log(this.prefDetails.eventsubtopic);
  }

  getEventType(){
    this.userProfileService.getEventType()
    .subscribe((res)=>{
      if(res.status === 'OK') {
        this.eventType = res.data;        
      }
    })
  }

  getEventSubType(eventtypeid){
    let self = this;
    this.userProfileService.getEventSubType(eventtypeid)
    .subscribe((res)=>{
      if(res.status === 'OK') {
        this.eventSubType = res.data;       
        setTimeout(function(){
          self.prefDetails.eventSubType = self.userFullDetails.preferenecesType2;
          self.getEventSubTopic(self.prefDetails.eventSubType);
          console.log('startedddddddddddd')
        }, 1000);                         
      }
    })
  }

  getEventSubTopic(eventtypeid){
    this.userProfileService.getEventSubType(eventtypeid)
    .subscribe((res)=>{
      if(res.status === 'OK') {
        this.eventSubTopic = res.data;              
      }
    })
  }

 
  deactivateAccount(){
    this.userProfileService.saveDeactivateAccount()
    .subscribe((res)=>{
      if(res.status === 'OK') {
        this.successMessage = "Your account has been deactivated";              
      } else if(res.status === 'ERROR') { 
        this.errorMessage = res.message;
      }
    })
  }

  linkEmail(){
    this.loading = true;
    console.log('email', this.email);
    this.userProfileService.saveLinkEmail(this.email)
    .subscribe((res)=>{
      this.loading = false;
      if(res.status === 'OK') {
        this.getUserDetails();
        this.email = '';
      } else if(res.status === 'ERROR') { 
        this.errorMessage = res.message;
      }
    })
  }

  getListofLanguages(){
    this.userProfileService.getlanguage()
    .subscribe((res)=>{
      if(res.status === 'OK') {
        this.languages = res.data;              
      }
    })
  }

  getUserDetails(){
    this.userProfileService.getUserFUllDetails()
    .subscribe((res)=>{
      console.log('teststet',res.data)
      this.userFullDetails = res.data;
      this.personalDetails.name = this.userFullDetails.firstName;
      this.personalDetails.lname = this.userFullDetails.lastName ;
      this.personalDetails.dob = this.userFullDetails.dateOfBirth;
      this.prefDetails.eventType = this.userFullDetails.preferenecesType1;
      this.getEventSubType(this.prefDetails.eventType);
      this.personalDetails.gender = this.userFullDetails.gender;
      this.personalDetails.phonenumber = this.userFullDetails.mobile;
      this.addressDetails.villa = this.userFullDetails.addressLine1;
      this.addressDetails.street = this.userFullDetails.addressLine2;
      this.addressDetails.area = this.userFullDetails.addressLine3;      
      this.prefDetails.eventSubTopic = this.userFullDetails.subTopic;
      this.addressDetails.resident = this.userFullDetails.city;
      this.communicationDetails.week = this.userFullDetails.weekAhead;      
      this.communicationDetails.regConf = this.userFullDetails.registrationConfirm;
      this.communicationDetails.fbresult = this.userFullDetails.facebookResults;
      this.medicalDetails.bloodtype = this.userFullDetails.bloodType;
      this.medicalDetails.medicalconditions = this.userFullDetails.medicalCondition;
      this.medicalDetails.allergies = this.userFullDetails.allergies1;
      this.personalDetails.nationality = this.userFullDetails.nationality;  
      this.userLanguage = this.userFullDetails.defaultLanguage;
      this.medicalDetails.allergies1 = this.userFullDetails.allergies2;
      this.medicalDetails.emergencyname = this.userFullDetails.emergencyContactName;
      this.medicalDetails.emergencynumber = this.userFullDetails.emergencyContactNumber;
      this.emails = this.userFullDetails.emailList;
      this.addressDetails.country = this.userFullDetails.countryId;
     // this.prefDetails.eventSubType = this.userFullDetails.preferenecesType2;
     
    })
  }

  // Facebook link Function

  loginWithFacebook(): void {    
      let httpobj = this.http;
      let navobj = this.router;
      let navthis = this;
      this.fb.login()
      .then((res: LoginResponse) => {
      // console.log('Logged in', res);  
        let accessToken = res.authResponse.accessToken;   
        navthis.fb.api('/me', 'get', { access_token: accessToken, fields: 'id,email,name,gender,first_name,last_name' })
        .then((response: any) => {

        //  console.log('Got the users profile', response);
          sessionStorage.setItem('fbAccessToken',accessToken);
        //  console.log(response);
          if (true) {

            //  console.log('You are now logged in.');
              AWS.config.update({
                  region: CognitoUtil._REGION,
                  credentials: new AWS.CognitoIdentityCredentials({
                      IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID,
                      Logins: {
                          'graph.facebook.com': accessToken,                                       
                      },                          
                  })     
              });
            // console.log("accesstoken", accessToken); 
              navthis.zone.run(() => {
                  httpobj.get(navthis.actionUrl+'user/validate/fbid/' + response.id)
                  .map((res:Response) => res.json()) 
                  .catch((err) => { return err; })
                  .subscribe((user) => {
                    this.registrationService.mapUserwithFacebook(response.id, this.userEmail)
                    .subscribe((res)=>{
                        if(res.status.toString() === 'OK') {                               
                          navthis.userLoginStatusFB = false;
                          navthis.getLoginStatus();
                        } else if(res.status.toString() === 'ERROR') { 
                            navthis.errorMessage = res.message;
                        }
                    })                       
                  });  
              });   
          } else {
              //console.log('There was a problem logging you in.');
          }


        })
        .catch(navthis.handleError);      
      })
      .catch(this.handleError);

  }

  //Change current user email id

  UpdateEmailId(){

    let Accesstokenjson = JSON.parse(sessionStorage.getItem('currentUser'));
    let accessToken = Accesstokenjson.jwtToken;
    let email = sessionStorage.getItem('email_id');
    let navobj = this;
    this.loading = true;
   
    let currentDetailsofUser = {
      userid:Accesstokenjson.userid,
      username:Accesstokenjson.username,
      email:navobj.userEmail,
      jwtToken:Accesstokenjson.jwtToken,
      emailVerified:Accesstokenjson.emailVerified,
      fbid:Accesstokenjson.fbid
    }
    
    let userdetail = JSON.parse(sessionStorage.getItem('currentUser'));    
    let UserID = userdetail.userid;
    let oldEmail = userdetail.email;

    let params = {
      AccessToken: accessToken, /* required */
      UserAttributes: [ /* required */
          {
              Name: 'email', /* required */
              Value: navobj.userEmail
          },
          /* more items */
      ]
    };

    let params1 = {
      AccessToken: accessToken, /* required */
      UserAttributes: [ /* required */
          {
              Name: 'email', /* required */
              Value: oldEmail
          },
          /* more items */
      ]
    };

    this.cognitoidentityserviceprovider.updateUserAttributes(params, function(err, data) {
        if (err) { 
          console.log('error',err, err.stack);
          navobj.errorMessage = err;
        } else {         
          navobj.registrationService.ChangeEmailID(UserID, navobj.userEmail )
          .subscribe((res) =>{
           // console.log(res);
            if(res.status.toString() === 'OK'){
              navobj.successMessage = 'Email id changed Successfully';
              navobj.mainEmailChange = false;
              navobj.loading = false;
              sessionStorage.setItem('currentUser',JSON.stringify(currentDetailsofUser));
            } else if(res.status.toString() === 'ERROR') {
              navobj.errorMessage = res.message;
              navobj.cognitoidentityserviceprovider.updateUserAttributes(params1, function(err, data) {
                if (err) { 
                  navobj.errorMessage = err;
                } else { 

                }
              })
            }      
          },
          (err: any) => {  
            navobj.cognitoidentityserviceprovider.updateUserAttributes(params1, function(err, data) {
              if (err) { 
                navobj.errorMessage = err;
              } else { 

              }
            })   
            if(err.message != '') {
              navobj.errorMessage = err.message
            } else {
              navobj.errorMessage = "Something happend Strange... Please Try again";
            }
           // console.log(err);
           navobj.loading = false;
          })                                     
        }
    });       
  }


  //Change current user password

  editChangepassword(){
    this.changeUserPassword = true;
  }

  changePassword(){    
    let self = this; 
    this.loading = true;
    self.errorMessage = null;   
    var params = {
      AccessToken: this.accessToken, /* required */
      PreviousPassword: this.previousPassword, /* required */
      ProposedPassword: this.newPassword /* required */
    };
    
    this.cognitoidentityserviceprovider.changePassword(params, function(err, data) {
      if (err) {
        console.log(err, err.stack); // an error occurred
        self.errorMessage = err;
        self.loading = false;
      } else {     
        console.log(data);   
        self.errorMessage = null;        // successful response
        self.successMessage = 'Password changed successfully';
        self.changeUserPassword = false;
        self.loading = false;
      }
    });

  }

  private handleError(error) {
      console.error('Error processing action', error);
  }

}
