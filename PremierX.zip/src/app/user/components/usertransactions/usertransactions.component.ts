import { Component, OnInit, NgZone } from '@angular/core';
import { InternationalPhoneModule } from 'ng4-intl-phone';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { EventRegistrationService } from '../../../eventreg/service/eventregistration.service';
import { userProfileService } from '../../service/user.service';
import { Router, ActivatedRoute } from "@angular/router";
import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { AppSettings } from '../../../core/app-setting';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';


import 'aws-sdk/dist/aws-sdk';
declare const AWS: any;
import 'amazon-cognito-js';
import { setTimeout } from 'timers';

declare let window: any;

@Component({
  selector: 'app-usertransactions',
  templateUrl: './usertransactions.component.html',
  styleUrls: ['./usertransactions.component.css']
})
export class UsertransactionsComponent implements OnInit {
  errorMessage: any;

  userEmail: any;
  userId: any;
  username: any;
  searchCat: any = [];
  searchResultApi: any;

  constructor(public userProfileService:userProfileService) {
    let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));    
    if(currentUser != null) {
      this.username = currentUser.username;   
      this.userId = currentUser.userid;
      this.userEmail = currentUser.email;
    }
    this.searchCat.catagory = 'All';
    let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
    if(currentUserFB != null) {
      this.username = currentUserFB.username;   
      this.userId = currentUserFB.userid;
      this.userEmail = currentUserFB.email;
    }   
    this.getlistofTransactions();
  }

  ngOnInit() {

  }


  getlistofAllTransactions(e){
    this.searchCat.catagory = e.target.value;
    this.userProfileService.getTransactionList(this.searchCat)
    .subscribe((res)=>{
      if(res.status === 'OK'){
        this.searchResultApi = res.data;
        console.log('this.searchResultApi',this.searchResultApi);
      } else if(res.status === 'ERROR'){
        this.errorMessage = res.message;
      }
    })
  }

  getlistofTransactions(){
    this.userProfileService.getTransactionList(this.searchCat)
    .subscribe((res)=>{
      if(res.status === 'OK'){
        this.searchResultApi = res.data;
        console.log('this.searchResultApi',this.searchResultApi);
      } else if(res.status === 'ERROR'){
        this.errorMessage = res.message;
      }
    })
  }
}
