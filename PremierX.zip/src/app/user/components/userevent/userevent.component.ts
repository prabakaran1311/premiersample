import { Component, OnInit } from '@angular/core';

declare var jQuery: any;
@Component({
  selector: 'app-userevent',
  templateUrl: './userevent.component.html',
  styleUrls: ['./userevent.component.css']
})
export class UsereventComponent implements OnInit {
  event_img: string;

  constructor() {
    this.event_img = 'assets/img/event-bg.jpg';
   }

  ngOnInit() {
    
    jQuery('.owl-demo').owlCarousel({

      loop: false,
      margin: 30,
      nav: true,
      navText: ["<i class='fa fa-chevron-left' aria-hidden='true'></i>", "<i class='fa fa-chevron-right' aria-hidden='true'></i>"],
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2.5
        },
        1000: {
          items: 3.5
        }
      }

    });

  }    

}
