import { UsereventComponent } from './userevent/userevent.component';
import { UsersettingComponent } from './usersetting/usersetting.component';
import { RatingdetailsComponent } from './ratingdetails/ratingdetails.component';
import { UsertransactionsComponent } from './usertransactions/usertransactions.component';


export const PROFILE_COMPONENTS = [ 
  UsereventComponent,
  UsersettingComponent,
  RatingdetailsComponent,
  UsertransactionsComponent
];

export const PROFILE_ROUTES = [ 
  { path: 'userevents', component: UsereventComponent},
  { path: 'profilesetting', component: UsersettingComponent},
  { path: 'ratingdetails', component: RatingdetailsComponent},
  { path: 'transactions', component: UsertransactionsComponent}
];
