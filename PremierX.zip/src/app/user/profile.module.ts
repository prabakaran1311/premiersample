import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { ProfileRoutingModule } from './profile-routing.module';
import { InternationalPhoneModule } from 'ng4-intl-phone';

import { PROFILE_COMPONENTS } from './components';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { RatingdetailsComponent } from './components/ratingdetails/ratingdetails.component';

@NgModule({
  imports: [
    CommonModule,
    ProfileRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BsDatepickerModule,
    InternationalPhoneModule
  ],
  declarations: [
    ...PROFILE_COMPONENTS,
    RatingdetailsComponent
  ]
})
export class ProfileModule { }
