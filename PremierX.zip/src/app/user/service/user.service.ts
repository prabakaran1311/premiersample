import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { Component, OnInit, Injectable } from '@angular/core';
import {Router} from "@angular/router";
import { AppSettings } from './../../core/app-setting';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';


@Injectable()
export class userProfileService { 
    userId: any;
    public actionUrl: string; 
    public headers: Headers;
    public options: RequestOptions;

    constructor(public http:Http, public router:Router) {
        this.actionUrl = AppSettings.API_ENDPOINT;
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
        let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));    
        if(currentUser != null) {
          this.userId = currentUser.userid;
        }
    
        let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
        if(currentUserFB != null) {
          this.userId = currentUserFB.userid;
        } 
    }

    savePersonalDetails(personaldetail){
        let body = ({id:this.userId, firstName:personaldetail.name, lastName: personaldetail.lname, gender: personaldetail.gender, dateOfBirth: personaldetail.dob, nationality:personaldetail.nationality});
        return this.http.put(this.actionUrl+'user/setting/personal', body, this.options)
        .map((response:Response)=> response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    saveAddressDetails(addressdetails){
        let body = ({id:this.userId,addressLine1:addressdetails.villa,addressLine2:addressdetails.street,addressLine3:addressdetails.area,countryId:addressdetails.country,city:addressdetails.resident});
        return this.http.put(this.actionUrl+'user/setting/address', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    savePreferenceDetails(prefDetails){
        let body = ({id:this.userId,preferenecesType1:prefDetails.eventType,preferenecesType2:prefDetails.subType,subTopic:[prefDetails.eventsubtopic]});
        return this.http.put(this.actionUrl+'user/setting/preferences', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    saveCommunicationDetails(comPreference){
        let body = ({id:this.userId,weekAhead:comPreference.week,registrationConfirm:comPreference.regConf,facebookResults:comPreference.fbresult});
        return this.http.put(this.actionUrl+'user/setting/compreferences', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    saveDeactivateAccount(){
        let body = ({id:this.userId});
        return this.http.put(this.actionUrl+'user/setting/deactivate', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    saveLinkEmail(email){
        let body = ({email:email,id:this.userId});
        return this.http.put(this.actionUrl+'user/setting/linkemail', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    saveEditLinkEmail(id, email){
        let body = ({email:email,id:this.userId, emailId: id});
        return this.http.put(this.actionUrl+'user/setting/linkemail', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    saveLanguage(lang){
        let body = ({id:this.userId, defaultLanguage:lang});
        return this.http.put(this.actionUrl+'user/setting/changelanguage', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    saveMedicalDetails(medicaldetails){
        let body = ({id:this.userId,bloodType:medicaldetails.bloodtype,medicalCondition:medicaldetails.medicalconditions,allergies1:medicaldetails.allergies,allergies2:medicaldetails.allergies1,
            emergencyContactName:medicaldetails.emergencyname,emergencyContactNumber:medicaldetails.emergencynumber});
        return this.http.put(this.actionUrl+'user/setting/medicalinfo', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    getEventType(){
        return this.http.get(this.actionUrl+'event/get-type')
        .map((response:Response)=>response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    getEventSubType(eventid){
        return this.http.get(this.actionUrl+'event/get-sub-type/'+eventid)
        .map((response:Response)=>response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    getUserFUllDetails(){
       // let body = ({id:this.userId});
        return this.http.get(this.actionUrl+'user/setting/'+ this.userId)
        .map((response:Response)=>response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    getlanguage(){
        return this.http.get(this.actionUrl+'other/language')
        .map((response:Response)=>response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }

    /* User Transaction Started */

    getTransactionList(transactionList){
        let body = ({id:this.userId,type:transactionList.catagory,search:transactionList.search,sortby:transactionList.sortby,sorttype:transactionList.sorttype});
        return this.http.post(this.actionUrl+'order/list/1', body, this.options)
        .map((response:Response) => response.json())
        .catch((error)=>{
            return Observable.throw(error);
        })
    }
}