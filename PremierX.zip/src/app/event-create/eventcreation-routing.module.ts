import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EVENTCREATION_ROUTES } from './components';

const EventCreationRoutes: Routes = [...EVENTCREATION_ROUTES];

@NgModule({
  imports: [RouterModule.forChild(EventCreationRoutes)],
  exports: [RouterModule]
})
export class EventCreationRoutingModule { }
