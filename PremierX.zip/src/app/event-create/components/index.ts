import { EventInformationComponent } from './event-information/event-information.component';
import { AdditionalInformationComponent } from './additional-information/additional-information.component';

export const EVENTCREATION_COMPONENTS = [  
  EventInformationComponent, 
  AdditionalInformationComponent
];

export const EVENTCREATION_ROUTES = [
  { path: 'eventInformation', component: EventInformationComponent},  
  { path: 'additionalinfo', component: AdditionalInformationComponent},  
];
