import { Component, OnInit } from '@angular/core';
import { CreateEventService } from "../../../service/create-event.service";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from "@angular/router";

import { SharedService } from "../../../service/shared.service";
import * as AWS from 'aws-sdk';

import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

declare var jQuery: any;

@Component({
  selector: 'app-additional-information',
  templateUrl: './additional-information.component.html',
  styleUrls: ['./additional-information.component.css']
})
export class AdditionalInformationComponent implements OnInit {
  sponsorfilename: any;
  sponsorfile: any;
  file: any;
  filename: any;
  extn: any;
  userid: any;
  showcheckbox: any = [];
  checkbox: any = [];
  _form: FormGroup;
  myForm: FormGroup;
  checkpos: any;
  ansinvoiceForm: FormGroup;
  custquesinvoiceForm: FormGroup;
  invoiceForm: FormGroup;
  eventid: any;
  faqques: any = [];
  questionsData: any;
  FaqQuestionsData: any;
  site: any;
  fb: any;
  twitter: any;
  instagram:any;
  youtube: any;
  snapchat: any;
  hash: any;
  venue: any;
  fileEvent: any;
  eveimage: any;
  sponsorfileimage: any = [];

  constructor(public router: Router, public CreateEventService: CreateEventService, private _fb: FormBuilder, private custques: FormBuilder, private ans: FormBuilder, public SharedService : SharedService) { 

  }

  initItemRows() {
    return this._fb.group({
      question: [''],
      answer: ['']
    });
  }

  addNewRow() {
    const control = <FormArray>this.invoiceForm.controls['itemRows'];
    control.push(this.initItemRows());
  }

  deleteRow(index: number) {
    const control = <FormArray>this.invoiceForm.controls['itemRows'];
    control.removeAt(index);
  }

  ngOnInit() {     
    this.SharedService.hide();   
    jQuery('.multiselect').multiselect();
    this.getFaqQuestions();
    this.eventid = sessionStorage.getItem('eventid');

    this.invoiceForm = this._fb.group({
      itemRows: this._fb.array([this.initItemRows()])
    });

    this._form = this._fb.group({
      'questions': this._fb.array([
        this._fb.group({
          'question': [''],
          'helpText': [''],
          'type': [''],
          'isMandatory': [''],
          'allowEditsUntil': [''],
          'answer': this._fb.array([
            this._fb.group({
              'value': ['']
            })
          ])
        })
      ])
    });
  }

  initQuestion() {
    return this._fb.group({
      'question': [''],
      'helpText': [''],
      'type': [''],
      'isMandatory': [''],
      'allowEditsUntil': [''],
      'answer': this._fb.array([
        this._fb.group({
          'value': ['']
        })
      ])
    });
  }

  addQuestion() {
    const control = <FormArray>this._form.controls['questions'];
    control.push(this.initQuestion());
  }
  removeQuestion(i: number) {
    const control = <FormArray>this._form.controls['questions'];
    control.removeAt(i);
  }

  initAnswer() {
    return this._fb.group({
      'value': ['']
    });
  }

  addAnswer(i: number) {
    const control = (<FormArray>this._form.controls['questions']).at(i).get('answer') as FormArray;
    control.push(this.initAnswer());
  }

  removeAnswer(i: number) {
    const control = (<FormArray>this._form.controls['questions']).at(i).get('answer') as FormArray;
    control.removeAt(i);
  }

  
  fileEvents(fileInput: any) {
    var files = fileInput.srcElement.files;

    var file = files[0];
    this.file = file;
    this.filename = this.file.name;
    this.extn = this.file.name.split(".").pop();

    // alert(extn);
    
      this.uploadfile();
    
  }

  
  uploadfile() {
    AWS.config.accessKeyId = 'AKIAJDPMAZUJXANJEJSQ';
    AWS.config.secretAccessKey = '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';
    let bucket = new AWS.S3({ params: { Bucket: 'premierx-temp' } });
    let params = { Bucket: 'premierx-temp', Key: "events/" + this.eventid + "/download-files/" + this.file.name, ACL: 'public-read', Body: this.file };
    let navObj = this;
    bucket.upload(params, function (err, data) {
      if (err) {
        console.log(err);
      } else {
        console.log(data);
        this.eventimage = data.Key;
        //   sessionStorage.setItem('imageurl',this.eventimage);
        navObj.saveeventimage(this.eventimage);
      }
    });
    //   console.log(sessionStorage.getItem('imageurl'));
  }

  
  saveeventimage(image: any) {
    
        let body = JSON.stringify({
          "id": this.eventid,
          "type": "3",
          "images": [{    
            "path": image
          }]
        });
        console.log(body);
        this.CreateEventService.SaveImage(body).subscribe(
          data => {
            // console.log('data-->',data.statusCode);
          },
          error => {
            alert('PLease try again');
          });
      }

  getFaqQuestions() {
    this.CreateEventService.getQuestions().subscribe(ques => {
      this.FaqQuestionsData = ques;
      this.questionsData = this.FaqQuestionsData.data;
      console.log(ques);
    });
  }

  //EVENT CREATE 
  addques(value, event) {
    if (event.target.checked) {
      this.faqques.push(value);
    }
    else if (!event.target.checked) {
      let indexx = this.faqques.indexOf(value);
      this.faqques.splice(indexx, 1);
    }

    console.log(this.faqques);
  }

  mapfaq() {

    let body = JSON.stringify({
      "id": this.eventid,
      "faq": this.faqques
    });

    console.log(body);

    this.CreateEventService.MapFaq(body).subscribe(
      data => {
        // console.log('data-->',data.statusCode);
      },
      error => {
        alert('PLease try again');
      });
  }

  saveaddfaq() {
    var status = document.getElementsByName("status")[0];
    var jsonArr = [];
    let length = this.invoiceForm.value.itemRows.length;

    for (var i = 0; i < length; i++) {
      jsonArr.push({
        question: this.invoiceForm.value.itemRows[i].question,
        answer: this.invoiceForm.value.itemRows[i].answer
      });
    }
    let body = JSON.stringify({
      "id": this.eventid,
      "eventFaq": jsonArr
    });

    console.log(body);

    this.CreateEventService.saveadditionalfaq(body).subscribe(
      data => {
        // console.log('data-->',data.statusCode);
      },
      error => {
        alert('PLease try again');
      });

  }

  savequestions() {

    let length = this._form.value.questions.length;
    console.clear();

    for (let i = 0; i < length; i++) {

      if (this._form.value.questions[i].isMandatory == true) {
        this._form.value.questions[i].isMandatory = "1";
      }
      else if (this._form.value.questions[i].isMandatory == false) {
        this._form.value.questions[i].isMandatory = "0";
      }

      let len = 1;
      for (let j = 0; j < len; j++) {
        if (this._form.value.questions[i].answer[j].value == "" || this._form.value.questions[i].answer[j].value == null) {
          delete this._form.value.questions[i].answer;
        }
      }
    }


    let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
    let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

    if(currentUserFB == null ) {
       this.userid = currentUser.userid;
    }
    else{
      this.userid = currentUserFB.userid;
    }

    let body = JSON.stringify({
      "id": this.eventid,
      "userId":  this.userid,
      "questionAnswer": this._form.value.questions
    });


    console.log(body);

    this.CreateEventService.savequestions(body).subscribe(
      data => {
        // console.log('data-->',data.statusCode);
      },
      error => {
        alert('PLease try again');
      });
  }

  saveadditionaldetails() {

    this.saveaddfaq()
    //   let body = JSON.stringify({
    //     "id": this.eventid,
    //     "faq": this.faqques
    //   });

    // console.log(this._form.value);

    this.savequestions();

    //   this.CreateEventService.MapFaq(body).subscribe(
    //     data => {
    //       // console.log('data-->',data.statusCode);
    //     },
    //     error => {
    //       alert('PLease try again');
    //     });
    // }

  }

  showmodal(i) {
    this.showcheckbox.push(this.showcheckbox.asd = i);

    console.log(this.showcheckbox);
  }






  savesociallink(value, id: any) {

    let body;
    if (value != "" || value != undefined) {
      body = JSON.stringify({
        "id": this.eventid,
        "data":[
          {
            "type": id,
            "url": value
          }]
      });
    }

    console.log(body);

    this.CreateEventService.saveSocialLink(body).subscribe(
      data => {
        // console.log('data-->',data.statusCode);
      },
      error => {
        alert('PLease try again');
      });

  }

  publish(){
    this.saveadditionaldetails();
    let body;    
      body = JSON.stringify({
        "id": this.eventid,
        "status": 5
      });
    
    this.CreateEventService.changeStatus(body).subscribe(
      data => {
        // console.log('data-->',data.statusCode);
        this.router.navigate(['/']);
      },
      error => {
        alert('PLease try again');
      });
  }

  
  saveasdraft(){
    this.saveadditionaldetails();
     let body;    
       body = JSON.stringify({
         "id": this.eventid,
         "status": 6
       }); 
     this.CreateEventService.changeStatus(body).subscribe(
       data => {
         // console.log('data-->',data.statusCode);
         this.router.navigate(['/']);
       },
       error => {
         alert('PLease try again');
       });
  }

  checkcheckbox(val, pos) {
    if (val == 2) {
      this.showmodal(pos);
    }
  }

  requirefiles(){
    
  }

  
  preview(){     
    sessionStorage.setItem('preview','true');
    this.router.navigate(['/events/EventDetails/', this.eventid]);
  }
  
  
sponsorFile(fileInput: any) {
  var sponsorfiles = fileInput.srcElement.files;

  var sponsorfile = sponsorfiles[0];
  this.sponsorfile = sponsorfile;
  this.sponsorfilename = this.sponsorfile.name;
 

  // alert(extn);
  
    this.uploadsponsor();
  
}


uploadsponsor() {
  AWS.config.accessKeyId = 'AKIAJDPMAZUJXANJEJSQ';
  AWS.config.secretAccessKey = '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';
  let bucket = new AWS.S3({ params: { Bucket: 'premierx-temp' } });
  let params = { Bucket: 'premierx-temp', Key: "events/" + this.eventid + "/sponsors/" + this.sponsorfile.name, ACL: 'public-read', Body: this.sponsorfile };
  let navObj = this;
  bucket.upload(params, function (err, data) {
    if (err) {
      console.log(err);
    } else {
      console.log(data);
      //   sessionStorage.setItem('imageurl',this.eventimage);
      let imagelocation = data.Location;
      let key =   data.key;
      navObj.savesponsorimage(imagelocation,key);
    }
  });
}


savesponsorimage(image,key: any) {
  
  this.sponsorfileimage.push(image);
  
  console.log(this.sponsorfileimage);

      let body = JSON.stringify({
        "id": this.eventid,
        "type": "2",
        "images": [{
  
          "path": key
        }]
      });
      console.log(body);
      this.CreateEventService.SaveImage(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }

}

