  import { Component, OnInit, ViewEncapsulation } from '@angular/core';
  import { Router } from '@angular/router';

  import { AgmCoreModule } from '@agm/core';
  import { CreateEventService } from '../../../service/create-event.service';

  import { FormsModule, ReactiveFormsModule } from '@angular/forms';
  import { SharedService } from "../../../service/shared.service";
  import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
  import * as AWS from 'aws-sdk';
  import { setTimeout } from 'timers';


  declare var jQuery: any;
  @Component({
    selector: 'app-event-information',
    templateUrl: './event-information.component.html',
    styleUrls: ['./event-information.component.css']
  })
  export class EventInformationComponent implements OnInit {
    endTimeError: boolean = false;
    endTime: any;
    startTimeminutes: any;
    showNav: boolean = true;
    simpleDrop: any = null;

    closedetails: boolean = false;
    CatDetailsDataJSON: any = [];
    blockDataJSON: any = [];
    reserveDataJSON: any = [];
    CategoryDataJSON: any = [];
    RecuringCount: any;
    ReccurenceData: any;
    ctr: string = "";
    showindividualcat: boolean = false;
    ct: string = "";
    filename: any;
    titleLength: string = "0";
    CatDetails: any;
    errorMsg: any;
    extn: string;
    idInsideGroup: Array<any>;
    recurringDataCloseType: any;
    mymodel: Array<any>;
    showMaxvalError: boolean = false;
    rowItemId: Array<any> = [];
    isEmptyDiv: Boolean = true;
    showcategoryOption: Boolean = false;
    showalert: boolean = false;
    individualGroupCategory: any;
    GroupMaxTicket: any;
    GroupName: any;
    myarr: any = [];
    today: number = Date.now();
    venue: any;
    imageerrormsg: boolean = false;
    latitude: string;
    longitude: string;
    eventimage: any;
    allowmulticategory: boolean = false;
    allowSwitchCategory: boolean = false;
    mailparticipant: boolean = false;
    maxRegistration: any;
    public controls: any;
    city: any;

    public input3Moment: any;
    processfees: boolean = false;
    blocknumber: boolean = false;
    reservenumber: boolean = false;
    fixedmember: boolean = false;
    SwitchTeam: boolean = false;
    TeamCatJson: any = [];
    bibsbyranges: boolean = false;
    bibsdiv: boolean = false;
    bibsstartno: any;
    specdate: boolean = false;
    public TeaminvoiceForm: FormGroup;
    TeamCategoryData: boolean = false;
    public invoiceForm: FormGroup;
    public reserveinvoiceForm: FormGroup;
    public blockinvoiceForm: FormGroup;
    i: any;
    count: any = [];

    startTime: any;
    GroupDiv: boolean = false;
    cancelRegistrationDays: any = 0;
    ContactInformation: any;
    contactInformation: any;
    tieravailjson: any = [];
    tierdatejson: any = [];
    participantsByavail: any;
    newPriceByavail: any;
    tierprice: any = [];
    tierjson: any = [];
    newPrice: any;
    tierdate: any;
    Multitier: string = "0";
    ByDate: boolean = true;
    ByAvailablity: boolean = false;
    recurjson: any = [];
    categoryJson: any = [];
    recuringmodel: any = [];
    CountryCurrency: any;
    showmap: boolean = false;
    othersub: boolean = false;
    othertype: boolean = false;
    EventSubType: any;
    EventType: any;
    catjson: any = [];
    eventid: any;
    langdata: any = [];
    languages: any;
    EventName: any = [];
    Description: any = [];
    Disclaimer: any = "All participants acknowledge and accept the following terms and conditions of participation, registration and payment when registering using the Premier Online    services and when participating in the registered event. \n \n   I, the Premier Online account owner (registrant) and on behalf of anyone I register through my Premier Online account on their behalf (referred to as my others), in    consideration of and as a condition of acceptance of my / their entry in the footrace / cycle race / triathlon / mixed discipline or other as described event for myself,    my others, my heirs, executors and administrators hereby waive any claim, right of claim, cause of any action which I or they might have arising out of loss of my life    or injury, damage or loss of any description whatsoever which I or my others may suffer or sustain in the course or consequent upon my or my others' entry or    participation in the event. \n \n I know that participating in such an event is a potentially hazardous activity. I and my others assume all risks associated with participating in this event, including    but not limited to falls, contact with other participants, the effects of weather, traffic and the conditions of the road / sea / water / trail or other course, all such risks    being known and appreciated by me and my others.   \n \n  This waiver, release and discharge shall be and operate separately in favor of all persons, corporations and bodies involved with or otherwise engaged in promoting    or staging the event and the servants, agents, representatives and officers of any of them.   \n \n  I and my others satisfy all entry requirements as set out.   \n \n  I and my others attest that I am / we are physically fit and medically able to complete part or the entirety of the course without jeopardising my / our health or life    and consent to receive medical treatment that may be advisable in the event of illness or injuries suffered by me / my others during this event.";
    eveimage: any;

    private _form: FormGroup;

    // DatePicker


    langID: any = [];
    previousUrl: any;
    weekly: boolean = false;
    monthly: boolean = false;

    nophysical: boolean = false;
    lat: number = 51.678418;
    lng: number = 7.809007;
    recuring: boolean = false;
    itemmRows: any = [];
    groupSwitch: Boolean = false;

    bibsjson: any = [];

    myfile: any;
    file: any;

    constructor(public router: Router, public CreateEventService: CreateEventService, private _fb: FormBuilder, private teamcat: FormBuilder, public SharedService: SharedService) {

    

      // dragulaService.setOptions('first-bag', {
      //   copy: true
      // });
    }
    private hasClass(el: any, name: string) {
      return new RegExp('(?:^|\\s+)' + name + '(?:\\s+|$)').test(el.className);
    }

    private addClass(el: any, name: string) {
      if (!this.hasClass(el, name)) {
        el.className = el.className ? [el.className, name].join(' ') : name;
      }
    }

    private removeClass(el: any, name: string) {
      if (this.hasClass(el, name)) {
        el.className = el.className.replace(new RegExp('(?:^|\\s+)' + name + '(?:\\s+|$)', 'g'), '');
      }
    }

    private onDrag(args) {
      let [e, el] = args;
      this.removeClass(e, 'ex-moved');
    }
    private getGroupId(eid: any) {
      console.log(this.rowItemId[eid]);
    }
    private onDrop(args) {
      
      let [e, el] = args;
      console.log(e.id);
      console.log(this._form.value.category[e.id].dbId);
        
        this.addClass(e, 'ex-moved');       

        if (this.myarr.length == 0) {
          this.myarr.push(this._form.value.category[e.id].dbId);
        }
        else {
          let positions = this.myarr.indexOf(this._form.value.category[e.id].dbId);
          if (positions == -1) {
            this.myarr.push(this._form.value.category[e.id].dbId);
          }
          else {
            this.delete();
          }
        }
          console.log(this.myarr);
        // let eid = e.id;
        // this.idInsideGroup.push(eid);
        // console.log(this.idInsideGroup);
        // this.getGroupId(eid)
      }
  
    



    private onOver(args) {

      let [e, el, container] = args;
      /* if(this.idInsideGroup.indexOf(el.id)) {
        alert('Already Exists');
      }
      else {
        this.addClass(el, 'ex-over');
      } */
      this.addClass(el, 'ex-over');
    }

    private onOut(args) {
      let [e, el, container] = args;
      this.removeClass(el, 'ex-over');
    }

    delete() {
    // this.dragulaService.find('first-bag').drake.cancel(true);
    }
    initItemRows() {
      return this._fb.group({
        dbId: [''],
        title: [''],
        gender: [''],
        maleCode: [''],
        femaleCode: [''],
        ageMinMale: [''],
        ageMaxMale: [''],
        ageMinFemale: [''],
        ageMaxFemale: [''],
        startTime: [''],
        maxTicket: [''],
        fee: [''],
        tirePrice: [{
          type: [''],
          newPrice: [''],
          date: ['']
        }]
      });
    }


    reserveinitItemRows() {
      return this._fb.group({
        from: [''],
        to: [''],
      });
    }


    blockinitItemRows() {
      return this._fb.group({
        from: [''],
        to: ['']
      });
    }

    recclosetype() {

      this.recurringDataCloseType = $("#closetyperec option:selected").text();
    }

    TeaminitItemRows() {
      return this.teamcat.group({
        title: [''],
        gender: [''],
        maleCode: [''],
        femaleCode: [''],
        ageMinMale: [''],
        ageMaxMale: [''],
        ageMinFemale: [''],
        ageMaxFemale: [''],
        startTime: [''],
        maxTicket: [''],
        fee: [''],
        minMember: [''],
        maxMember: [''],
        tirePrice: [{
          type: [''],
          newPrice: [''],
          date: ['']
        }]
      });
    }

    addNewRow() {
      const control = <FormArray>this.invoiceForm.controls['itemRows'];
      control.push(this.initItemRows());
    }

    deleteRow(index: number) {
      //alert(index)
      const control = <FormArray>this.invoiceForm.controls['itemRows'];
      control.removeAt(index);
    }


    addreserveNewRow() {
      const control = <FormArray>this.reserveinvoiceForm.controls['reserveitemRows'];
      control.push(this.reserveinitItemRows());
    }

    deletereserveRow(index: number) {
      //alert(index)
      const control = <FormArray>this.reserveinvoiceForm.controls['reserveitemRows'];
      control.removeAt(index);
    }


    addblockNewRow() {
      const control = <FormArray>this.blockinvoiceForm.controls['blockitemRows'];
      control.push(this.blockinitItemRows());
    }

    deleteblockRow(index: number) {
      //alert(index)
      const control = <FormArray>this.blockinvoiceForm.controls['blockitemRows'];
      control.removeAt(index);
    }


    teamdeleteRow(index: number) {
      //alert(index)
      const Teamcontrol = <FormArray>this.TeaminvoiceForm.controls['TeamitemRows'];
      Teamcontrol.removeAt(index);
    }


    teamaddNewRow() {
      const Teamcontrol = <FormArray>this.TeaminvoiceForm.controls['TeamitemRows'];
      Teamcontrol.push(this.TeaminitItemRows());
    }

    getip() {
      this.CreateEventService.GetIP().subscribe(lang => {
        let cur = lang;
        console.log('lang', cur);
      });
    }

    ngOnInit() {
      this.SharedService.hide();
      
      this._form = this._fb.group({
        'category': this._fb.array([
          this._fb.group({
            'dbId': [''],
            'title': [''],
            'gender': [''],
            'maleCode': [''],
            'femaleCode': [''],
            'ageMinMale': [''],
            'ageMaxMale': [''],
            'ageMinFemale': [''],
            'ageMaxFemale': [''],
            'startTime': [''],
            'maxTicket': [''],
            'fee': [''],
            'tierPriceByDate': this._fb.array([
              this._fb.group({
                'newPrice': [''],
                'date': ['']
              })
            ]),
            'tierPriceByAvailable': this._fb.array([
              this._fb.group({
                'newPrice': [''],
                'participants': ['']
              })
            ])
          })
        ])
      });


      this.recurjson["dayOfMonth"] = 0;

      this.getip()

      this.invoiceForm = this._fb.group({
        itemRows: this._fb.array([this.initItemRows()])
      });


      this.reserveinvoiceForm = this._fb.group({
        reserveitemRows: this._fb.array([this.reserveinitItemRows()])
      });


      this.blockinvoiceForm = this._fb.group({
        blockitemRows: this._fb.array([this.blockinitItemRows()])
      });

      this.TeaminvoiceForm = this.teamcat.group({
        TeamitemRows: this.teamcat.array([this.TeaminitItemRows()])
      });

      this.eventid = sessionStorage.getItem('eventid');

      if (this.eventid == null || this.eventid == "") {
        this.router.navigate(['/']);
      }
      else {
        this.langID = JSON.parse(sessionStorage.getItem('langID'));

        this.setlang(this.langID);
      }
      this.recuringmodel.id = this.eventid;

      this.geteventtype();

      this.getcountrycourency();

    }


    initCategory() {
      return this._fb.group({
        'dbId': [''],
        'title': [''],
        'gender': [''],
        'maleCode': [''],
        'femaleCode': [''],
        'ageMinMale': [''],
        'ageMaxMale': [''],
        'ageMinFemale': [''],
        'ageMaxFemale': [''],
        'startTime': [''],
        'maxTicket': [''],
        'fee': [''],
        'tierPriceByDate': this._fb.array([
          this._fb.group({
            'newPrice': [''],
            'date': ['']
          })
        ]),
        'tierPriceByAvailable': this._fb.array([
          this._fb.group({
            'newPrice': [''],
            'participants': ['']
          })
        ])
      });
    }

    addCat() {
      const control = <FormArray>this._form.controls['category'];
      control.push(this.initCategory());
    }
    removeCat(i: number) {
      const control = <FormArray>this._form.controls['category'];
      control.removeAt(i);
    }


    initTieByDate() {
      return this._fb.group({
        'newPrice': [''],
        'date': ['']
      });
    }


    initTieByAvailable() {
      return this._fb.group({
        'newPrice': [''],
        'participants': ['']
      });
    }

    addTierByDate(i: number) {
      const control = (<FormArray>this._form.controls['category']).at(i).get('tierPriceByDate') as FormArray;
      control.push(this.initTieByDate());
    }

    removeTierByDate(i: number) {
      const control = (<FormArray>this._form.controls['category']).at(i).get('tierPriceByDate') as FormArray;
      control.removeAt(i);
    }


    addTierByAvailable(i: number) {
      const control = (<FormArray>this._form.controls['category']).at(i).get('tierPriceByAvailable') as FormArray;
      control.push(this.initTieByAvailable());
    }

    removeTierByAvailable(i: number) {
      const control = (<FormArray>this._form.controls['category']).at(i).get('tierPriceByAvailable') as FormArray;
      control.removeAt(i);
    }



    getcountrycourency() {
      this.CreateEventService.Countrycurrency().subscribe(lang => {
        let cur = lang;
        this.CountryCurrency = cur.data;
        console.log('lang', lang);
      });
    }

    geteventtype() {
      this.CreateEventService.getEventType().subscribe(lang => {
        this.EventType = lang.data;
      });
    }

    checkmaxval(val: any) {
      if (parseInt(val) > 30) {
        this.showMaxvalError = true;
        this.cancelRegistrationDays = null;
      }
      else {
        this.showMaxvalError = false;
      }
    }

    checkstring(val: any) {
      val = (val) ? val : window.event;
      var charCode = (val.which) ? val.which : val.keyCode;
      console.clear();
      console.log(charCode);
      if (charCode <= 57 && charCode >= 48 || charCode <= 105 && charCode >= 96 || charCode == 8 || charCode == 46) {
        return true;
      }
      return false;
    }

    physicalstate() {
      let body;
      if (this.nophysical == false) {
        this.nophysical = true;

        body = JSON.stringify({
          "id": this.eventid,
          "hasPhysicalLocation": "0"
        });
      }
      else {
        this.nophysical = false;

        body = JSON.stringify({
          "id": this.eventid,
          "hasPhysicalLocation": "1"
        });
      }
      console.log(body);
      this.CreateEventService.CreateEvent(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }

    recuringevent() {
      let body;

      if (this.recuring == false) {
        this.recuring = true;
        this.recurjson['isRecurring'] = "1";
        this.recurjson["id"] = this.eventid;
        this.recurjson["stopOnWeekends"] = "0";
      }
      else {
        this.recuring = false;
        this.recurjson['isRecurring'] = "0";
      }

    }


    notinWeekends() {
      if (this.recurjson["stopOnWeekends"] == "0") {
        this.recurjson["stopOnWeekends"] = "1";
      }
      else {
        this.recurjson["stopOnWeekends"] = "0";
      }
    }

    tiertype(type: any) {

      if (type == "ByDate") {
        this.ByDate = true;
      }
      else {
        this.ByDate = false;
      }
    }

    savebibsData() {

      let body;

      if (this.bibsjson['requireBibs'] == "1") {

        body = {
          "id": this.eventid,
          "requireBibs": 1,
          "type": parseInt(this.bibsjson['type'])
        };

        if (body['type'] == 1) {
          body['startNumber'] = this.bibsjson['startNumber'];
        }
        else {

          if (this.reserveinvoiceForm.value.reserveitemRows[0] != null || this.reserveinvoiceForm.value.reserveitemRows[0] != "") {
            let reserveRowsLength = this.reserveinvoiceForm.value.reserveitemRows.length;

            for (var i = 0; i < reserveRowsLength; i++) {
              this.reserveDataJSON.push({
                'from': parseInt(this.reserveinvoiceForm.value.reserveitemRows[i].from),
                'to': parseInt(this.reserveinvoiceForm.value.reserveitemRows[i].to)
              });
            }

            body.reserve = this.reserveDataJSON;
          }
          if (this.blockinvoiceForm.value.blockitemRows[0].from != null || this.blockinvoiceForm.value.blockitemRows[0].from != "") {

            let blockRowsLength = this.blockinvoiceForm.value.blockitemRows.length;

            for (var i = 0; i < blockRowsLength; i++) {
              this.blockDataJSON.push({
                'from': parseInt(this.blockinvoiceForm.value.blockitemRows[i].from),
                'to': parseInt(this.blockinvoiceForm.value.blockitemRows[i].to)
              });
            }
            body.block = this.blockDataJSON;
          }

          if (this.CatDetails[0].from != null || this.CatDetails[0].from != "") {

            let catRowsLength = this.CatDetails.length;

            for (var i = 0; i < catRowsLength; i++) {
              this.CatDetailsDataJSON.push({
                'id': parseInt(this.CatDetails[i].id),
                'from': parseInt(this.CatDetails[i].from),
                'to': parseInt(this.CatDetails[i].to)
              });
            }

            body.ranges = this.CatDetailsDataJSON;
          }

        }

        let model = JSON.stringify(body);


        this.CreateEventService.SaveBibs(model).subscribe(
          data => {
            // console.log('data-->',data.statusCode);
          },
          error => {
            alert('PLease try again');
          });

      }
      else {

      }

    }

    SaveandContinue() {
      if (this._form.value.category[0].title == null || this._form.value.category[0].title == "") {
        this.showalert = true;
        this.errorMsg = "Give the Category Details";
        if (this.bibsdiv == false) {
          this.showalert = true;
          this.errorMsg = this.errorMsg + ' and ' + "Bibs Details";
        }
      }
      else {
        if (this.bibsdiv == false) {
          this.showalert = true;
          this.errorMsg = "Give the Bibs Details";
        }
        else {
          this.saveCategoryGroup();
          this.savebibsData();
          this.savedesription(this.Description[0], '0', 'Description');
          this.savedesription(this.Disclaimer, '0', 'Disclaimer');
          this.router.navigate(['/eventcreation/additionalinfo']);
        }
      }

    }

    markerMoved(e) {

      let body = JSON.stringify({
        "id": this.eventid,
        lat: e.coords.lat,
        lng: e.coords.lng
      });

      console.log(body);

      this.CreateEventService.CreateEvent(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }

    everecur(val) {
      let body;
      if (val == "2") {
        this.weekly = true;
        this.monthly = false;

        this.recurjson["recurringTypeId"] = "2";
      }
      else if (val == "3") {
        this.monthly = true;
        this.weekly = false;
        this.recurjson["recurringTypeId"] = "3";
      }
      else if (val == "1") {
        this.weekly = false;
        this.monthly = false;
        this.recurjson["recurringTypeId"] = "1";
      }
      console.log(this.recuringmodel);
    }

    setlang(langid: any) {
      for (let i = 0; i < langid.length; i++) {

        if (langid[i] == 1) {
          this.languages = {
            "langID": langid[i],
            "language": "English"
          }
        }
        else if (langid[i] == 2) {
          this.languages = {
            "langID": langid[i],
            "language": "Arabic"
          }

        }
        this.langdata.push(this.languages)
      }
      console.log(this.langdata);

    }

    showmapdiv() {
      let body;
      if (this.showmap == false) {
        this.showmap = true;
        body = JSON.stringify({
          "id": this.eventid,
          "showOnMap": "1"
        });
      }
      else {
        this.showmap = false;
        body = JSON.stringify({
          "id": this.eventid,
          "showOnMap": "0"
        });
      }
      console.log(body);
      this.CreateEventService.CreateEvent(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }

    saveventtitle(title: any, id: any) {

      let EventTitle = title;
      let LanguageID = id;

      let body = JSON.stringify({
        "id": this.eventid,
        "title": {
          "languages": [{
            "data": EventTitle,
            "id": LanguageID
          }]
        }
      });

      this.CreateEventService.CreateEvent(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }

    getsubtype(e) {

      if (e.target.value == "Others") {
        this.othertype = true;
      }
      else {
        let body = JSON.stringify({
          "id": this.eventid,
          "type": e.target.value
        });

        console.log(body);

        this.CreateEventService.CreateEvent(body).subscribe(
          data => {
            // console.log('data-->',data.statusCode);
          },
          error => {
            alert('PLease try again');
          });

        this.CreateEventService.getEventSubType(e.target.value).subscribe(val => {
          this.EventSubType = val.data;
        });

      }

    }


    saveeventdetails(e) {

      // alert(e.target.value);
      if (e.target.value == "Others") {
        this.othersub = true;
      }
      else {
        let body = JSON.stringify({
          "id": this.eventid,
          "subType": e.target.value
        });

        console.log(body);

        this.CreateEventService.CreateEvent(body).subscribe(
          data => {
            // console.log('data-->',data.statusCode);
          },
          error => {
            alert('PLease try again');
          });
      }

    }


    saveeventtype(value, type: any) {
      let body;

      if (value != "" || value != undefined) {
        body = JSON.stringify({
          "id": this.eventid,
          [type]: value
        });
      }

      if(type == "city"){
        this.savelatlong(value);
      }

      console.log(body);

      this.CreateEventService.CreateEvent(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }

    savelatlong(value){
      this.CreateEventService.getJSONlatlang(value).subscribe(
        data => {
          console.log('data-->', data);
          let datalongitude = data.results[0].geometry.location.lng;
          let datalatitude = data.results[0].geometry.location.lat;
          this.saveeventtype(datalongitude, '');

          let body = JSON.stringify({
            "id": this.eventid,
            lat: datalatitude,
            lng: datalongitude
          });
      
          console.log(body);
      
          this.CreateEventService.CreateEvent(body).subscribe(
            data => {
              // console.log('data-->',data.statusCode);
            },
            error => {
              alert('PLease try again');
            });
        },
        error => {
          alert('PLease try again');
        });
    }


    savedrpdownval(e, type) {
      let body = JSON.stringify({
        "id": this.eventid,
        [type]: e.target.value
      });

      console.log(body);

      this.CreateEventService.CreateEvent(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }

    addreccrval(data, type: any) {
      if (type == "dateOfMonth" || type == "lastEventDate") {
        data = new Date(data).toISOString().slice(0, 10);
      }
      this.recurjson[type] = data;
      console.log(this.recurjson);
    }

    saveRecurringvalue() {
      let body;

      if (this.recurjson["isRecurring"] == "1") {

        body = JSON.stringify({
          "id": this.eventid,
          "isRecurring": 1,
          "recurringTypeId": parseInt(this.recurjson["recurringTypeId"]),
          "dayOfMonth": parseInt(this.recurjson["dayOfMonth"]),
          "dateOfMonth": this.recurjson["dateOfMonth"],
          "dayOfWeek": parseInt(this.recurjson["dayOfWeek"]),
          "stopOnWeekends": parseInt(this.recurjson["stopOnWeekends"]),
          "startTime": this.recurjson["startTime"],
          "endTime": this.recurjson["endTime"],
          "firstEventDate": this.recurjson["firstEventDate"],
          "lastEventDate": this.recurjson["lastEventDate"],
          "recurringCloseCount": parseInt(this.recurjson["recurringCloseCount"]),
          "recurringCloseType": parseInt(this.recurjson["recurringCloseType"]),
          "recurringCloseTime": this.recurjson["recurringCloseTime"],
          "cancelRegistrationDays": parseInt(this.recurjson["cancelRegistrationDays"]),
        }
        );
        console.log(body);

        this.CreateEventService.SaveRecurrance(body).subscribe(
          data => {
            // console.log('data-->',data.statusCode);
            this.getreccurencelist();
          },
          error => {
            alert('PLease try again');
          });
      }
      else {

      }
    }

    getreccurencelist() {
      this.CreateEventService.GetRecurenceData(this.eventid).subscribe(data => {
        this.ReccurenceData = data.data;
        this.RecuringCount = this.ReccurenceData.length;
      });
    }

    ListRecurenceData() {
      this.getreccurencelist();
      jQuery("#recuringmodal").modal("show");

    }

    hasMultiTire(val: any) {
      if (this.Multitier == "0") {

        let ids = '#' + val.toString();
        jQuery(ids).modal("show");

        this.categoryJson['hasMultiTire'] = "1";
      }
      else {
        this.categoryJson['hasMultiTire'] = "0";
      }
      console.log(this.categoryJson);
    }


    addcategoryjson(title: any, id: any) {

      let EventTitle = title;
      let LanguageID = id;

      let body = JSON.stringify({
        "id": this.eventid,
        "title": {
          "languages": [{ [LanguageID]: EventTitle }]
        }
      });
      console.log(body);
    }

    tireval(val: any) {
      if (val == "ByAvailablity") {
        this.ByDate = false;
        this.ByAvailablity = true;
      }
      else {
        this.ByDate = true;
        this.ByAvailablity = false;
      }
    }

    addtierbydate() {
      this.tierdatejson['type'] = "1";
      this.tierdatejson['newPriceByDate'] = this.newPrice;
      this.tierdatejson['tierdate'] = this.tierdate;
      this.tierprice.push(this.tierdatejson);
      console.log(this.tierprice);
    }

    addtierbyavailablity() {
      this.tieravailjson['type'] = "2";
      this.tieravailjson['newPriceByavail'] = this.newPriceByavail;
      this.tieravailjson['participantsByavail'] = this.participantsByavail;
      this.tierprice.push(this.tieravailjson);
      console.log(this.tierprice);
    }

    addcategory() {
      this.count.push("2");
    }

    deleterecurece(id: any) {
      this.CreateEventService.DeleteRecurenceData(id).subscribe(data => {
        this.getreccurencelist();
      });

    }

    groupofindcat() {


      if (this._form.value.category[0].title == null || this._form.value.category[0].title == "") {

      }
      else {
        if (this.GroupDiv == false) {
          this.GroupDiv = true;
        }
        else {
          this.GroupDiv = false;
        }

        if (!this.groupSwitch) {
          if (this.invoiceForm.value.itemRows[0] == "") {

          }
          else {
            
            let itemRowsLength = this._form.value.category.length;


            for (var i = 0; i < itemRowsLength; i++) {
              this.CategoryDataJSON.push({
                'ageMaxFemale': parseInt(this._form.value.category[i].ageMaxFemale),
                'ageMaxMale': parseInt(this._form.value.category[i].ageMaxMale),
                'ageMinFemale': parseInt(this._form.value.category[i].ageMinFemale),
                'ageMinMale': parseInt(this._form.value.category[i].ageMinMale),
                'startTime': new Date(this._form.value.category[i].startTime).toTimeString(),
                'fee': parseInt(this._form.value.category[i].fee),
                'femaleCode': parseInt(this._form.value.category[i].femaleCode),
                'gender': parseInt(this._form.value.category[i].gender),
                'maleCode': parseInt(this._form.value.category[i].maleCode),
                'maxTicket': parseInt(this._form.value.category[i].maxTicket),
                'title': this._form.value.category[i].title,
                'order': 1
              });
            }
            console.clear();
            console.log(this._form.value.category);

            for (var i = 0; i < itemRowsLength; i++) {
            this.CategoryDataJSON[i].tirePrice = [];
              if(this._form.value.category[i].tierPriceByAvailable[0].newPrice == "" || this._form.value.category[i].tierPriceByAvailable[0].participants == ""){

              }
              else{
                this.CategoryDataJSON[i].hasMultiTire = 1;
                for(let j = 0; j < this._form.value.category[i].tierPriceByAvailable.length; j ++){
                  this.CategoryDataJSON[i].tirePrice.push({                  
                      'type': 2,
                      'newPrice': this._form.value.category[i].tierPriceByAvailable[j].newPrice,
                      'participants': this._form.value.category[i].tierPriceByAvailable[j].participants                 
                  })
                }
              }

              if(this._form.value.category[i].tierPriceByDate[0].newPrice == "" || this._form.value.category[i].tierPriceByDate[0].date == ""){

              }
              else{ 
                
                this.CategoryDataJSON[i].hasMultiTire = 1;

                for(let j = 0; j < this._form.value.category[i].tierPriceByDate.length; j ++){
                  this.CategoryDataJSON[i].tirePrice.push({                 
                      'type': 1,
                      'newPrice': this._form.value.category[i].tierPriceByDate[j].newPrice,
                      'date': this._form.value.category[i].tierPriceByDate[j].date                  
                  })
                }
              }
            }

            console.log('asdfasdfasdfasdf',this.CategoryDataJSON);

            let uid = Math.floor(Math.random() * 999999) + 100000;
            console.log(uid);
            let body = JSON.stringify({
              'id': this.eventid,
              'allowIndividualRegistration': 1,
              'category': this.CategoryDataJSON
            });
            console.log(body);
            this.CreateEventService.SaveCategory(body).subscribe(
              res => {
                let itemId = res.data;
                let reslength = res.data.length;
                for (let j = 0; j < reslength; j++) {
                  this.rowItemId.push(res.data[j].id);
                  this._form.value.category[j].dbId = res.data[j].id;
                }
                // this.rowItemId.push(itemId);
                //this.invoiceForm.value.itemRows[i].dbId = this.rowItemId;
                //   alert(this.invoiceForm.value.itemRows[i].dbId)
                this.showcategoryOption = true;
                console.log(this.rowItemId);
              },
              error => {
                alert('PLease try again');
              }
            );
            this.groupSwitch = true;
            setInterval(1000);
          }
        }
      }
      /* let body = JSON.stringify({
        'id': this.eventid,fsave bibs
        'allowIndividualRegistration': '1',
        'category': [
          {
            'ageMaxFemale': this.invoiceForm.value.itemRows[0].ageMaxFemale,
            'ageMaxMale': this.invoiceForm.value.itemRows[0].ageMaxMale,
            'ageMinFemale': this.invoiceForm.value.itemRows[0].ageMinFemale,
            'ageMinMale': this.invoiceForm.value.itemRows[0].ageMinMale,
            'catstartTime': this.invoiceForm.value.itemRows[0].catstartTime,
            'fee': this.invoiceForm.value.itemRows[0].fee,
            'femaleCode': this.invoiceForm.value.itemRows[0].femaleCode,
            'gender': this.invoiceForm.value.itemRows[0].gender,
            'maleCode': this.invoiceForm.value.itemRows[0].maleCode,
            'maxTicket': this.invoiceForm.value.itemRows[0].maxTicket,
            'title': this.invoiceForm.value.itemRows[0].title,
            'hasMultiTire': '0',
            'order': '1'
          }]
      });

      console.log(body);
      this.CreateEventService.SaveCategory(body).subscribe(
        data => {
          console.log('data-->', data);
        },
        error => {
          alert('PLease try again');
        }
      ); */
    }

    TeamCategory() {
      if (this.TeamCategoryData == false) {
        this.TeamCategoryData = true;
        this.TeamCatJson['id'] = this.eventid;
        this.TeamCatJson['allowTeamRegistration'] = "1";
      }
      else {
        this.TeamCategoryData = false;
      }

    }

    calage(data, key: any) {
      this.saveeventtype(data, key);
      if (data == "2") {
        this.specdate = true;
      }
      else {
        this.specdate = false
      }
    }

    bibsrequires() {
      if (this.bibsdiv == false) {

        this.bibsdiv = true;
        this.bibsjson['id'] = this.eventid;
        this.bibsjson['requireBibs'] = "1";

      }
      else {
        this.bibsdiv = false;
        this.bibsjson['requireBibs'] = "0";
      }
    }

    bibsdataadd(data, key: any) {
      this.bibsjson[key] = data;

      if (key == "startNumber") {
        this.bibsjson['type'] = 1;
      }

      if (key == "type") {
        if (data == "2") {
          this.bibsbyranges = true;
          this.getCategory();
          delete this.bibsjson['startNumber'];
          console.log(this.bibsjson);
        }
        else {
          this.bibsbyranges = false;
        }
      }

      console.log(this.bibsjson);
    }



    getCategory() {
      this.CreateEventService.GetCategoryData(this.eventid).subscribe(data => {
        this.CatDetails = data.data;
      });
    }

    switchteam() {
      if (this.SwitchTeam == false) {
        this.TeamCatJson['allowSwitchTeam'] = "1";
      }
      else {
        this.TeamCatJson['allowSwitchTeam'] = "0";
      }
    }

    switchdate(data, key: any) {
      this.TeamCatJson[key] = data;
      console.log(this.TeamCatJson);
    }

    saveTeamCategorydata() {
      console.log(this.TeaminvoiceForm.value);
      let body = JSON.stringify({
        "id": this.eventid,
        "allowTeamRegistration": "1",
        "allowSwitchTeam": this.TeamCatJson['allowSwitchTeam'],
        "swtichTeamExpiryDate": this.TeamCatJson['swtichTeamExpiryDate'],
        "category": [
          {
            "ageMaxFemale": this.TeaminvoiceForm.value.TeamitemRows[0].ageMaxFemale,
            "ageMaxMale": this.TeaminvoiceForm.value.TeamitemRows[0].ageMaxMale,
            "ageMinFemale": this.TeaminvoiceForm.value.TeamitemRows[0].ageMinFemale,
            "ageMinMale": this.TeaminvoiceForm.value.TeamitemRows[0].ageMinMale,
            "catstartTime": this.TeaminvoiceForm.value.TeamitemRows[0].catstartTime,
            "fee": this.TeaminvoiceForm.value.TeamitemRows[0].fee,
            "femaleCode": this.TeaminvoiceForm.value.TeamitemRows[0].femaleCode,
            "gender": this.TeaminvoiceForm.value.TeamitemRows[0].gender,
            "maleCode": this.TeaminvoiceForm.value.TeamitemRows[0].maleCode,
            "maxTicket": this.TeaminvoiceForm.value.TeamitemRows[0].maxTicket,
            "title": this.TeaminvoiceForm.value.TeamitemRows[0].title,
            "hasMultiTire": "0",
            "tirePrice": this.TeaminvoiceForm.value.TeamitemRows[0].tirePrice
          }]
      });

      // console.log(body);
      // this.CreateEventService.SaveTeamCategory(body).subscribe(
      //   data => {
      //     console.log('data-->', data);
      //   },
      //   error => {
      //     alert('PLease try again');
      //   });
    }

    noofmember() {
      if (this.fixedmember == true) {
        this.fixedmember = false;
      }
      else {
        this.fixedmember = true;
      }
    }

    reservenorange() {
      if (this.reservenumber == false) {
        this.reservenumber = true;
      }
      else {
        this.reservenumber = false;
      }
    }


    blocknorange() {
      if (this.blocknumber == false) {
        this.blocknumber = true;
      }
      else {
        this.blocknumber = false;
      }
    }

    ProcessingFee() {
      if (this.processfees == false) {
        this.processfees = true;
        this.saveeventtype("1", "absorbProcessingFee");
      } else {
        this.processfees = false;
        this.saveeventtype("0", "absorbProcessingFee");
      }
    }

    emailParticipant() {
      if (this.mailparticipant == false) {
        this.mailparticipant = true;
        this.saveeventtype("1", "emailParticipant");
      } else {
        this.mailparticipant = false;
        this.saveeventtype("0", "emailParticipant");
      }
    }

    switchcategory() {
      if (this.allowSwitchCategory == false) {
        this.allowSwitchCategory = true;
        this.saveeventtype("1", "allowSwitchCategory");
      } else {
        this.allowSwitchCategory = false;
        this.saveeventtype("0", "allowSwitchCategory");
      }
    }

    multicategory() {
      if (this.allowmulticategory == false) {
        this.allowmulticategory = true;
        this.saveeventtype("1", "allowMultipleCategoryRegistration");
      } else {
        this.allowmulticategory = false;
        this.saveeventtype("0", "allowMultipleCategoryRegistration");
      }
    }

    uploadfile() {
      AWS.config.accessKeyId = 'AKIAJDPMAZUJXANJEJSQ';
      AWS.config.secretAccessKey = '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';
      let bucket = new AWS.S3({ params: { Bucket: 'premierx-temp' } });
      let params = { Bucket: 'premierx-temp', Key: "events/" + this.eventid + "/images/" + this.file.name, ACL: 'public-read', Body: this.file };
      let navObj = this;
      bucket.upload(params, function (err, data) {
        if (err) {
          console.log(err);
        } else {
          console.log(data);
          this.eventimage = data.Key;
          //   sessionStorage.setItem('imageurl',this.eventimage);
          navObj.saveeventimage(this.eventimage);
        }
      });
      //   console.log(sessionStorage.getItem('imageurl'));
    }

    fileEvent(fileInput: any) {
      var files = fileInput.srcElement.files;

      var file = files[0];
      this.file = file;
      this.filename = this.file.name;
      this.extn = this.file.name.split(".").pop();

      // alert(extn);
      if (this.extn == "jpg" || this.extn == "png" || this.extn == "Jpeg" || this.extn == "gif") {
        this.uploadfile();
        this.imageerrormsg = false;
      }
      else {
        this.imageerrormsg = true;
      }
    }

    saveeventimage(image: any) {

      let body = JSON.stringify({
        "id": this.eventid,
        "type": "1",
        "images": [{

          "path": image
        }]
      });
      console.log(body);
      this.CreateEventService.SaveImage(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }


    getlatlong(venue, e, city: any) {

      let address = venue + ", " + city + "," + $("#country option:selected").text();

      console.log(address);
      this.CreateEventService.getJSONlatlang(address).subscribe(
        data => {
          console.log('data-->', data);
          this.longitude = data.results[0].geometry.location.lng;
          this.latitude = data.results[0].geometry.location.lat;
        },
        error => {
          alert('PLease try again');
        });

      // $.getJSON("https://maps.googleapis.com/maps/api/geocode/json?address="+encodeURIComponent(city), function(val) {
      //   if(val.results.length) {
      //     var location = val.results[0].geometry.location
      //     $("#lat").val(location.lat)
      //     $("#lon").val(location.lng)
      //   }
      // })


    }



    saveeventDate(val, type: any) {

      jQuery('#date').bind("cut copy paste", function (e) {
        e.preventDefault();
      });

      let date = new Date(val).toISOString().slice(0, 10);

      let body;
      if (date != "" || date != undefined) {
        body = JSON.stringify({
          "id": this.eventid,
          [type]: date
        });

        console.log(body);

        this.CreateEventService.CreateEvent(body).subscribe(
          data => {
            // console.log('data-->',data.statusCode);
          },
          error => {
            alert('PLease try again');
          });

      }

      //end
    }

    count_title() {
      this.titleLength = this.EventName[0].length;
    }



    savedesription(desc: any, id: any, type) {

      let descri = desc;
      let LanguageID = id;

      let body = JSON.stringify({
        "id": this.eventid,
        [type]: {
          "languages": [{ [LanguageID]: descri }]
        }
      });

      this.CreateEventService.CreateEvent(body).subscribe(
        data => {
          console.log('data-->', data);
        },
        error => {
          alert('PLease try again');
        });
    }

    saveCategoryGroup() {
      let body = JSON.stringify({
        "id": this.eventid,
        "allowGroupRegistration": "1",
        "categoryId" : this.myarr,
        "name": this.GroupName,
        "maxTicket": this.GroupMaxTicket
      });
      console.log(body);
      this.CreateEventService.SaveGroupCategory(body).subscribe(
        data => {
          // console.log('data-->',data.statusCode);
        },
        error => {
          alert('PLease try again');
        });
    }

    savebibs() {
      console.clear();
      console.log(this.bibsjson);
      let ps = "to" in this.CatDetails;
      alert(ps);
    }

    savetime(e, type: any) {

      let va = new Date(e);

      let hours = va.getHours().toString();
      let minutes = va.getMinutes().toString();
      let time = hours + ':' + minutes;
      this.saveeventtype(time, type);

      if (type == "closeTime") {
        this.ct = time;
        this.closedetails = true;
      }

      else if(type == "startTime"){
        console.log(hours, parseInt(hours));
        this.startTimeminutes = parseInt(hours)*60 + parseInt(minutes);
      }

    }


    saverectime(e, type: any) {

      let va = new Date(e);

      let hours = va.getHours().toString();
      let minutes = va.getMinutes().toString();
      let time = hours + ':' + minutes;

      this.addreccrval(time, type);
      if (type = "closeTime") {
        this.ctr = time;
      }

    }

    individualcat() {
      if (this.showindividualcat == false) {
        this.showindividualcat = true;
      }
      else {
        this.showindividualcat = false;
      }
    }

    preview() {
      sessionStorage.setItem('preview', 'true');
      this.router.navigate(['/events/EventDetails/', this.eventid]);
    }

    checkmin(e){
      let va = new Date(e);
      
      let hours = va.getHours();
      let minutes = va.getMinutes();
      let time = hours + ':' + minutes;

      minutes+=hours*60;

      console.log(this.startTimeminutes);
      console.log(minutes);

      if(this.startTimeminutes > minutes +1){
        this.endTimeError = true;
      }
      else{
        this.endTimeError = false;
      }
    }



  }

  class Widget {
    constructor(public name: string) {}
  }