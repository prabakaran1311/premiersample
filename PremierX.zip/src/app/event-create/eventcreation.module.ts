import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DragulaModule } from 'ng2-dragula';
import { DragulaService  } from 'ng2-dragula';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AgmCoreModule } from '@agm/core';
import { EventCreationRoutingModule } from './eventcreation-routing.module';

import { FroalaEditorModule, FroalaViewModule } from 'angular-froala-wysiwyg';

import { EVENTCREATION_COMPONENTS } from './components';


import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { NKDatetimeModule } from 'ng2-datetime/ng2-datetime';
import { Ng2DragDropModule } from 'ng2-drag-drop';


@NgModule({
  imports: [
    CommonModule,
    EventCreationRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AgmCoreModule,
    FroalaEditorModule.forRoot(), 
    FroalaViewModule.forRoot(),
    NKDatetimeModule,
    BsDatepickerModule.forRoot(),
    DragulaModule,    
    Ng2DragDropModule.forRoot()
  ],
  declarations: [
    ...EVENTCREATION_COMPONENTS
  ]
})
export class EventCreationModule { }
 