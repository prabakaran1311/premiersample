import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EVENTCREATIONTICKET_ROUTES } from './components';

const EventCreationTicketRoutes: Routes = [...EVENTCREATIONTICKET_ROUTES];

@NgModule({
  imports: [RouterModule.forChild(EventCreationTicketRoutes)],
  exports: [RouterModule]
})
export class EventCreationTicketRoutingModule { }
