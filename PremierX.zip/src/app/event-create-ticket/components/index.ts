import { EventCreateTicketComponent } from './event-create-ticket/event-create-ticket.component';

export const EVENTCREATIONTICKET_COMPONENTS = [  
  EventCreateTicketComponent, 
];

export const EVENTCREATIONTICKET_ROUTES = [
  { path: 'eventcreateTicket', component: EventCreateTicketComponent}
];
