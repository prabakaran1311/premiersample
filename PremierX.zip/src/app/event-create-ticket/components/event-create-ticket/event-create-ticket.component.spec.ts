import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventCreateTicketComponent } from './event-create-ticket.component';

describe('EventCreateTicketComponent', () => {
  let component: EventCreateTicketComponent;
  let fixture: ComponentFixture<EventCreateTicketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventCreateTicketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventCreateTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
