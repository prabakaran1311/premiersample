import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-create-ticket',
  templateUrl: './event-create-ticket.component.html',
  styleUrls: ['./event-create-ticket.component.css']
})
export class EventCreateTicketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
