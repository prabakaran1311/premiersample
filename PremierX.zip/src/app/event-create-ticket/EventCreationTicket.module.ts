import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { EventCreationTicketRoutingModule } from './EventCreationTicketRouting.module';


import { EVENTCREATIONTICKET_COMPONENTS } from './components';


@NgModule({
  imports: [
    CommonModule,
    EventCreationTicketRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    ...EVENTCREATIONTICKET_COMPONENTS
  ]
})
export class EventCreationTicketModule { }
 