import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { Http, HttpModule,JsonpModule } from '@angular/http';
import { TranslateModule, TranslateLoader,  MissingTranslationHandler, MissingTranslationHandlerParams } from '@ngx-translate/core';
import { ShTimeoutModule } from "ng2-timeout-dialog";
import { FacebookModule } from 'ngx-facebook';
import { InternationalPhoneModule } from 'ng4-intl-phone';
import { ShareButtonsModule } from 'ngx-sharebuttons';

import { Ng2DragDropModule } from 'ng2-drag-drop';

//import { AgmCoreModule } from '@agm/core';
//import { LazyLoadImagesModule } from 'ngx-lazy-load-images';

// import { Md2Module }  from 'md2';
// import {nvD3} from 'ng2-nvd3';

const MODULE_COLLECTION = [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    JsonpModule,
    ShTimeoutModule,
    InternationalPhoneModule,
    
    //AgmCoreModule
   // LazyLoadImagesModule
    // Md2Module,
    // nvD3
]

@NgModule({
  imports: [
    ...MODULE_COLLECTION,
    FacebookModule.forRoot(),
    ShareButtonsModule.forRoot(),
    Ng2DragDropModule.forRoot()
    
  ],
  declarations: [],
  exports: [
    ...MODULE_COLLECTION
  ]
})
export class SharedModule { }
