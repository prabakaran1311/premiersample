import {Inject, Injectable} from "@angular/core";
import {CognitoCallback, CognitoUtil, CognitoCallbackConfirm} from "./cognito.service";
import {AuthenticationDetails, CognitoUser, CognitoUserAttribute} from "amazon-cognito-identity-js";
import { RegistrationUser } from "../auth/components/register/register.component";
import {NewPasswordUser} from "../auth/components/newpassword/newpassword.component";
import {Router} from "@angular/router";
import {environment} from "../../environments/environment";
import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { SharedService } from '../service/shared.service';
import { Observable } from 'rxjs/Observable'; 
import { AppSettings } from './../core/app-setting';

import 'rxjs/add/operator/map'; 
import 'rxjs/add/operator/do'; 
import 'rxjs/add/operator/catch';

import * as AWS from "aws-sdk";
//import * as AWSS from "aws-sdk";

declare var sessionStorage : any;
declare var localStorage : any;

@Injectable()
export class UserRegistrationService {

    public actionUrl: string; 
    public headers: Headers;
    public options: RequestOptions;

    constructor(@Inject(CognitoUtil) public cognitoUtil: CognitoUtil, private router: Router, public http:Http, private sharedService: SharedService) {
        this.actionUrl = AppSettings.API_ENDPOINT;
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
    }

   register(user: RegistrationUser, callback: CognitoCallbackConfirm): void {
      //  console.log("UserRegistrationService: user is " + user);

        let attributeList = [];
     
        let httpobj = this.http;

        AWS.config.update({
            accessKeyId: "AKIAJDPMAZUJXANJEJSQ",
            secretAccessKey: "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",
            region: 'eu-central-1' // change region if required
        });          
       
        let cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();
      
        let params = {
            UserPoolId: environment.userPoolId, /* required */
            Username: user.email /* required */
        };
        let httpobje = this;
        this.cognitoUtil.getUserPool().signUp(user.email, user.password, attributeList, null, function (err, result) {
            if (err) {
                callback.CognitoCallbackConfirm(err.message, null);
            } else {
               // console.log("UserRegistrationService1: registered user is " + result);    
                cognitoidentityserviceprovider.adminGetUser(params, function(err, data) {
                    if (err) {
                        cognitoidentityserviceprovider.adminDeleteUser(params, function(err, data) {
                            if (err) {
                                console.log("catch block",err, err.stack); // an error occurred
                            }else {
                                callback.CognitoCallbackConfirm('Network issue Please Try again Later', 'Network issue Please Tru again Later');
                               // console.log("cache block success",data); // successful response
                            }
                        });
                        console.log(err, err.stack);    // an error occurred
                    } else{     
                       // console.log('getuserdetails',data.UserAttributes[0].Value);// successful response
                        let body = JSON.stringify({ registerType: 'normal' , action: 'signup',sub: data.UserAttributes[0].Value,
                                    firstName: user.name,lastName: user.lname, email: user.email,mobile: user.phonenumber});
                      
                       // console.log(body);
                        httpobj.post( httpobje.actionUrl+'user', body, httpobje.options )
                        .map((response: Response) => response.json())
                        .subscribe((res) =>{
                            if(res.status === 'OK'){
                           // httpobje.sharedService.IsUserLoggedIn.next(true);
                                callback.CognitoCallbackConfirm(null, result);
                            } else if(res.status === 'ERROR'){
                                cognitoidentityserviceprovider.adminDeleteUser(params, function(err, data) {
                                    if (err) {
                                        console.log("catch block",err, err.stack); // an error occurred
                                    }else {
                                        callback.CognitoCallbackConfirm('Network issue Please Try again Later', 'Network issue Please Tru again Later');
                                       // console.log("cache block success",data); // successful response
                                    }
                                });
                            }             
                            
                        });
                        
                    }
                });                        
                
            }
        });    

    }

    
    confirmRegistration(username: string, confirmationCode: string, callback: CognitoCallbackConfirm): void {

        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };

        let cognitoUser = new CognitoUser(userData);

        cognitoUser.confirmRegistration(confirmationCode, true, function (err, result) {
            if (err) {
                callback.CognitoCallbackConfirm(err.message, null);
            } else {
                callback.CognitoCallbackConfirm(null, result);
            }
        });
    }

    resendCode(username: string, callback: CognitoCallback): void {
        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };

        let cognitoUser = new CognitoUser(userData);

        cognitoUser.resendConfirmationCode(function (err, result) {
            if (err) {
                callback.cognitoCallback(err.message, null);
            } else {
                callback.cognitoCallback(null, result);
            }
        });
    }

    newPassword(newPasswordUser: NewPasswordUser, callback: CognitoCallback): void {
       // console.log(newPasswordUser);
        // Get these details and call
        //cognitoUser.completeNewPasswordChallenge(newPassword, userAttributes, this);
        let authenticationData = {
            Username: newPasswordUser.username,
            Password: newPasswordUser.existingPassword,
        };
        let authenticationDetails = new AuthenticationDetails(authenticationData);

        let userData = {
            Username: newPasswordUser.username,
            Pool: this.cognitoUtil.getUserPool()
        };

       // console.log("UserLoginService: Params set...Authenticating the user");
        let cognitoUser = new CognitoUser(userData);
       // console.log("UserLoginService: config is " + AWS.config);
        cognitoUser.authenticateUser(authenticationDetails, {
            newPasswordRequired: function (userAttributes, requiredAttributes) {
                // User was signed up by an admin and must provide new
                // password and required attributes, if any, to complete
                // authentication.

                // the api doesn't accept this field back
                delete userAttributes.email_verified;
                cognitoUser.completeNewPasswordChallenge(newPasswordUser.password, requiredAttributes, {
                    onSuccess: function (result) {
                        callback.cognitoCallback(null, userAttributes);
                    },
                    onFailure: function (err) {
                        callback.cognitoCallback(err, null);
                    }
                });
            },
            onSuccess: function (result) {
                callback.cognitoCallback(null, result);
            },
            onFailure: function (err) {
                callback.cognitoCallback(err, null);
            }
        });
    } 

  /*  updateUserProfile(username: string, registerProfile: RegisterProfile, callback: CognitoCallback): void {
        
        let cognitoUser = this.cognitoUtil.getCurrentUser();

        if (cognitoUser != null) {
            cognitoUser.getSession(function (err, session) {
                if (err)
                    console.log("UserParametersService: Couldn't retrieve the user");
                else {                              
                }    
            });
        } else {
          
        }
    
        console.log('service username',username);
        let userData = {
            Username: username,
            Pool: this.cognitoUtil.getUserPool()
        };
       

        let attributeList = [];
        let dob = {
            Name : 'birthdate',
            Value : registerProfile.dob
        };  
        let bloodtype = {
            Name : 'custom:bloodtype',
            Value : registerProfile.bloodtype
        }; 
        let allergies = {
            Name : 'custom:allergies',
            Value : registerProfile.allergies
        }; 
        let medicalcondition = {
            Name : 'custom:medicalcondition',
            Value : registerProfile.medicalcondition
        }; 
        let nationality = {
            Name : 'custom:nationality',
            Value : registerProfile.nationality
        }; 
        let country = {
            Name : 'custom:country',
            Value : registerProfile.country
        }; 
        let cityofresidence = {
            Name : 'custom:city',
            Value : registerProfile.cityofresidence
        }; 
        let address = {
            Name : 'address',
            Value : registerProfile.address
        }; 
        let language = {
            Name : 'custom:languagepreference',
            Value : registerProfile.language
        };   
        let emergencycontactnumber = {
            Name : 'custom:emergencynumber',
            Value : registerProfile.emergencycontactnumber
        };  
        let emergencycontactname = {
            Name : 'custom:emergencycontact',
            Value : registerProfile.emergencycontactname
        };  
       /* let eventtype = {
            Name : 'custom:preferedeventtype',
            Value : registerProfile.eventtype
        };  
        let eventtopic = {
            Name : 'custom:preferedtopic',
            Value : registerProfile.eventtopic
        };  
        let subtopics = {
            Name : 'custom:preferedsubtopic',
            Value : registerProfile.subtopics
        };     * / 
        
        attributeList.push(new CognitoUserAttribute(dob));    
        attributeList.push(new CognitoUserAttribute(bloodtype)); 
        attributeList.push(new CognitoUserAttribute(allergies)); 
        attributeList.push(new CognitoUserAttribute(medicalcondition)); 
        attributeList.push(new CognitoUserAttribute(nationality)); 
        attributeList.push(new CognitoUserAttribute(country)); 
        attributeList.push(new CognitoUserAttribute(cityofresidence)); 
        attributeList.push(new CognitoUserAttribute(address)); 
        attributeList.push(new CognitoUserAttribute(language)); 
        attributeList.push(new CognitoUserAttribute(emergencycontactnumber)); 
        attributeList.push(new CognitoUserAttribute(emergencycontactname)); 
        console.log('attrib',attributeList);
    
        cognitoUser.updateAttributes(attributeList, function(err, result) {
            if (err) {
                alert(err);
                return;
            }
            console.log('call result: ' + result);
           // this.router.navigate(['/securehome']);
        });

       
    }*/

    private handleError(error: Response) { 
        console.error(error); 
        return Observable.throw(error.json().error()); 
     } 
    
}