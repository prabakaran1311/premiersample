import { Injectable } from '@angular/core';

import { Client, SearchResponse } from 'elasticsearch';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
// import 'rxjs/add/operator/do';  // for debugging

@Injectable()
export class Elasticsearch {
  private _client: Client;

  constructor() {
    if (!this._client) this._connect();
  }

  /*constructor() {
    this.clientElasticsearch = new Client({
        host: 'https://search-pxdevelastic-xkrhyz73gg5kr4okdyphdkoclm.eu-central-1.es.amazonaws.com',
        log: 'trace'
      });
  }*/

  private _connect() {
    this._client = new Client({
        host: 'https://search-pxdevelastic-xkrhyz73gg5kr4okdyphdkoclm.eu-central-1.es.amazonaws.com',
        log: 'trace'
    });
  }

  search(value): any {
    // if (value) {
    //     console.log(value)
    //     return this._client.search({
    //         index: 'testdata',
    //         q: `title:${value}, description:${value}`,
    //         size: 50,
    //         from: 150,
    //         scroll: '1m',
    //     })
    // } else {
    //     return Promise.resolve({})
    // }

    if (value) {
        console.log(value)
        return this._client.search({
            index: 'phonetictest/my_type',            
            q: `${value}`,
            size: 50,
            from: 150,
            scroll: '1m',
        })
    } else {
        return Promise.resolve({})
    }
  }

  addToIndex(value): any {
    return this._client.create(value)
  }

  isAvailable(): any {
      return this._client.ping({
          requestTimeout: Infinity,
          //hello: "elasticsearch!"
      });
  }

 /* public test_search(): Observable<SearchResponse<{}>> {
    return Observable.fromPromise(<Promise<SearchResponse<{}>>> this.clientElasticsearch.search( {
      index: 'testdata',
      type: 'info',
      q: `title:Sample`,
      scroll : '2m',
      size : 100,
    }));
  } */

}
