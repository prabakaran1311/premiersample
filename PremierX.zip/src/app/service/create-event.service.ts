import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from "@angular/http";
import { Router } from "@angular/router";
import { AppSettings } from '../core/app-setting';

  

@Injectable()


export class CreateEventService {


  //API CALL
  public actionUrl: string;
  public headers: Headers;
  public options: RequestOptions;

  constructor(public router: Router, public http: Http) {

     this.actionUrl = AppSettings.API_ENDPOINT;
    this.headers = new Headers({ 'Content-Type': 'application/json' });
    this.options = new RequestOptions({ headers: this.headers });
  }

  
  SaveBibs(model: any) {

    return this.http.post(this.actionUrl + 'event/save-bib', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        console.log(result);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }

  SaveGroupCategory(model: any) {
    return this.http.post(this.actionUrl + 'event/save-group-category', model, this.options)
    .map((response: Response) => {
      let result = response.json();
      let resultHttpstatus = result.status;
      // alert(EventID);
      //let resultMessage = result.message;
      console.log(result);
      if (resultHttpstatus == "OK") {

      } else {
        alert("error");
      }
    });
  }


  saveSocialLink(model: any) {

    return this.http.post(this.actionUrl + 'event/save-social-link', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        console.log(result);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }

  
  DeleteRecurenceData(model: any) {

    return this.http.delete(this.actionUrl + 'event/delete-recurrance/' + model).map((response: Response) => response.json())
  
  }

  getJSONlatlang(model: any) {

    return this.http.get("https://maps.googleapis.com/maps/api/geocode/json?address=" + encodeURIComponent(model) + " &key=AIzaSyDdLxYbq-0zybb2SzqHTywQW-l7nyKiHy8").map((response: Response) => response.json())
  }

  GetRecurenceData(model: any) {
   
    return this.http.get(this.actionUrl + "event/recurrance-list/" + model).map((response: Response) => response.json())
  }


  GetIP() {

    return this.http.get("https://freegeoip.net/json/").map((response: Response) => response.json())
  }



  SaveImage(model: any) {

    return this.http.post(this.actionUrl + 'event/save-image', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        console.log(result);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }


  GetCategoryData(model: any) {

    return this.http.get(this.actionUrl + "event/category-list/" + model).map((response: Response) => response.json())
  }


  changeStatus(model: any) {

    return this.http.post(this.actionUrl + 'event/change-status', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        console.log(result);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }



  getQuestions() {

    return this.http.get(this.actionUrl + "faq/list").map((response: Response) => response.json())
  }

  Countrycurrency() {
    // alert(model);

    return this.http.get(this.actionUrl + "other/country").map((response: Response) => response.json())
  }

  SaveCategory(model: any) {

    return this.http.post(this.actionUrl + 'event/save-category', model, this.options)
      .map(res => res.json());
  }


  savequestions(model: any) {

    return this.http.post(this.actionUrl + 'event/save-custom-question', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        console.log(result);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }


  saveadditionalfaq(model: any) {

    return this.http.post(this.actionUrl + 'event/create-event-faq', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        console.log(result);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }


  MapFaq(model: any) {

    return this.http.post(this.actionUrl + 'event/map-faq', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        console.log(result);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }

  SaveTeamCategory(model: any): any {

    return this.http.post(this.actionUrl + 'event/save-team-category', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        console.log(result);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }

  getEventSubType(model: any) {

    return this.http.get(this.actionUrl + "event/get-sub-type/" + model).map((response: Response) => response.json())
  }

  CreateEvent(model: any) {
    return this.http.post(this.actionUrl + 'event/save-basic-info', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        //console.log(resultStatus);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });

  }

  SaveRecurrance(model: any) {

    return this.http.post(this.actionUrl + 'event/save-recurrance', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        // alert(EventID);
        //let resultMessage = result.message;
        //console.log(resultStatus);
        if (resultHttpstatus == "OK") {

        } else {
          alert("error");
        }
      });
  }

  getEventType() {
    // alert(model);

    return this.http.get(this.actionUrl + "event/get-type").map((response: Response) => response.json())
  }

  GenerateEventID(model: any) {
    // alert(model);
   
    return this.http.post(this.actionUrl + 'event/generate-key', model, this.options)
      .map((response: Response) => {
        let result = response.json();
        let resultHttpstatus = result.status;
        let EventID = result.data.id;
        // alert(EventID);
        //let resultMessage = result.message;
        //console.log(resultStatus);
        sessionStorage.setItem('eventid', EventID);
        if (resultHttpstatus == "OK") {
          console.clear();
          console.log(result.data.registerType);
          if(result.data.registerType == "1"){
            this.router.navigate(['/eventcreation/eventInformation']);
          }
          else{
            this.router.navigate(['/eventcreation/eventInformation']);
          }
          
        } else {
          alert("error");
        }
      });

  }
}
