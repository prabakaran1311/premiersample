import { Injectable, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';


import { Http, Headers, Response, RequestOptions } from "@angular/http";
import { Router } from "@angular/router";
import { Observable } from "rxjs/Observable";

import { AppSettings } from './../core/app-setting';

declare var sessionStorage : any;
declare var localStorage : any;


@Injectable()
export class SharedService {
    email: any;

    mailid: string;
    visible: boolean;
    public IsUserLoggedIn: EventEmitter<Boolean> = new EventEmitter();
    public fblogoutbtn: EventEmitter<any> = new EventEmitter();

    public is_login: EventEmitter<any> = new EventEmitter();

    public actionUrl: string; 
    public headers: Headers;
    public options: RequestOptions;    

    res: any;


    constructor(public router: Router, public http: Http) {
        this.actionUrl = AppSettings.API_ENDPOINT;
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
        this.visible = true;
    }

    handleError(error) {
        console.log(error)
    }

    
      hide() { this.visible = false; }
    
      show() { this.visible = true; }
    
      toggle() { this.visible = !this.visible; }
    


    onSendVerifyCode(email, url) {

        sessionStorage.clear();
        this.mailid = email
        return this.http.get(this.actionUrl+'user/validate/email/' + email)
        .map((response: Response) => response.json())
        .subscribe((data => {
           // console.log('data',data);
            this.res = data;
            let status =  this.res.status;
           // console.log(status);
            //console.log(this.mailid);
            if (status === 'OK') {
                this.router.navigate(['/auth/login'], { queryParams: { returnUrl: url }});                
            } else if(status === 'ERROR'){
                //console.log(sessionStorage.getItem('email_id'));
                this.router.navigate(['/auth/register']);
            }
        }),
        (error) => {
            //console.log(this.mailid);
            this.router.navigate(['/auth/register']);
        })
    }

}