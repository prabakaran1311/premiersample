import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { HttpClientModule, HttpClient } from '@angular/common/http';

import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateModule, TranslateLoader,  MissingTranslationHandler, MissingTranslationHandlerParams } from '@ngx-translate/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';
import { SharedModule } from './shared/shared.module';
import { AgmCoreModule } from '@agm/core';

import 'jquery';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { HeaderComponent } from './commonelements/header/header.component';
import { FooterComponent } from './commonelements/footer/footer.component';

import { CoreModule } from './core/core.module';
import { AuthModule } from './auth/auth.module'; 
import { EventRegistrationModule } from './eventreg/eventregistration.module';
import { EventsModule } from './events/events.module';
import { EventCreationModule } from './event-create/eventcreation.module';
import { ProfileModule } from './user/profile.module';

import { EventCreationTicketModule } from './event-create-ticket/EventCreationTicket.module';

import { ShareButtonsModule } from 'ngx-sharebuttons';


// AoT requires an exported function for factories
export function HttpLoaderFactory(httpClient: HttpClient) {
    return new TranslateHttpLoader(httpClient, "../assets/i18n/", ".json");
}

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    HeaderComponent,
    FooterComponent,    
  ],
  imports: [
    BrowserModule.withServerTransition({appId: 'premierx'}),
    AppRoutingModule, 
    SharedModule,
    AuthModule,    
    EventsModule,    
    EventCreationTicketModule,
    EventRegistrationModule,
    EventCreationModule,
    ProfileModule,
    CoreModule.forRoot(),
    HttpClientModule,
    ShareButtonsModule.forRoot(),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDdLxYbq-0zybb2SzqHTywQW-l7nyKiHy8',
      libraries: ["places"]
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      },
    })    
  ],
  providers: [   
    BrowserAnimationsModule,
  ], 
  bootstrap: [AppComponent]
})
export class AppModule { }
