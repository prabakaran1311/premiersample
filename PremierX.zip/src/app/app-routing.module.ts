import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth/services/auth.guard';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  { path: '', component: HomeComponent },  
  { path: 'about', component: AboutComponent },    
  { path: 'auth', loadChildren: '../app/auth/auth.module#AuthModule' },
  { path: 'eventregister', loadChildren: '../app/eventreg/eventregistration.module#EventRegistrationModule', canActivate: [AuthGuard] },
  { path: 'events', loadChildren: '../app/events/events.module#EventsModule' },
  { path: 'eventcreation', loadChildren: '../app/event-create/eventcreation.module#EventCreationModule', canActivate: [AuthGuard] },
  { path: 'eventcreationticket', loadChildren: '../app/event-create-ticket/EventCreationTicket.module#EventCreationTicketModule', canActivate: [AuthGuard] },
  { path: 'profile', loadChildren: '../app/user/profile.module#ProfileModule', canActivate: [AuthGuard] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
  