import { Component, OnInit, ViewChild, ElementRef, Renderer2, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";

import { EventRegistrationService } from '../../service/eventregistration.service';

declare var jQuery: any;

export class GetValueofCat {
  quantity: number = 0;
  totalAmount: number;
}

@Component({
  selector: 'app-individual-friends-list',
  templateUrl: './individual-friends-list.component.html',
  styleUrls: ['./individual-friends-list.component.css'],
  providers : [GetValueofCat],
})
export class IndividualFriendsListComponent implements OnInit {
  eventChecked: number = 0;
  deliveryAddress: number = 0;
  userId: string;
  catagoryIdResult: any;
  test: any;
  eventId: any;
  result: any = [];
  catagoryList: any = [];
  checkedCatagory:any = [];
  totalPrize:any = 0;
  quantity : number = 0;
 // carObj: any = {};
  cart:any = {};
  carObj = <any>{};
  

  itemNumber: string;

  @ViewChild('item') item: ElementRef;
  @ViewChild('appendToChildEl') appendToChildEl: ElementRef;
  
  @ViewChild('rendererAppendToChildEl') rendererAppendToChildEl: ElementRef;

  constructor(public eventRegistrationService:EventRegistrationService, public router:Router, private route: ActivatedRoute, private _renderer: Renderer2, 
      public getValueofCat:GetValueofCat) {
        let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));    
        if(currentUser != null) {
          this.userId = currentUser.userid;   
        }
    
        let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
        if(currentUserFB != null) {
          this.userId = currentUserFB.details.userId;   
        }
        if (localStorage.cart) {
            this.cart = JSON.parse(localStorage.cart);
        }
        this.cart.cartItems = {};
        this.cart.userId = this.userId;
        
  }

  ngOnInit() {
    window.scrollTo(0, 0); 
    this.GetFriendList();
    this.route.paramMap.subscribe(params => {
      this.eventId = params.get('id'); 
    });
  }


  GetFriendList(){
    this.eventRegistrationService.GetAllFriendList()
    .subscribe((res)=>{
     // for(let i=0;i< res.data.length;i++){
        this.result = res.data;
        console.log(this.result)
        this.getCatagoryList();
        //console.log("datasadasd",data.fullName)     
      //}
    })
  }

  getCatagoryList(){
    this.eventRegistrationService.getEventCatagoriesList(this.eventId)
    .subscribe((res)=>{
      if(res.status === 'OK'){
        this.catagoryList = res.data;
        console.log('catagry',this.catagoryList)
      }
    })    
  }

  addToCart(id, catagoryId, fullName, catTitle){
    var currentUserObj = <any>{};
    var self = this;
    var sum;
    currentUserObj[id] = {};    
    currentUserObj[id].participantid = id;
    currentUserObj[id].participantName = fullName;
     
   // console.log(fullName)
    this.cart.cartItems[id] = {};
    
    if(jQuery("#catagoryId"+catagoryId).is(":checked")) { 
      currentUserObj[id]['categoryInfo'] = []; 
      currentUserObj[id]['categoryName'] = []; 
      currentUserObj[id]['categoryFee'] = [];
      var totalPrize = 0;
      jQuery('#list'+id).find('.catagory_list input:checked').each(function(){  
        var currentCategoryId = jQuery(this).val();   
        var currentCatagoryName = jQuery('.catagory_list input:checked+#catagoryName'+catagoryId).text();
        currentUserObj[id]['categoryInfo'].push(currentCategoryId);
        currentUserObj[id]['categoryName'].push(jQuery(this).next('').text());
        currentUserObj[id]['categoryFee'].push(Number(jQuery(this).next().next().next().text()));
      });
      sum = currentUserObj[id]['categoryFee'].reduce(this.add, 0);
      currentUserObj[id].quantity = currentUserObj[id]['categoryInfo'].length;
      this.cart.cartItems[id] = currentUserObj[id];     
      currentUserObj[id].participantTotalPrize = sum; 
      console.log('sum',sum)
      this.saveCart();
    } else {
      var currentCategoryId;
      currentUserObj[id]['categoryInfo'] = [];
      currentUserObj[id]['categoryName'] = []; 
      currentUserObj[id]['categoryFee'] = [];
      jQuery('#list'+id).find('.catagory_list input:checked').each(function(){  
        currentCategoryId = jQuery(this).val(); 
        currentUserObj[id]['categoryName'].push(jQuery(this).next().text());
        currentUserObj[id]['categoryInfo'].push(currentCategoryId);      
        currentUserObj[id]['categoryFee'].push(Number(jQuery(this).next().next().next().text()));
      });
      sum = currentUserObj[id]['categoryFee'].reduce(this.add, 0);
      currentUserObj[id].participantTotalPrize = sum;
      currentUserObj[id].quantity = currentUserObj[id]['categoryInfo'].length;      
      this.cart.cartItems[id] = currentUserObj[id];
      if(currentUserObj[id].quantity === 0) {
        console.log("completed delete", this.cart.cartItems[id])
        delete self.cart.cartItems[id];
      }
      this.saveCart();    

    }
  }

  
  
  add(a, b) {
      return a + b;
  }
  
  saveCart() {
      if (window.localStorage) {
        console.log("tfgb",this.cart);
        sessionStorage.setItem('cart',JSON.stringify(this.cart));        
      }
  }

  resize(id, catagoryId) {
    let navObj = this;
    var appendSelectedCatagory = document.getElementById('appendtext'); 
    jQuery(appendSelectedCatagory).prepend(jQuery('#FriendList'+id));
   
    if(jQuery("#catagoryId"+catagoryId).is(":checked")) { 
           
        this.displaySelectedList(id, catagoryId);
         
        var totalPrize = 0;
        navObj.quantity = 0;
       jQuery('#list'+id).find('.catagory_list input:checked').each(function(){   
                
          var currentCategoryId = jQuery(this).val();      
          navObj.eventRegistrationService.getEventCatagoriesList(navObj.eventId)
          .subscribe((res)=>{
            for(let i in res.data){
            var catList = res.data[i];
              if(catList.id == currentCategoryId){
                totalPrize += catList.fee
                navObj.quantity += 1;                
              }              
            }             
            jQuery('#sectionprize'+id).html(totalPrize);
            jQuery('#sectionquantity'+id).html(navObj.quantity);
            
          })
        })
       
    } else {

      this.eventChecked -= 1;
      var totalPrize = 0;
      navObj.quantity = 0;
      jQuery('#list'+id).find('.catagory_list input:checked').each(function(){         
        var currentCategoryId = jQuery(this).val();      
        navObj.eventRegistrationService.getEventCatagoriesList(navObj.eventId)
        .subscribe((res)=>{
          for(let i in res.data){
          var catList = res.data[i];
            if(catList.id == currentCategoryId){
              totalPrize += catList.fee
              navObj.quantity += 1;
            }
          }             
          jQuery('#sectionprize'+id).html(totalPrize)
          jQuery('#sectionquantity'+id).html(navObj.quantity)
        })
      })

      this.checkedCatagory.pop(catagoryId); 
      let checkBoxList = '#appendtext #list'+id;
      if(jQuery(checkBoxList+' :checkbox:checked').length == 0){
        jQuery('#listFriends').append(jQuery('#FriendList'+id));
        jQuery("#FriendList"+id+ " input[type='checkbox']").prop("checked", false);
        sessionStorage.removeItem(id);
      }
      
    }    
  }

  displaySelectedList(id, catagoryId) {
    this.eventChecked += 1;
    let getselectList = sessionStorage.getItem('selectedFriends');
    jQuery('#appendCatagoryList').append(jQuery('#catagorySelected'+catagoryId))
  }

  delete(id){   
    jQuery('#listFriends').append(jQuery('#FriendList'+id));
    jQuery("#FriendList"+id+ " input[type='checkbox']").prop("checked", false);
    console.log('asdasdsa',id);
    //this.quantity = 0;
    sessionStorage.removeItem(id);
  }



 /* getValueofQuantity(id){
    let quanty: number = 0;
    var itemss = JSON.parse(sessionStorage[id]);
    //console.log('quantytest',itemss);
    for (var i =0; i< itemss.length; i++) {
      quanty = itemss[i].quantity;
    }
    //console.log('quanty',quanty);
    this.getValueofCat.quantity = quanty;
  }*/

  confirmParticipants(){
    if(this.eventChecked == 0){
      alert("Please select atleast one friend");
    } else if(this.deliveryAddress == 0){
      alert("Please confirm the delivery address");
    } else {
     
     console.log('this.deliveryAddress',this.deliveryAddress)
     this.cart.shipmetDeliveryType = this.deliveryAddress;
     this.saveCart();
     console.log('saved data', this.cart);
     this.router.navigate(['/eventregister/select-size/',this.eventId]);
    }
    
  }
  
  /*confirmAddress(){
    
  }*/

}