import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualFriendsListComponent } from './individual-friends-list.component';

describe('IndividualFriendsListComponent', () => {
  let component: IndividualFriendsListComponent;
  let fixture: ComponentFixture<IndividualFriendsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualFriendsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualFriendsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
