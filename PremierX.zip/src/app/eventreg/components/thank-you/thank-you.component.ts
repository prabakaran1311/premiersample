import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

declare var jQuery: any;
@Component({
  selector: 'app-thank-you',
  templateUrl: './thank-you.component.html',
  styleUrls: ['./thank-you.component.css']
})
export class ThankYouComponent implements OnInit {
  event_img: string;

  constructor() { 


    this.event_img = 'assets/img/event-bg.jpg';
  }

  ngOnInit() {
    window.scrollTo(0, 0);
 jQuery('.owl-demo').owlCarousel({
      
            loop: false,
            margin: 30,
            nav: true,
            navText: ["<i class='fa fa-chevron-left' aria-hidden='true'></i>", "<i class='fa fa-chevron-right' aria-hidden='true'></i>"],
            responsive: {
              0: {
                items: 1
              },
              600: {
                items: 3
              },
              1000: {
                items: 3.7
              }
            }
      
          });
  }

}
