import { Component, OnInit, NgZone } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EventRegistrationService } from '../../service/eventregistration.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';


interface PartIds {
  participantId: [{
    id: any;
  }];
}
declare var jQuery: any;
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  dets: any = [];
  eventId: any;
  userName: string;
  eventName: string;
  participants: any = {};
  participantIds: any = [];
  event_img: string;
  partName: any = [];
  shirtSize: any = [];
  weight: any =[];
  addressLine1: any = [];
  addressLine2: any = [];
  countryId: any = [];
  city: any = [];
  mobile: any = [];
  zeroRefundCover: any;
  cart: any = {};
  quantity: any = [];
  individualTotalPrize: any = [];
  catgoryName: any = [];
  overallTotalPrize: number;
  /* partID = {}; */
  partIdArray: Array<any> = [];
  partIdss = {};
  


  constructor(
    private zone: NgZone,
    public router: Router,
    private route: ActivatedRoute,
    public eventRegistrationService: EventRegistrationService
  ) {
      this.event_img = 'assets/img/event-bg.jpg';
      let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));    
      if(currentUser != null) {
        this.userName = currentUser.username;   
      }

      let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
      if(currentUserFB != null) {
        this.userName = currentUserFB.username;   
      }

      this.getAllListOFParticipants();
  }


  ngOnInit() { 
    console.log(this.quantity);
    this.route.paramMap.subscribe(params => {
      this.eventId = params.get('id'); 
    });
    window.scrollTo(0, 0);
    jQuery('.owl-demo').owlCarousel({
            loop: false,
            margin: 30,
            nav: true,
            navText: ['<i class=\'fa fa-chevron-left\' aria-hidden=\'true\'></i>', '<i class=\'fa fa-chevron-right\' aria-hidden=\'true\'></i>'],
            responsive: {
              0: {
                items: 1
              },
              600: {
                items: 3
              },
              1000: {
                items: 2.7
              }
            }
          });

          for (let i=0; i < this.participantIds.length; i++) {
            console.log('PId', this.participantIds[i]);
            let jsonn = { id : this.participantIds[i] };
            this.partIdArray.push(jsonn);
            /* this.partID.participantId[i].id = this.participantIds[i];
            console.log(this.partID); */
            console.log(this.partIdArray);
          }
          this.partIdss = { participantId: this.partIdArray };
          this.eventRegistrationService.getUserBioInfo(this.partIdss)
          .subscribe((res) => {
            console.log('Response', res);
            this.dets = res.data;
            console.log('=======> ', this.dets);
          });
      this.getEventCatagoryList();
      this.getCatagoryListbyName();
  }

  zeroConfirm(value) {
    if (jQuery('#cancel').is(':checked')){ 
      this.cart.zeroRefundCover = value; 
    } else {
      this.cart.zeroRefundCover = 0;
    }
    this.saveCart();
  }

  calculateTotalPrice(a, b) {
      return a + b;
  }

  getEventCatagoryList() {
    var totalPrize = 0;
    var quantity = 0;
    this.eventRegistrationService.getEventCatagoriesList(this.eventId)
    .subscribe((res) => {
      for(let ii in res.data){
      var catList = res.data[ii];
       /* if(catList.id == currentCategoryId) {
          totalPrize += catList.fee
          this.quantity += 1;
        } */
      }
    });
  }

  deleteParticipantfromList(id){
    console.log('completed delete', id);
    delete this.cart.cartItems[id];
    this.saveCart();
    this.getAllListOFParticipants();
  }

  toCheckout() {
    this.router.navigate(['/checkout/' + this.eventId]);
  }

  getCatagoryListbyName() {
   
   /* let currentId = JSON.parse(sessionStorage.getItem('cart'));
    for(let key in currentId.cartItems) {
      var amount = [];
        var value = currentId.cartItems[key];      
        for(let i=0;i< value.categoryInfo.length; i++){
          // console.log('value.categoryInfo',value.categoryInfo[i]);        
          this.eventRegistrationService.getEventCatagoriesListByID(value.categoryInfo[i])
          .subscribe((res)=>{                
            console.log("titleeeeee-->", res.data[0].title);
            console.log('amount-->', res.data[0].fee)
            amount.push(res.data[0].fee);            
          })
          
        }
        console.log('amounttt==================>',amount);
      }*/
  }

  getAllListOFParticipants() {
    this.cart = JSON.parse(sessionStorage.getItem('cart'));
    
    let eventDetails = JSON.parse(sessionStorage.getItem('currentEventDetails'));
    
    if(eventDetails === null || eventDetails === undefined) {
      this.router.navigate(['/']);
    }
    this.eventName = eventDetails.eventName;
    // console.log(this.eventName)
    let currentId = JSON.parse(sessionStorage.getItem('cart'));
    var currentParticipantsName = [];
    var currentparticipantsId = [];
    var currentparticipantsQuantity = [];
    var currentCatgoryName = [];
    var currentTotalPrize = [];
    for (let i = 0; i < 1; i++) {
      for (var partName in currentId.cartItems) {
          currentParticipantsName.push(currentId.cartItems[partName].participantName);
          currentparticipantsId.push(currentId.cartItems[partName].participantid);
          currentparticipantsQuantity.push(currentId.cartItems[partName].quantity);
          currentCatgoryName.push(currentId.cartItems[partName].categoryName);
          currentTotalPrize.push(currentId.cartItems[partName].participantTotalPrize);
      }
    }
    this.participants.Names = currentParticipantsName;
    this.participantIds = currentparticipantsId;
    this.quantity = currentparticipantsQuantity;
    this.individualTotalPrize = currentTotalPrize;
    this.catgoryName = currentCatgoryName;
    // this.catgoryName = currentCatgoryName;
    this.overallTotalPrize = this.individualTotalPrize.reduce(this.calculateTotalPrice, 0);
    console.log('Names', this.participants.Names);
  }

  saveCart() {
    if (window.localStorage) {
      sessionStorage.setItem('cart',JSON.stringify(this.cart));
    }
  }
}
