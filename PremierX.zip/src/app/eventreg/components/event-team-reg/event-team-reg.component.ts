import { Component, OnInit, ViewChild, ElementRef, Renderer2, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";

import { EventRegistrationService } from '../../service/eventregistration.service';
import Handsontable from 'handsontable';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-event-team-reg',
  templateUrl: './event-team-reg.component.html',
  styleUrls: ['./event-team-reg.component.css']
})
export class EventTeamRegComponent implements OnInit {

  title = 'app';

  constructor(private _http: HttpClient) { }

  data: any = Handsontable.helper.isIE8();

  columns: object[] = [
    { data: 'firstName', title: 'First Name' },
    { data: 'lastName', title: 'Last Name' },
    { data: 'gender', title: 'Gender', width: 50 },
    { data: 'dateOfBirth', title: 'Day of Birth', width: 45 },
    { data: 'mobile', title: 'Mobile #', width: 150 }
  ];

  settings: object = {
    afterLoadData: (firstLoad) => {
      if (!firstLoad) {
        this.isLoading = false;
      }
    },
  };
  
  isLoading: boolean = false;

  loadData() {
    this.isLoading = true;

    this._http.get(`//api.tvmaze.com/singlesearch/shows?q=mr-robot&embed=episodes`)
      .subscribe((res: Response) => {
        this.data = res['_embedded']['episodes'];
      });
  }

  getData() {
    console.log('datata', this.data);
  }

  ngOnInit() {
    
  }


}
