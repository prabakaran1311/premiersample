import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventTeamRegComponent } from './event-team-reg.component';

describe('EventTeamRegComponent', () => {
  let component: EventTeamRegComponent;
  let fixture: ComponentFixture<EventTeamRegComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventTeamRegComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventTeamRegComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
