import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegtypeComponent } from './regtype.component';

describe('RegtypeComponent', () => {
  let component: RegtypeComponent;
  let fixture: ComponentFixture<RegtypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegtypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegtypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
