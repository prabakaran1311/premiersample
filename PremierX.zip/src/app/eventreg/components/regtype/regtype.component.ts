import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-regtype',
  templateUrl: './regtype.component.html',
  styleUrls: ['./regtype.component.css']
})
export class RegtypeComponent implements OnInit {
  eventId: string;

  constructor(private route: ActivatedRoute) { 

  }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.eventId = params.get('id');
    });
    window.scrollTo(0, 0);
  }

}
