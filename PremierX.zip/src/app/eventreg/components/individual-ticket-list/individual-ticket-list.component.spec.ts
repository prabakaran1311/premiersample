import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualTicketListComponent } from './individual-ticket-list.component';

describe('IndividualTicketListComponent', () => {
  let component: IndividualTicketListComponent;
  let fixture: ComponentFixture<IndividualTicketListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualTicketListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualTicketListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
