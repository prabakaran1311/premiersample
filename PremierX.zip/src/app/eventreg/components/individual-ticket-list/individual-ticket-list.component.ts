import { Component, OnInit, ViewChild, ElementRef, Renderer2, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";

import { EventRegistrationService } from '../../service/eventregistration.service';

@Component({
  selector: 'app-individual-ticket-list',
  templateUrl: './individual-ticket-list.component.html',
  styleUrls: ['./individual-ticket-list.component.css'],  
})
export class IndividualTicketListComponent implements OnInit {

  counterValue: number = 0;

  constructor() { }

  ngOnInit() {
  }

  increment() {this.counterValue++;}
  decrement() {this.counterValue--;}

}
