import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { Response } from '@angular/http';

import { EventRegistrationService } from '../../service/eventregistration.service';


export class AddFreindVariable {
  fname: string;
  lname: string;
  email: string;
  phonenumber: string;
  dob: string;
  gender: string;
  spouse: any = false;
  createdBy: string;
}

@Component({
  selector: 'app-add-friend',
  templateUrl: './add-friend.component.html',
  styleUrls: ['./add-friend.component.css']
})
export class AddFriendComponent implements OnInit {
  errormessage: any = null;
  eventId: string;
  addFreindVariable: AddFreindVariable;
  @ViewChild('f') form: any;
  result: any = [];
  active_css: string;
  error_code: string;
  friendsLength: Number;
  newlyAdded: Boolean = false;

  constructor(public eventRegistrationService: EventRegistrationService, private route: ActivatedRoute, public router:Router) {
   }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.eventId = params.get('id');
    });
    window.scrollTo(0, 0);
    this.addFreindVariable = new AddFreindVariable();
    this.GetFriendList();
  }

  Addfriend() {
    console.log(this.addFreindVariable);
    let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
    let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    if ( currentUser != null ) {
        this.addFreindVariable.createdBy = currentUser.userid;
    } else if (currentUserFB != null) {
      this.addFreindVariable.createdBy = currentUserFB.userid;
    }
    if (this.addFreindVariable.spouse === true) {
      this.addFreindVariable.email = '';
      this.addFreindVariable.phonenumber = '';
      this.addFreindVariable.spouse = 1;
    }
    if (this.addFreindVariable.spouse === false) {
      this.addFreindVariable.spouse = 0;
    }
    console.log('this.addFreindVariable.', this.addFreindVariable.spouse);
      this.eventRegistrationService.AddFriendListService(this.addFreindVariable)
      .subscribe((res) => {
      // console.log("res",res);
        // console.log("res.data",res.data)
        if(res.status === 'OK') {
          this.form.resetForm();
          this.addFreindVariable.spouse = false;
          this.addFreindVariable.email = '';
          this.addFreindVariable.phonenumber = '';
          this.addFreindVariable.dob = '';
          this.addFreindVariable.gender = '';
          this.GetFriendList();
          console.log("completed");
          this.newlyAdded = true;
          this.errormessage = null;
        }
      }, err => {
        this.addFreindVariable.spouse = false;
        this.errormessage = err;
        console.log('err', err);
      });
  }

  GetFriendList() {
    this.eventRegistrationService.GetAllFriendList()
    .subscribe((res) => {
        this.result = res.data;
        console.log('this.result',this.result.data);
        /* for(let i = 0; i <= this.result.length; i++) {
          if(i <= this.result) {
          }
        } */
        this.friendsLength = this.result.length;
    });
  }

  deleteFun(id){
    this.eventRegistrationService.deleteFriend(id)
    .subscribe((res) => {
      console.log(res);
      this.GetFriendList();
    });
  }

  proceedRegistration() {
    this.router.navigate(['/eventregister/IFriendsList', this.eventId]);
  }

  getGender(e) {
    console.log('e', e.target.value);
    this.addFreindVariable.gender = e.target.value;
  }
}
