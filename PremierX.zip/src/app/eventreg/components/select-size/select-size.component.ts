import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { EventRegistrationService } from '../../service/eventregistration.service';


export class ParticipantInfo{
  participantId: string;
  shirtSize: string;
  bodyWeight: string;
  addressLine1:string;
  addressLine2:string;
  addressLine3:string;
  countryId:string;
  city:string;
}

export interface FilledInfos {
  id: any;
  shirtSize: any;
  weight: number;
  addressLine1: any;
  addressLine2: any;
  addressLine3: any;
  countryId: any;
  city: any;
 }

@Component({
  selector: 'app-select-size',
  templateUrl: './select-size.component.html',
  styleUrls: ['./select-size.component.css']
})
export class SelectSizeComponent implements OnInit {
  getFriendList: any;
  answerList: any = [];
  participants: any = [];
  participantIds: any = [];
  eventId: any;
  questionList: any = [];
  iy: Number = 5;
  participantInfo: ParticipantInfo;
  friendList: any;
  countryList: any;
  friendsDets: any = [];
  eventBio: FilledInfos = {
    id: '',
    shirtSize: '',
    weight: 0,
    addressLine1: '',
    addressLine2: '',
    addressLine3: '',
    countryId: '',
    city: '',
   };
  eventBioList: FilledInfos[] = [];
  //eventBioList: any = [];

  constructor(public router:Router, private route: ActivatedRoute, public eventRegistrationService:EventRegistrationService) {
      this.eventRegistrationService.getCountryList()
      .subscribe((res)=>{
          this.countryList = res.data;
      });
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.participantInfo = new ParticipantInfo();
    this.route.paramMap.subscribe(params => {
      this.eventId = params.get('id');
    });
    this.getEventQuestionList();
    this.getSelectedFriendList();
    
    let selectSize = sessionStorage.getItem('selectSize');
    if(selectSize === null || selectSize === undefined){
      return
    } else if(selectSize === '1'){
      this.router.navigate(['/cart',this.eventId]);
    }
  }

  getEventQuestionList(){
    this.eventRegistrationService.getQuestionList(this.eventId)
    .subscribe((res)=>{
      this.questionList = res.data;
      console.log('questionlist', this.questionList);
     /* for(let i = 0; i<= this.questionList.length; i++){
        test = this.questionList[i].answer.split(",");      
        console.log('answerrr',test);       
      }
      this.answerList.push(test);
      console.log(this.answerList);*/
    })
  }

  /*getGender(e){
    console.log('e',e.target.value)    
    this.addFreindVariable.gender = e.target.value;      
  }*/

  isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    return !(charCode > 31 && (charCode < 48 || charCode > 57));
  }

  getSelectedFriendList(){
    let currentId = JSON.parse(sessionStorage.getItem('cart'));
    var currentParticipantsName = [];
    var currentparticipantsId = [];
    for (let i = 0; i < 1; i++) {
      for (var partName in currentId.cartItems) {
          this.participants.push({ 'name': currentId.cartItems[partName].participantName});
          currentparticipantsId.push(currentId.cartItems[partName].participantid);
      }
    }
    this.participantIds = currentparticipantsId;
    console.log('ID',this.participantIds);
    console.log('currentParticipantsName',this.participants);
  }

  addBioInfo() {
   let variable = 0;


   for (let i = 0; i < this.participants.length; i++) {
      console.log(this.participantIds[i]);
      console.log(this.participants[i].shirtSize);
      console.log(this.participants[i].bodyWeight);
      console.log(this.participants[i].addressLine1);
      console.log(this.participants[i].addressLine2);
      console.log(this.participants[i].countryId);
      console.log(this.participants[i].city);
      let eventBio1 = {
        id: '',
        shirtSize: '',
        weight: 0,
        addressLine1: '',
        addressLine2: '',
        addressLine3: '',
        countryId: '',
        city: '',
       };
      eventBio1.id = this.participantIds[i];
      eventBio1.shirtSize = this.participants[i].shirtSize;
      eventBio1.weight = this.participants[i].bodyWeight;
      eventBio1.addressLine1 = this.participants[i].addressLine1;
      eventBio1.addressLine2 = this.participants[i].addressLine2;
      eventBio1.addressLine3 = '';
      eventBio1.countryId = this.participants[i].countryId;
      eventBio1.city = this.participants[i].city;
      this.eventBioList[i] = eventBio1;
   }
   console.log('eventBioList', this.eventBioList);
   this.eventRegistrationService.setParticipantBioInfo(this.eventBioList)
   .subscribe((res) => {
     if (res) {
       console.log('resr', res);
       if (res.status === 'OK') {
         sessionStorage.setItem('selectSize', '1');
         this.router.navigate(['/cart', this.eventId]);
       } else if (res.data === 'ERROR') {
        let errorMessage = res.message;
        console.log(errorMessage);
       }
     }
   });


   /* for (let i = 0; i < this.participants.length; i++) {
    this.participants.participantId = this.participantIds[i];
    this.eventRegistrationService.setParticipantBioInfo(this.participants[i], this.participants.participantId)
    .subscribe((res) => {
      if (res) {
        console.log('resr', res);
        variable += 1;
        // console.log('variable',variable, 'this.participants.length-------->', this.participants.length);
        if (this.participants.length === variable) {
          sessionStorage.setItem('selectSize', '1');
          this.router.navigate(['/cart', this.eventId]);
        }
      }
    });
   } */
  }
}
