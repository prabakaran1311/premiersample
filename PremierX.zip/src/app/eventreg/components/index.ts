import { RegtypeComponent } from '../../eventreg/components/regtype/regtype.component';
import { IndividualFriendsListComponent } from '../../eventreg/components/individual-friends-list/individual-friends-list.component';
import { IndividualTicketListComponent } from '../../eventreg/components/individual-ticket-list/individual-ticket-list.component';
import { AddFriendComponent } from '../../eventreg/components/add-friend/add-friend.component';
import { SelectSizeComponent } from '../../eventreg/components/select-size/select-size.component';
import { CartComponent } from '../../eventreg/components/cart/cart.component';
import { CheckoutComponent } from '../../eventreg/components/checkout/checkout.component';
import { ThankYouComponent } from '../../eventreg/components/thank-you/thank-you.component';
import { EventTeamRegComponent } from '../../eventreg/components/event-team-reg/event-team-reg.component';



export const EVENTREG_COMPONENTS = [  
    RegtypeComponent, 
    IndividualFriendsListComponent, 
    IndividualTicketListComponent,
    EventTeamRegComponent,
    AddFriendComponent,
    SelectSizeComponent,
    CartComponent,
    CheckoutComponent,
    ThankYouComponent,
];

export const EVENTREG_ROUTES = [
  { path: 'regtype/:id', component: RegtypeComponent },
  { path: 'IFriendsList/:id', component: IndividualFriendsListComponent },
  { path: 'ITicketList/:id', component: IndividualTicketListComponent },
  { path: 'event-teamreg/:id', component: EventTeamRegComponent },
  { path: 'AddFriend/:id', component: AddFriendComponent },
  { path: 'select-size/:id', component: SelectSizeComponent },
  { path: 'cart/:id', component: CartComponent },
  { path: 'checkout/:id', component: CheckoutComponent },
  { path: 'thankyou/:id', component: ThankYouComponent },
];
