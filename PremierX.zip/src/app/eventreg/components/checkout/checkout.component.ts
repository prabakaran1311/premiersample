import { Component, OnInit, NgZone } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EventRegistrationService } from '../../service/eventregistration.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  userName: any;
  event_img: string;
  eventId: string;
  dets: any = [];
  eventName: any;
  cart: any;
  overallTotalPrize: any;
  catgoryName: any[];
  individualTotalPrize: any[];
  quantity: any[];
  participantIds: any[];
  participants: any;
  partIdArray: Array<any> = [];
  partIdss = {};
  names: any = [];

  constructor(
    private zone: NgZone,
    public router: Router,
    private route: ActivatedRoute,
    public eventRegistrationService: EventRegistrationService
  ) {
      this.event_img = 'assets/img/event-bg.jpg';
      let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
      if (currentUser != null) {
        this.userName = currentUser.username;
      }

      let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
      if (currentUserFB != null) {
        this.userName = currentUserFB.username;
      }

      this.getAllListOFParticipants();
  }


  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.eventId = params.get('id');
      console.log(this.eventId);
    });
    window.scrollTo(0, 0);

    for (let i = 0; i < this.participantIds.length; i++) {
      console.log('PId', this.participantIds[i]);
      let jsonn = { id : this.participantIds[i] };
      this.partIdArray.push(jsonn);
      /* this.partID.participantId[i].id = this.participantIds[i];
      console.log(this.partID); */
      console.log(this.partIdArray);
    }
    this.partIdss = { participantId: this.partIdArray };
    this.eventRegistrationService.getUserBioInfo(this.partIdss)
    .subscribe((res) => {
      console.log('Response', res);
      this.dets = res.data;
      console.log('=======> ', this.dets);
    });
    this.getEventCatagoryList();
    /* this.getCatagoryListbyName(); */
  }

  saveCart(): any {
    throw new Error("Method not implemented.");
  }

  getAllListOFParticipants() {
    this.cart = JSON.parse(sessionStorage.getItem('cart'));
    let eventDetails = JSON.parse(sessionStorage.getItem('currentEventDetails'));
    if (eventDetails === null || eventDetails === undefined) {
      this.router.navigate(['/']);
    }
    this.eventName = eventDetails.eventName;
    // console.log(this.eventName)
    let currentId = JSON.parse(sessionStorage.getItem('cart'));
    var currentParticipantsName = [];
    var currentparticipantsId = [];
    var currentparticipantsQuantity = [];
    var currentCatgoryName = [];
    var currentTotalPrize = [];
    for (let i = 0; i < 1; i++) {
      for (var partName in currentId.cartItems) {
          currentParticipantsName.push(currentId.cartItems[partName].participantName);
          currentparticipantsId.push(currentId.cartItems[partName].participantid);
          currentparticipantsQuantity.push(currentId.cartItems[partName].quantity);
          currentCatgoryName.push(currentId.cartItems[partName].categoryName);
          currentTotalPrize.push(currentId.cartItems[partName].participantTotalPrize);
      }
    }
    this.names.push(currentParticipantsName);
    this.participantIds = currentparticipantsId;
    this.quantity = currentparticipantsQuantity;
    this.individualTotalPrize = currentTotalPrize;
    this.catgoryName = currentCatgoryName;
    // this.catgoryName = currentCatgoryName;
    this.overallTotalPrize = this.individualTotalPrize.reduce(this.calculateTotalPrice, 0);
    console.log('Names', this.names);
    console.log('Categories', this.catgoryName);
    console.log('Quantity', this.quantity);
    console.log('individualTotalPrize', this.individualTotalPrize);
  }


  calculateTotalPrice(a, b) {
      return a + b;
  }

  getEventCatagoryList() {
    var totalPrize = 0;
    var quantity = 0;
    this.eventRegistrationService.getEventCatagoriesList(this.eventId)
    .subscribe((res) => {
      for(let ii in res.data){
      var catList = res.data[ii];
      /* if(catList.id == currentCategoryId) {
          totalPrize += catList.fee
          this.quantity += 1;
        } */
      }
    });
  }

  deleteParticipantfromList(id){
    console.log('completed delete', id);
    delete this.cart.cartItems[id];
    this.saveCart();
    this.getAllListOFParticipants();
  }

}
