import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EVENTREG_ROUTES } from './components';

const EventRegRoutes: Routes = [...EVENTREG_ROUTES];

@NgModule({
  imports: [RouterModule.forChild(EventRegRoutes)],
  exports: [RouterModule]
})
export class EventRegistrationRoutingModule { }
