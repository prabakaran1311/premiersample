import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { Component, OnInit, Injectable } from '@angular/core';
import {Router} from "@angular/router";
import { AppSettings } from './../../core/app-setting';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';


@Injectable()
export class EventRegistrationService { 
    options: RequestOptions;
    headers: Headers;
    actionUrl: string;
    userId: string;

    constructor(public http:Http){
        this.actionUrl = AppSettings.API_ENDPOINT;
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });

        let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));    
        if(currentUser != null) {
          this.userId = currentUser.userid;   
        }    
        let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
        if(currentUserFB != null) {
          this.userId = currentUserFB.userid;   
        }
    }

    AddFriendListService(Friendlist) {
        // tslint:disable-next-line:max-line-length
        let body = JSON.stringify({ firstName: Friendlist.name, lastName: Friendlist.lname, gender: Friendlist.gender, dateOfBirth: Friendlist.dob, email: Friendlist.email, mobile: Friendlist.phonenumber, createdBy: Friendlist.createdBy.toString(), dependants: Friendlist.spouse });
        return this.http.post(this.actionUrl+'user/add-new-friend', body, this.options)
        .map((response: Response) => response.json())
        .catch(this.handleError);
    }

    deleteFriend(id){
        let body = JSON.stringify({id: id});
        let headers = new Headers({ 'Content-Type': 'application/json' });        
        let options = new RequestOptions({ headers: headers, body: body });
        return this.http.delete(this.actionUrl+'user/delete-friend', options)
        .map((response:Response) => response.json())
        .catch(this.handleError);
    }

    GetAllFriendList(){
        let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
        let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
        let userID;
        if( currentUser != null) {
            userID = currentUser.userid;
        } else if(currentUserFB != null) {
            userID = currentUserFB.userid;
        }
        return this.http.get(this.actionUrl+'user/get-friend-list/'+userID+'/1')
        .map((response:Response) => response.json())
        .catch(this.handleError);
    }

    getEventCatagoriesList(eventID) {
        return this.http.get(this.actionUrl + 'event/category-list/' + eventID)
        .map((response:Response) => response.json())
        .catch(this.handleError);
    }

    getEventCatagoriesListByID(catagoryID): Observable<any>{
        return this.http.get(this.actionUrl + 'event/category/' + catagoryID)
        .map((response:Response) => response.json())
        .catch(this.handleError);
    }

    getQuestionList(eventId){
        return this.http.get(this.actionUrl + 'event/question-list/' + eventId)
        .map((response:Response) => response.json())
        .catch(this.handleError);
    }

    /* setParticipantBioInfo(ParticipantInfo, participantsId){
        let body = JSON.stringify({id:participantsId,shirtSize:ParticipantInfo.shirtSize,weight:ParticipantInfo.bodyWeight, addressLine1:ParticipantInfo.addressLine1,
            addressLine2:ParticipantInfo.addressLine2,addressLine3:ParticipantInfo.addressLine3, countryId:ParticipantInfo.countryId,city:ParticipantInfo.city});
        console.log(body, 'participantsId',participantsId);
        return this.http.put(this.actionUrl+'user/update-user-bio-info',body, this.options)
        .map((response:Response) => response.json())
        .catch(this.handleError);
    } */

    setParticipantBioInfo(ParticipantInfo) {
        let body = JSON.stringify(ParticipantInfo);
        console.log(body);
        return this.http.put(this.actionUrl + 'user/update-user-bio-info', body,  this.options)
            .map((response: Response) => response.json())
            .catch(this.handleError);
    }


    /* getUserBioInfo(participantId){
        let body = JSON.stringify({participantId:[{id:participantId }]});
        return this.http.post(this.actionUrl+'user/user-bio-info',body, this.options)
        .map((response:Response) => response.json())
        .catch(this.handleError);
    } */

    getUserBioInfo(participantId) {
        console.log('partiID : ', participantId);
        /* let info = "{ 'id':'" +participantId+ "'}";
        let body = JSON.stringify('{participantId:['+ info +']}');
        console.log('seriiiii',body); */
        let body = JSON.stringify(participantId);
        console.log('Going in ==> ', body)
        return this.http.post(this.actionUrl + 'user/user-bio-info', body, this.options)
        .map((response: Response) => response.json())
        .catch(this.handleError);
    }

    getCountryList() {
        return this.http.get(this.actionUrl + 'other/country')
        .map((response: Response) => response.json())
        .catch(this.handleError);
    }
    private handleError(error: any) {
      //  let errMsg = (error.message) ? error.message :
        // error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        // console.error(errMsg);
        return Observable.throw(error);
    }
}