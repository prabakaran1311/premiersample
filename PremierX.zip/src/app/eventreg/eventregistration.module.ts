import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HotTableModule } from 'angular-handsontable';
import { EventRegistrationRoutingModule } from './eventregistration-routing.module';

import { EVENTREG_COMPONENTS } from './components';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';


@NgModule({
  imports: [
    CommonModule,
    EventRegistrationRoutingModule,
    FormsModule,
    ReactiveFormsModule,    
    BsDatepickerModule,
    HotTableModule.forRoot()
  ],
  declarations: [
    ...EVENTREG_COMPONENTS
  ]
})
export class EventRegistrationModule { }
