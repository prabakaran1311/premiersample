import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { Component, OnInit, Injectable } from '@angular/core';
import {Router} from "@angular/router";
import { AppSettings } from './../../core/app-setting';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';

import * as AWS from "aws-sdk";
import {environment} from "../../../environments/environment";

declare var sessionStorage : any;
declare var localStorage : any;

@Injectable()
export class RegistrationService {

    public actionUrl: string; 
    public headers: Headers;
    public options: RequestOptions;
    css_class: string;
    verifyphn: number = 0;
    verifyval: number = 0;
    submit_btn_enable: boolean = true;
    confirm_code_enable: boolean = false;

    constructor(public http:Http, public router:Router) {
        this.actionUrl = AppSettings.API_ENDPOINT;
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
    }

    


    RequestVerificationEmail(email){
        let body = JSON.stringify({ "action": "verifyemail", "email": email});

        return this.http.post(this.actionUrl+'user/request-email-verify-code', body, this.options)
        .map((response : Response) => response.json())
        .catch((error: any) => Observable.throw(error || 'Server error'));
    
    }

    VerifyEmailAddress(email, verificationcode){
        let body = JSON.stringify({ "action": "verifycode", "email": email, "code": verificationcode});
        return this.http.post(this.actionUrl+'user/validate-email-verify-code', body, this.options)
        .map((response:Response) => response.json()).catch(this.handleError);
    }

    RequestVerificationPhone(phonenumber){
        let body = JSON.stringify({action: 'verify', phoneNo: phonenumber});
        console.log(body);
        return this.http.post(this.actionUrl+'user/request-code', body, this.options)
        .map((response: Response)=> response.json())
    }

    VerifyPhoneNumber(phonenumber, verifycodenumber){
        let body = JSON.stringify({action: 'verify', phoneNo: phonenumber, code: parseInt(verifycodenumber)});
        console.log('body',body)
        return this.http.post(this.actionUrl+'user/verify-code', body, this.options)
        .map((response: Response)=>  response.json())
    }

  /*  checkUserExists(email) {     
        return this.http.get(this.actionUrl+'user/validate/email/' + email, this.options)
        .map((response: Response) =>{ 
            response.json()
            let status = response.status;
            if (status == 200) {
                this.router.navigate(['/auth/login']);
                //this.router.navigate(['/auth/GetStarted'], { queryParams: { returnUrl: state.url }});
            } else {
                console.log(sessionStorage.getItem('email_id'));
                this.router.navigate(['/auth/register']);
            }
        })
        .subscribe((data => { data}),
        (error) => {
            this.router.navigate(['/auth/register']);
        })
    }*/

    

    updateEmailStauts(UserId, changeEmailID){
        let body = JSON.stringify({ email: changeEmailID, emailVerified: 0 });
        return this.http.put(this.actionUrl+'user/update-email/' + UserId, body, this.options)
        .map((response: Response)=> response.json())
    }

    ChangeEmailID(UserId, changeEmailID) {
        let body = JSON.stringify({ email: changeEmailID, emailVerified: 1 });
        return this.http.put(this.actionUrl+'user/update-email/' + UserId, body, this.options)
        .map((response: Response)=>  response.json())
    }

    mapUserwithFacebook(fbId, email){
        let body = JSON.stringify({fbId: fbId, email: email });
        return this.http.post(this.actionUrl+'user/map-user-with-fb', body, this.options)
        .map((response: Response)=>  response.json())
    }

    private handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}