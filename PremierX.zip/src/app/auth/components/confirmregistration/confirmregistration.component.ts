import {Component, OnDestroy, OnInit} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {UserRegistrationService} from "../../../service/user-registration.service";
import {UserLoginService} from "../../../service/user-login.service";
import {LoggedInCallback} from "../../../service/cognito.service";
import { RegistrationService } from '../../services/registration.service';
import * as AWS from "aws-sdk";
import { environment } from "../../../../environments/environment";
import { SharedService } from '../../../service/shared.service';

declare var sessionStorage : any;
declare var localStorage : any;

@Component({
  selector: '',
  template: ''
})
export class LogoutComponent implements LoggedInCallback {

  constructor(public router: Router,
              public userService: UserLoginService, public sharedService : SharedService) {
      this.userService.isAuthenticated(this)
  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
      if (isLoggedIn) {
          this.userService.logout();
          this.router.navigate(['/']);
      }

      this.router.navigate(['/']);
  }
}


/*export class ConfirmregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}*/

@Component({
  selector: 'app-confirmregistration',
  templateUrl: './confirmregistration.component.html',
  styleUrls: ['./confirmregistration.component.css']
})
export class RegistrationConfirmationComponent implements OnInit, OnDestroy {
    confirmationCode: string;
    email: string;
    errorMessage: string;
    private sub: any;
    Remember:Boolean = false;
    codeVerified: boolean = false;
    loading:boolean = false;

    constructor( public registrationService:RegistrationService, public regService: UserRegistrationService, public router: Router, 
        public route: ActivatedRoute,  public userService: UserLoginService, private sharedService: SharedService) {
    }

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.email = params['username'];

        });

        this.errorMessage = null;
    }

    ngOnDestroy() {
        this.sub.unsubscribe();
    }

    onConfirmRegistration() {
      //  this.errorMessage = null;
       // this.regService.confirmRegistration(this.email, this.confirmationCode, this);       
   
        let email = sessionStorage.getItem('email_id');
        this.registrationService.VerifyEmailAddress(email, this.confirmationCode) 
        .subscribe((res) => {           
            //console.log(res);
            if(res.status.toString() === 'OK') {   
                this.errorMessage = null;         
                this.AdminUpdateEmailStatus();
            } else if (res.status.toString() === 'ERROR'){
                this.errorMessage = res.message;
            }
        })
    }

    onCheckCode(code){
        if(code.length === 6) {
            this.codeVerified = true;
        } else if(code.length < 6) { 
            this.codeVerified = false;
        } else { 
            this.codeVerified = false;
        }
    }
    AdminUpdateEmailStatus(){        
        let email = sessionStorage.getItem('email_id');    
        AWS.config.update({
            accessKeyId: "AKIAJDPMAZUJXANJEJSQ",
            secretAccessKey: "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",
            region: 'eu-central-1' // change region if required
        });   
    
        let cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();
    
        let params = {
            UserAttributes: [ /* required */
            {
                Name: 'email_verified', /* required */
                Value: 'true'
            },
            ],
            UserPoolId: environment.userPoolId, /* required */
            Username: email /* required */
        };
        var headerClassObj = this;
        cognitoidentityserviceprovider.adminUpdateUserAttributes(params, function(err, data) {
            if (err) { 
               // console.log(err, err.stack); // an error occurred
            }else {     
               // console.log(data);    
                headerClassObj.router.navigate(['/auth/forgotPassword']);
            }
        });
    }

  
    CognitoCallbackConfirm(message: string, result: any) {
        if (message != null) { //error
            this.errorMessage = message;
           // console.log("message: " + this.errorMessage);
        }  else { //success
            //move to the next step
          //  console.log("Moving to securehome");
            // this.configs.curUser = result.user;
            //this.router.navigate(['/securehome']);         
            let currentUser = JSON.parse(sessionStorage.getItem('currentUserPas'));
            let token = currentUser.token;
            this.userService.authenticate(this.email, token, this, this.Remember)
        }
    }

    cognitoCallback(message: string, result: any) {
        if (message != null) { //error
            this.errorMessage = message;
           // console.log("message: " + this.errorMessage);
        }  else { //success
            //move to the next step
           // console.log("Moving to securehome");
            // this.configs.curUser = result.user;
            //this.router.navigate(['/securehome']);   
            //this.sharedService.IsUserLoggedIn.next(true);
            this.router.navigate(['/premierid']);
        }
    }

    
}
