import { LoginComponent } from './login/login.component';
import { LogoutComponent, RegistrationConfirmationComponent } from './confirmregistration/confirmregistration.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPassword2Component, ForgotPasswordStep1Component} from "./forgot/forgotPassword.component";
import { ResendCodeComponent } from "./resend/resendCode.component";
import { NewPasswordComponent } from "./newpassword/newpassword.component";
import { GetStartedComponent } from './get-started/get-started.component';
import { FacebookregisterComponent } from './facebookregister/facebookregister.component';


export const AUTH_COMPONENTS = [  
  LoginComponent, 
  RegisterComponent, 
  LogoutComponent,
  RegistrationConfirmationComponent,
  ForgotPassword2Component,
  ForgotPasswordStep1Component,
  ResendCodeComponent,
  NewPasswordComponent,
  GetStartedComponent,
  FacebookregisterComponent
];

export const AUTH_ROUTES = [
  { path: 'GetStarted', component: GetStartedComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'confirmRegistration/:username', component: RegistrationConfirmationComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'resendCode', component: ResendCodeComponent },
  { path: 'forgotPassword/:email', component: ForgotPassword2Component },
  { path: 'forgotPassword', component: ForgotPasswordStep1Component },
  { path: 'newPassword', component: NewPasswordComponent },
  { path: 'facebookRegistration', component: FacebookregisterComponent }
];
