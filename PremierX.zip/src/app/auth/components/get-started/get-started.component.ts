import { Component, OnInit, NgZone } from '@angular/core';
import { SharedService } from "../../../service/shared.service"
import { Router, ActivatedRoute } from "@angular/router";

import { FacebookService, InitParams, LoginResponse } from 'ngx-facebook';

import {CognitoCallback, LoggedInCallback, CognitoUtil} from "../../../service/cognito.service";
import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { AppSettings } from '../../../core/app-setting';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';


import 'aws-sdk/dist/aws-sdk';
declare const AWS: any;
import 'amazon-cognito-js';

declare let window: any;
//declare let FB: any;
declare var sessionStorage : any;
declare var localStorage : any;

@Component({
  selector: 'app-get-started',
  templateUrl: './get-started.component.html',
  styleUrls: ['./get-started.component.css']
})
export class GetStartedComponent implements OnInit {
 returnUrl: any;
 email: string;
 alertemail: string;
 loading = false;
 public is_fb_login:Boolean = false;
 active_css: string;
 public actionUrl: string; 
 public headers: Headers;
 public options: RequestOptions;
 
 
  
    constructor(public router: Router, public http: Http,  public route: ActivatedRoute, public sharedService: SharedService, private zone:NgZone, public fb: FacebookService) { 
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
        
        this.actionUrl = AppSettings.API_ENDPOINT;
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
        this.AutofillEmail();
        this.is_fb_login = false;
        
        fb.init({
            appId: '165158957377830',
            xfbml: true,
            version : 'v2.10'
        });

        (function(d, s, id){
            let js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) {return;}
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));

    
    }

    ngOnInit() { 
        this.userloggedincheck();
        if(this.email != undefined) {
            if(this.email.length > 0) {
                this.active_css = 'float-lbl';
            } else {
                this.active_css = '';
            }
        }
    } 

    AutofillEmail() {
        let emailidd = sessionStorage.getItem('email_id');
        if(emailidd != null) {
            //console.log("test currentuser",emailidd);
            this.email = emailidd;
        }
    }

    onKeyup(emailid){
        sessionStorage.setItem('email_id', emailid);
        if(emailid.length > 0) {
            this.active_css = 'float-lbl';
        } else {
            this.active_css = '';
        }
    }
    oncheck() {
        if (this.email === undefined || this.email === '' || this.email === null) {
            return false;
        } else {
            this.loading = true;
            this.sharedService.onSendVerifyCode(this.email, this.returnUrl);
            sessionStorage.setItem('email_id', this.email);
        }
    }

    userloggedincheck(){
        let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
        let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

        if(currentUserFB != null || currentUser != null) {
            //console.log("test currentuser",currentUser.jwtToken);
            if (currentUserFB && currentUserFB.jwtToken || currentUser && currentUser.jwtToken) {
                this.router.navigate([this.returnUrl])
            } else {
                //return false
            }
        }
    }

    loginWithFacebook(): void {    
        let httpobj = this.http;
        let navobj = this.router;
        let navthis = this;
        this.fb.login()
        .then((res: LoginResponse) => {
         // console.log('Logged in', res);  
          let accessToken = res.authResponse.accessToken;   
          navthis.fb.api('/me', 'get', { access_token: accessToken, fields: 'id,email,name,gender,first_name,last_name' })
          .then((response: any) => {
    
          //  console.log('Got the users profile', response);
            sessionStorage.setItem('fbAccessToken',accessToken);
          //  console.log(response);
            if (true) {
    
              //  console.log('You are now logged in.');
                AWS.config.update({
                    region: CognitoUtil._REGION,
                    credentials: new AWS.CognitoIdentityCredentials({
                        IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID,
                        Logins: {
                            'graph.facebook.com': accessToken,                                       
                        },                          
                    })     
                });
               // console.log("accesstoken", accessToken); 
                navthis.zone.run(() => {
                    httpobj.get(navthis.actionUrl+'user/validate/fbid/' + response.id)
                    .map((res:Response) => res.json()) 
                    .catch((err) => { return err; })
                    .subscribe((user) => {  
                        if(user.status.toString() === 'OK') {                      
                            let useridd = user.data[0].id;
                            let email = user.data[0].email;
                            sessionStorage.setItem('currentUserFB', JSON.stringify({userid: useridd, username: response.first_name, email: email, jwtToken: accessToken, fbid:user.data[0].fbId}));                
                            navthis.sharedService.IsUserLoggedIn.next(true); 
                            navobj.navigate([navthis.returnUrl]);
                            window.location.href = navthis.returnUrl;
                        } else if(user.status.toString() === 'ERROR'){
                            sessionStorage.setItem('FacebookDetails', JSON.stringify(response));  
                            navthis.sharedService.IsUserLoggedIn.next(false);    
                           // console.log('test praba');                                                   
                            navobj.navigate(['/auth/facebookRegistration']); 
                        }
                    });  
                });   
            } else {
                //console.log('There was a problem logging you in.');
            }
    
    
          })
          .catch(navthis.handleError);      
        })
        .catch(this.handleError);
    
    }
 
    private handleError(error) {
        console.error('Error processing action', error);
    }
}
