import { Component, OnInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params, ParamMap } from '@angular/router';
import {UserRegistrationService} from "../../../service/user-registration.service";
import {CognitoCallback} from "../../../service/cognito.service";
import { Meta, Title } from "@angular/platform-browser";
import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import {UserLoginService} from "../../../service/user-login.service";
import { SharedService } from '../../../service/shared.service';
import { RegistrationService } from '../../../auth/services/registration.service';
import { InternationalPhoneModule } from 'ng4-intl-phone';

declare var sessionStorage : any;
declare var localStorage : any;
declare var jQuery: any;

export class RegistrationUser {
  name: string;
  lname: string;
  email: string;
  password: string;
  phonenumber: string;
  dob: string;
  gender: string;
}

export class VerifyPhoneNumber{
    verifycode: string;
    phonenumber: string;
}

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements CognitoCallback {
    registrationUser: RegistrationUser;
    verifyPhoneNumber: VerifyPhoneNumber;
    router: Router;
    errorMessage: string;
    verify_show: any;
    res: any;
    css_class: string;
    verifyphn: number = 0;
    verifyval: number = 0;
    submit_btn_enable: any = true;
    confirm_code_enable: any = false;
    loading = false;
    public is_login:any = false;
    Remember:any = false;
  

    constructor(meta: Meta, title: Title, public userRegistration: UserRegistrationService, router: Router, private route: ActivatedRoute, public http:Http, 
         public userService: UserLoginService, private sharedService: SharedService, public registrationService:RegistrationService, private elementRef: ElementRef) {
        this.router = router;
        this.onInit();
        title.setTitle('PremierX Registration');
        
        meta.addTags([
          { name: 'author',   content: 'Premierx.com'},
          { name: 'keywords', content: 'Premierx keywords'},
          { name: 'description', content: 'Premierx description' }
        ]);
    }

   
    onInit() {
        this.userloggedincheck();
        if (sessionStorage.getItem('email_id') == null) {
            this.router.navigate(['/auth/GetStarted'])
        }
        this.registrationUser = new RegistrationUser();
        this.errorMessage = null;      
        this.verify_show = false;  
        this.registrationUser.email =  sessionStorage.getItem('email_id');
    }

    userloggedincheck(){
        let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
        let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

        if(currentUserFB != null || currentUser != null) {
           // console.log("test currentuser",currentUser.jwtToken);
            if (currentUserFB && currentUserFB.jwtToken || currentUser && currentUser.jwtToken) {
                this.router.navigate(['/'])
            } else {
                //return false
            }
        }
    }

    GetStarted(){
        //window.location.href= "/auth/GetStarted";
        this.router.navigate(['/auth/GetStarted']);
    }

    onRegister() {  
        this.loading = true;
        this.errorMessage = null;
        sessionStorage.setItem('currentUserPas', this.registrationUser.password);     
      //  console.log(this.registrationUser); 
        this.userRegistration.register(this.registrationUser, this);
    }

    onSendVerifyCode(){        
        if(this.verifyphn == 0){
            this.registrationService.RequestVerificationPhone(this.registrationUser.phonenumber).subscribe(data =>{ 
              //  console.log('data',data, 'data.status', data.status)
                if(data.status.toString() === 'OK') {
                    this.verifyphn = 1;
                    this.errorMessage = null;
                    this.verify_show = true;
                   // console.log("test phone number",data);
                } else if(data.status.toString() === 'ERROR') { 
                    this.errorMessage = data.message;
                }
            },
            (err: Response) => {               
               let retrivemessage =  err.json();
                if(retrivemessage.message != '') {              
                    this.errorMessage = retrivemessage.message;
                } else {
                    this.errorMessage = 'Something happend strange... Please try again later';
                }
            });
        }
    }

    onReSendVerifyCode(){
        this.verifyphn = 0;
        if(this.verifyphn == 0){
            this.registrationService.RequestVerificationPhone(this.registrationUser.phonenumber).subscribe(data =>{ 
               // console.log('phonenumber',data);               
                if(data.status.toString() === 'OK') {
                    this.verifyphn = 1;     
                    this.confirm_code_enable = false;
                    this.submit_btn_enable = true;
                    this.errorMessage = null;
                } else if(data.status.toString() === 'ERROR') { 
                    this.errorMessage = data.message;
                }
            },
            (err: Response) => {               
                let retrivemessage =  err.json();
                if(retrivemessage.message != '') {              
                    this.errorMessage = retrivemessage.message;
                } else {
                    this.errorMessage = 'Something happend strange... Please try again later';
                }               
            });
        }
    }

    
  /*  onPhoneNumber(){       
        console.log(this.registrationUser.phonenumber);
        this.currentnumber = this.registrationUser.phonenumber;
        if( this.currentnumber == this.oldnumber ){
            console.log("corret number");
        }else{
            console.log("wrong number");
        }
    }*/
  
    onKey(verifycodenumber) {     
        let verifycodee = verifycodenumber;
       
        if(this.verifyval == 0 && verifycodee.length == 6){            
          //  console.log(verifycodee);
          //  console.log('length reached five');
            this.css_class = "confirm-no";
            this.registrationService.VerifyPhoneNumber(this.registrationUser.phonenumber, verifycodenumber)
            .subscribe((res: Response) => {               
                //console.log("phoneverify",res.status);
                let statuscode = res.status.toString();
                let msg = res;
                if(statuscode === "OK") {
                    this.verifyval = 1;                    
                    this.confirm_code_enable = true;
                    this.css_class = "confirm-code";
                    this.submit_btn_enable = false;
                    this.res = res;
                   // console.log(this.res);
                } else if(statuscode === "ERROR") { 
                    this.css_class = "confirm-no";                    
                }
            });    
        }
                  
    }

    CognitoCallbackConfirm(message: string, result: any) {
        if (message != null) { //error 
            this.errorMessage = message;
            //console.log("message: " + this.errorMessage);
            this.loading = false;
        }  else { //success        
            let currentUser = sessionStorage.getItem('currentUserPas');
            this.registrationService.RequestVerificationEmail(this.registrationUser.email).subscribe()
           // this.sharedService.IsUserLoggedIn.next(true);
            this.userService.authenticate(this.registrationUser.email, currentUser, this, this.Remember);
        }
    }


  

    cognitoCallback(message: string, result: any) {
        if (message != null) { //error
            this.loading = false;
            this.errorMessage = message;
           // console.log("result: " + this.errorMessage);
        } else { //success
           // console.log("redirecting"); 
           // this.sharedService.IsUserLoggedIn.next(true);
            this.is_login = true;
            this.router.navigate(['/']);
            window.location.href = '/';
           // this.router.navigate(['/']);
        }
    }
} 

