import { Component, OnInit, NgZone } from '@angular/core';
import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { Router, ActivatedRoute, Params, ParamMap } from '@angular/router';
import { CognitoCallback, LoggedInCallback, CognitoUtil } from "../../../service/cognito.service";
import { UserLoginService } from "../../../service/user-login.service";
import { RegistrationService } from '../../services/registration.service';
import { SharedService } from '../../../service/shared.service';
import { AppSettings } from '../../../core/app-setting';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';

import { InternationalPhoneModule } from 'ng4-intl-phone';

/*import 'aws-sdk/dist/aws-sdk';
declare var AWS: any;
import 'amazon-cognito-js';*/
const AWS = require('aws-sdk');
require('amazon-cognito-js');

declare let window: any;
declare let FB: any;
declare var sessionStorage : any;
declare var localStorage : any;

export class RegistrationFacebookUser {
  name: string;
  lname: string;
  email: string;
  phonenumber: string;
  dob: string;
  gender: string;
}
export class VerifyPhoneNumber{
  verifycode: string;
  phonenumber: string;
}

@Component({
  selector: 'app-facebookregister',
  templateUrl: './facebookregister.component.html',
  styleUrls: ['./facebookregister.component.css']
})
export class FacebookregisterComponent implements OnInit {
    active_css: string;
    variablear: any;
    verify_show: boolean;
    verifyphn: number = 0;
    submit_btn_enable: boolean = true;
    confirm_code_enable: boolean = false;
    loading = false;
    verifyPhoneNumber: VerifyPhoneNumber;
    errorMessage: string;
    res: any;
    css_class: string;
    verifyval: number = 0;
    EmailField: boolean;
    fbemailid:string;
    identityidd: string;
    public actionUrl: string; 
    public headers: Headers;
    public options: RequestOptions;


    constructor(public http:Http, private sharedService: SharedService, public userService: UserLoginService, public registrationUser:RegistrationFacebookUser, 
    public registrationService:RegistrationService, public router:Router, public zone:NgZone) { 
        this.actionUrl = AppSettings.API_ENDPOINT;
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
        this.getFBValue();
        //console.log("email",this.registrationUser.email)
        if(this.registrationUser.email == '' || this.registrationUser.email == null || this.registrationUser.email == undefined){
                this.EmailField = false
        } else {            
                this.EmailField = true
        }
    }

    ngOnInit() {       
        //this.getFBValue();        
    }
    

    onSendVerifyCode(){
        
        if(this.verifyphn == 0){
            this.registrationService.RequestVerificationPhone(this.registrationUser.phonenumber).subscribe(data =>{ 
                 if(data.status.toString() === 'OK') {
                    this.verifyphn = 1;
                    this.errorMessage = null;
                    this.verify_show = true;
                   // console.log("test phone number",data);
                } else if(data.status.toString() === 'ERROR') { 
                    this.errorMessage = data.message;
                }
            },
            (err: Response) => {               
               let retrivemessage =  err.json();
                if(retrivemessage.message != '') {              
                    this.errorMessage = retrivemessage.message;
                } else {
                    this.errorMessage = 'Something happend strange... Please try again later';
                }
            });
        }
    }
    onReSendVerifyCode(){
        this.verifyphn = 0;
        if(this.verifyphn == 0){
            this.registrationService.RequestVerificationPhone(this.registrationUser.phonenumber).subscribe(data =>{ 
               
                 if(data.status.toString() === 'OK') {
                    this.verifyphn = 1;     
                    this.confirm_code_enable = false;
                    this.submit_btn_enable = true;
                    this.errorMessage = null;
                } else if(data.status.toString() === 'ERROR') { 
                    this.errorMessage = data.message;
                }
            },
            (err: Response) => {               
               let retrivemessage =  err.json();
                if(retrivemessage.message != '') {              
                    this.errorMessage = retrivemessage.message;
                } else {
                    this.errorMessage = 'Something happend strange... Please try again later';
                }
            });
        }
    }

    onKeyup(emailid){
        sessionStorage.setItem('email_id', emailid);
      //  console.log(emailid);
        if(emailid.length > 0) {
            this.active_css = 'float-lbl';
        } else {
            this.active_css = '';
        }
    }

    onKey(verifycodenumber) {     
        let verifycodee = verifycodenumber;
       
        if(this.verifyval == 0 && verifycodee.length == 6){            
          //  console.log(verifycodee);
         //   console.log('length reached five');
            this.css_class = "confirm-no";
            this.registrationService.VerifyPhoneNumber(this.registrationUser.phonenumber, verifycodenumber)  
            .subscribe((res: Response) => {               
               // console.log("phoneverify",res.status);
                let statuscode = res.status.toString();
                let msg = res;
                if(statuscode === "OK") {
                    this.verifyval = 1;                    
                    this.confirm_code_enable = true;
                    this.css_class = "confirm-code";
                    this.submit_btn_enable = false;
                    this.res = res;
                   // console.log(this.res);
                } else if(statuscode === "ERROR") { 
                    this.css_class = "confirm-no";                    
                }
            });   
        }
    }

  getFBValue(){     
    let parsedObject = JSON.parse(sessionStorage.getItem('FacebookDetails'));
    if(parsedObject == "" || parsedObject == null) {
      //  console.log("No session Found");
    }else {
        this.registrationUser.email =  parsedObject.email; 
       // this.registrationUser.gender = parsedObject.gender; 
        this.registrationUser.name =  parsedObject.first_name; 
        this.registrationUser.lname =  parsedObject.last_name;
    }
  }
  
  FaceBookRegister(){
    this.loading = true;
    let httpobj = this.http;
    let navobj = this.router;
    let navthis = this;
    let retrievedObject = sessionStorage.getItem('FacebookDetails');    
    let parsedObject = JSON.parse(retrievedObject);

    let accessToken = sessionStorage.getItem("fbAccessToken");

    AWS.config.update({
        region: CognitoUtil._REGION,
        credentials: new AWS.CognitoIdentityCredentials({
            IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID,
            Logins: {
                'graph.facebook.com': accessToken,                                       
            },
           // expired: true                                  
        })    
    });
    
    return this.http.get(this.actionUrl+'user/validate/email/' + navthis.registrationUser.email, this.options)
    .map((response: Response) => response.json())
    .subscribe((data => {
       // console.log('data--->',data)
         if(data.status.toString() === 'OK') {
                //this.router.navigate(['/auth/login']);
                //this.router.navigate(['/auth/GetStarted'], { queryParams: { returnUrl: state.url }});
                this.registrationService.mapUserwithFacebook(parsedObject.id, navthis.registrationUser.email)
                .subscribe((res)=>{
                    if(res.status.toString() === 'OK') {
                        sessionStorage.setItem('currentUserFB', JSON.stringify({userid: res.data[0].id, username: navthis.registrationUser.name,email: res.data[0].email, jwtToken: accessToken, fbid:parsedObject.id}));
                        navthis.sharedService.IsUserLoggedIn.next(true);
                        navobj.navigate(['/']);
                        window.location.href = '/';
                    } else if(res.status.toString() === 'ERROR') { 
                        navthis.errorMessage = res.message;
                    }
                })            
         } else if(data.status.toString() === 'ERROR'){
            AWS.config.credentials.get(function(err) {
                    if (err) {
                      //  console.log("Error: "+err);
                        return;
                    }
                   // console.log("Cognito Identity Id: " + AWS.config.credentials.identityId);
            
                    navthis.identityidd =  AWS.config.credentials.identityId;
            
                    let syncClient = new AWS.CognitoSyncManager();
            
                    syncClient.openOrCreateDataset('fb', function(err, dataset) { 
            
                        dataset.put('username', parsedObject.name, function(err, record){        
                            dataset.synchronize({        
                                onSuccess: function(data, newRecords) {    // Your handler code here
                                }        
                            });        
                        });
            
                        dataset.put('first_name', navthis.registrationUser.name, function(err, record){        
                            dataset.synchronize({        
                                onSuccess: function(data, newRecords) {    // Your handler code here
                                }        
                            });        
                        });
            
                        dataset.put('last_name', navthis.registrationUser.lname, function(err, record){        
                            dataset.synchronize({        
                                onSuccess: function(data, newRecords) {    // Your handler code here
                                }        
                            });        
                        });
            
                        dataset.put('id', parsedObject.id, function(err, record){        
                            dataset.synchronize({        
                                onSuccess: function(data, newRecords) {    // Your handler code here
                                }        
                            });        
                        });
            
                        if(parsedObject.email == null || parsedObject.email == '') {
                            dataset.put('email', navthis.registrationUser.email, function(err, record){        
                                dataset.synchronize({        
                                    onSuccess: function(data, newRecords) {    // Your handler code here
                                    }        
                                });        
                            });
                        } else {
                            dataset.put('email', parsedObject.email, function(err, record){        
                                dataset.synchronize({        
                                    onSuccess: function(data, newRecords) {    // Your handler code here
                                    }        
                                });        
                            });
                        }
                    
                    });
                    
                    // Other service clients will automatically use the Cognito Credentials provider
                    // configured in the JavaScript SDK.
                    let cognitoSyncClient = new AWS.CognitoSync();
                    cognitoSyncClient.listDatasets({
                        IdentityId: AWS.config.credentials.identityId,
                        IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID
                    }, function(err, data) {
                        if ( !err ) {
                           // console.log(JSON.stringify(data));
                            
                        }
                    });
            
                    let params = {
                        DatasetName: 'FB', /* required */
                        IdentityId: AWS.config.credentials.identityId, /* required */
                        IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID, /* required */
                        LastSyncCount: 0,
                        MaxResults: 10,
                        //NextToken: null,
                        //SyncSessionToken: 'STRING_VALUE'
                    };
                    cognitoSyncClient.listRecords(params, function(err, data) {
                        if (err) console.log(err, err.stack); // an error occurred
                        else     console.log(data);           // successful response
                    });
            
                    //console.log("identity",AWS.config.credentials.identityId);
                    navthis.zone.run(() => {
                        let body = JSON.stringify({ registerType: 'fb' , action: 'signup',identityId: AWS.config.credentials.identityId,fbId: parsedObject.id,firstName: navthis.registrationUser.name,
                        lastName: navthis.registrationUser.lname,email: navthis.registrationUser.email, mobile:navthis.registrationUser.phonenumber});
                       // console.log('user reg details',body);
                        httpobj.post( navthis.actionUrl+'user', body, navthis.options )
                        .map((response: Response) => response.json())                        
                        .subscribe(prmemieridgenerate => {
                            // this.sharedService.IsUserLoggedIn.next(true);
                        //  console.log('prmemieridgenerate.userId',prmemieridgenerate.userId)
                            if(prmemieridgenerate.status.toString() === 'OK') {
                                localStorage.setItem('premierId', prmemieridgenerate.premierId );
                                sessionStorage.setItem('currentUserFB', JSON.stringify({userid: prmemieridgenerate.userId, username: navthis.registrationUser.name,email:navthis.registrationUser.email, jwtToken: accessToken, fbid:parsedObject.id}));
                                navthis.sharedService.IsUserLoggedIn.next(true);
                                navobj.navigate(['/']);
                                window.location.href = '/';
                                // this.router.navigate(['/']);
                            } else if (prmemieridgenerate.status.toString() === 'ERROR') {
                                navthis.errorMessage = prmemieridgenerate.message;
                                navthis.loading = false;
                            }
                        });
                    });
                });
         }
    }),
    (error) => {
        AWS.config.credentials.get(function(err) {
            if (err) {
                //console.log("Error: "+err);
                return;
            }
            //console.log("Cognito Identity Id: " + AWS.config.credentials.identityId);
    
            navthis.identityidd =  AWS.config.credentials.identityId;
    
            let syncClient = new AWS.CognitoSyncManager();
    
            syncClient.openOrCreateDataset('fb', function(err, dataset) { 
    
                dataset.put('username', parsedObject.name, function(err, record){        
                    dataset.synchronize({        
                        onSuccess: function(data, newRecords) {    // Your handler code here
                        }        
                    });        
                });
    
                dataset.put('first_name', navthis.registrationUser.name, function(err, record){        
                    dataset.synchronize({        
                        onSuccess: function(data, newRecords) {    // Your handler code here
                        }        
                    });        
                });
    
                dataset.put('last_name', navthis.registrationUser.lname, function(err, record){        
                    dataset.synchronize({        
                        onSuccess: function(data, newRecords) {    // Your handler code here
                        }        
                    });        
                });
    
                dataset.put('id', parsedObject.id, function(err, record){        
                    dataset.synchronize({        
                        onSuccess: function(data, newRecords) {    // Your handler code here
                        }        
                    });        
                });
    
                if(parsedObject.email == null || parsedObject.email == '') {
                    dataset.put('email', navthis.registrationUser.email, function(err, record){        
                        dataset.synchronize({        
                            onSuccess: function(data, newRecords) {    // Your handler code here
                            }        
                        });        
                    });
                } else {
                    dataset.put('email', parsedObject.email, function(err, record){        
                        dataset.synchronize({        
                            onSuccess: function(data, newRecords) {    // Your handler code here
                            }        
                        });        
                    });
                }
            
            });
            
            // Other service clients will automatically use the Cognito Credentials provider
            // configured in the JavaScript SDK.
            let cognitoSyncClient = new AWS.CognitoSync();
            cognitoSyncClient.listDatasets({
                IdentityId: AWS.config.credentials.identityId,
                IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID
            }, function(err, data) {
                if ( !err ) {
                    //console.log(JSON.stringify(data));
                    
                }
            });
    
            let params = {
                DatasetName: 'FB', /* required */
                IdentityId: AWS.config.credentials.identityId, /* required */
                IdentityPoolId: CognitoUtil._IDENTITY_POOL_ID, /* required */
                LastSyncCount: 0,
                MaxResults: 10,
                //NextToken: null,
                //SyncSessionToken: 'STRING_VALUE'
            };
            cognitoSyncClient.listRecords(params, function(err, data) {
                if (err) console.log(err, err.stack); // an error occurred
                else     console.log(data);           // successful response
            });
    
           // console.log("identity",AWS.config.credentials.identityId);
             navthis.zone.run(() => {
                 let body = JSON.stringify({ registerType: 'fb' , action: 'signup',identityId: AWS.config.credentials.identityId,fbId: parsedObject.id,firstName: navthis.registrationUser.name,
                 lastName: navthis.registrationUser.lname,email: navthis.registrationUser.email, mobile:navthis.registrationUser.phonenumber});
               //  console.log('user reg details',body);
                 httpobj.post( navthis.actionUrl+'user', body, navthis.options )
                 .map((response: Response) => response.json())
                 .subscribe(prmemieridgenerate => {
                    // this.sharedService.IsUserLoggedIn.next(true);
                    //  console.log('prmemieridgenerate.userId',prmemieridgenerate.userId)
                    if(prmemieridgenerate.status.toString() === 'OK') {
                        localStorage.setItem('premierId', prmemieridgenerate.premierId );
                        sessionStorage.setItem('currentUserFB', JSON.stringify({userid: prmemieridgenerate.userId, username: navthis.registrationUser.name,email:navthis.registrationUser.email, jwtToken: accessToken, fbid:parsedObject.id}));
                        navthis.sharedService.IsUserLoggedIn.next(true);
                        navobj.navigate(['/']);
                        window.location.href = '/';
                        // this.router.navigate(['/']);
                    } else if (prmemieridgenerate.status.toString() === 'ERROR') {
                        navthis.errorMessage = prmemieridgenerate.message;
                        navthis.loading = false;
                    }
                });
             });
        });
    })

  }

}
