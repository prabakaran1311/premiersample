import {Component, OnInit} from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import {UserLoginService} from "../../../service/user-login.service";
import {CognitoCallback, LoggedInCallback, CognitoUtil} from "../../../service/cognito.service";
import { Meta, Title } from "@angular/platform-browser";
import { Http, Headers, Response, RequestOptions  } from "@angular/http";
import { SharedService } from '../../../service/shared.service';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';


import 'aws-sdk/dist/aws-sdk';
declare const AWS: any;
import 'amazon-cognito-js';

declare let window: any;
declare let FB: any;
declare var sessionStorage : any;
declare var localStorage : any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements CognitoCallback, OnInit {
    sub: any;
    email: string;
    password: string;
    errorMessage: string;
    public is_login:Boolean = false;
    Remember: Boolean = false;
    loading = false;
    returnUrl: string;

    constructor(public router: Router,
                public userService: UserLoginService, meta: Meta, title: Title, private http: Http,  public route: ActivatedRoute, private sharedService: SharedService) {
       // console.log("LoginComponent constructor");

        title.setTitle('PremierX Login ');
        
        meta.addTags([ 
            { name: 'author',   content: 'Login page author'},
            { name: 'keywords', content: 'PremierX login page test keyword'},
            { name: 'description', content: 'PremierX login page test description' }
        ]);
        // This function initializes the FB variable

        let currentUserRemember = JSON.parse(sessionStorage.getItem('currentUser'));

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

        if( currentUserRemember != null) {
           // console.log("test currentuser",currentUserRemember.jwtToken);
            if ( currentUserRemember && currentUserRemember.jwtToken) {
                sessionStorage.setItem('currentUser', JSON.stringify({ currentUserRemember }));
                this.router.navigate([this.returnUrl])
            } else {
                //return false
            }
        }
                     
    }    

    ngOnInit() {
        this.email = sessionStorage.getItem('email_id');
        if (this.email == null) {
            this.router.navigate(['/auth/GetStarted'])
        }
        this.errorMessage = null;
       // console.log("Checking if the user is already authenticated. If so, then redirect to the secure site");
       // this.userService.isAuthenticated(this);
        this.userloggedincheck();
    }

    GetStarted(){
        //window.location.href= "/auth/GetStarted";
        this.router.navigate(['/auth/GetStarted']);
    }

    onLogin() {
        this.loading = true;
        if (this.email == null || this.password == null) {
            this.errorMessage = "All fields are required";
            this.loading = false;
            return;
        }
        this.errorMessage = null;
        this.userService.authenticate(this.email, this.password, this, this.Remember);
    }

    cognitoCallback(message: string, result: any) {
       // console.log('messageee',message);
        if (message != null) { //error
            this.errorMessage = message;
            this.loading = false;
           // console.log("result: " + this.errorMessage);
            if (this.errorMessage === 'User is not confirmed.') {
               // console.log("redirecting");
                this.router.navigate(['/auth/confirmRegistration', this.email]);
            } else if (this.errorMessage === 'User needs to set password.') {
                //console.log("redirecting to set new password");
                this.router.navigate(['/auth/newPassword']);
            }
        } else { //success
            //this.ddb.writeLogEntry("login");
            this.is_login = true;
            this.router.navigate([this.returnUrl]);
            window.location.href = this.returnUrl;
 

        }
    }

    /*isLoggedIn(message: string, isLoggedIn: boolean) {
        if (isLoggedIn)
           // this.router.navigate(['/']);
            window.location.href = '/';
    }*/

    private handleError(error: any) {
        
    }

    userloggedincheck(){
        let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
        let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

        if(currentUserFB != null || currentUser != null) {
           // console.log("test currentuser",currentUser.jwtToken);
            if (currentUserFB && currentUserFB.jwtToken || currentUser && currentUser.jwtToken) {
                this.router.navigate([this.returnUrl])
            } else {
               //return false
            }
        }
    }
}