import {Component, OnDestroy, OnInit} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {UserLoginService} from "../../../service/user-login.service";
import {CognitoCallback} from "../../../service/cognito.service";

@Component({
    selector: '',
    templateUrl: './forgotPassword.html', 
    styleUrls: ['./forgotPassword.component.css']
})
export class ForgotPasswordStep1Component implements CognitoCallback {
    email: string;
    errorMessage: string;
    loading:boolean = false;

    constructor(public router: Router,
                public userService: UserLoginService) {
        this.errorMessage = null;
    }

    onNext() {
        this.errorMessage = null;
        this.userService.forgotPassword(this.email, this);
    }

    cognitoCallback(message: string, result: any) {
        if (message == null && result == null) { //error
            this.router.navigate(['/auth/forgotPassword', this.email]);
        } else { //success
            this.errorMessage = message;
            if(message === 'Cannot reset password for the user as there is no registered/verified email or phone_number') {
                this.router.navigate(['/auth/confirmRegistration', this.email]);
            }
        }
    }
}


@Component({
    selector: 'awscognito-angular2-app',
    templateUrl: './forgotPasswordStep2.html'
})
export class ForgotPassword2Component implements CognitoCallback, OnInit, OnDestroy {
    codeVerified: boolean = false;
    verificationCode: string;
    email: string;
    password: string;
    
    errorMessage: string;
    private sub: any;
    loading:boolean = false;

    constructor(public router: Router, public route: ActivatedRoute,
                public userService: UserLoginService) {
        //console.log("email from the url: " + this.email);
    }

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.email = params['email'];

        });
        this.errorMessage = null;
    }

    Login(){
        this.router.navigate(['/auth/Login']);
    }

    onCheckCode(code){
        if(code.length === 6) {
            this.codeVerified = true;
        } else if(code.length < 6) { 
            this.codeVerified = false;
        } else { 
            this.codeVerified = false;
        }
    }

    ngOnDestroy() {
        this.sub.unsubscribe();
    }

    onNext() {
        this.errorMessage = null;
        this.userService.confirmNewPassword(this.email, this.verificationCode, this.password, this);
    }

    cognitoCallback(message: string) {
        if (message != null) { //error
            this.errorMessage = message;
           // console.log("result: " + this.errorMessage);
        } else { //success
            this.router.navigate(['/auth/login']);
        }
    }

}