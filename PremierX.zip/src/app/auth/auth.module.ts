import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InternationalPhoneModule } from 'ng4-intl-phone';

import { AuthRoutingModule } from './auth-routing.module';

import { AUTH_COMPONENTS } from './components';

@NgModule({
  imports: [
    CommonModule,
    AuthRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    InternationalPhoneModule
  ],
  declarations: [
    ...AUTH_COMPONENTS
  ]
})
export class AuthModule { }
