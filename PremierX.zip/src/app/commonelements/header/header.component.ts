import { Component, OnInit, AfterViewInit, Output, EventEmitter, NgZone, OnChanges, ChangeDetectionStrategy  } from '@angular/core';
import { SharedService } from "../../service/shared.service";
import { Router} from "@angular/router";
import { AppComponent } from '../../app.component';
import { UserLoginService} from "../../service/user-login.service";
import { RegistrationService } from '../../auth/services/registration.service';
import { Subject, Observable } from "rxjs";
import * as AWS from "aws-sdk";
import { CreateEventService } from "../../service/create-event.service";
import { environment } from "../../../environments/environment";
import { Elasticsearch } from '../../service/elasticsearch.service';
import { Http, Headers, Response, RequestOptions } from "@angular/http";
import {
  FormGroup,
  FormControl,
  FormControlName,
  FormsModule,
  NgModel
} from "@angular/forms";

import { AppSettings } from '../../core/app-setting';

declare var jQuery: any;
declare const FB: any;
declare var sessionStorage : any;
declare var localStorage : any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  providers: [NgModel]
})

export class HeaderComponent implements AfterViewInit, OnInit {
  
  errmsg: boolean = false;
  userIdCreateEvent: any;
  model: any = [];
  res: any;
  userID: any;
  loggeduserdata: any;
  eventtypeID: any;
  lang: any = [];
  showtextbox: boolean = true;
  errorMessage: string;
  fullImagePath: string;
  isUserLoggedIn: boolean = false; 
  is_login: boolean = false;
  data: any;
  showEmailvalid: boolean = true;
  successMessage: boolean = false;
  mailidconfirm: string;
  fblogoutbtn: boolean;
  username: string;
  resendemailverify:boolean = false;
  changeEmailID: string;
  css_class: string;
  Email_change: boolean = false;
  successsMessage: string;
  email_fields: boolean = true; 
  loading = false;
  language: boolean = false;

  languages = [
    { name: 'English', value: 1, checked: true, disable: true },
    { name: 'Arabic', value: 2, checked: false, disable: false }
  ];

  eventtype = [
    { name: 'Requires user registration', value: 1 },
    { name: 'Ticket sales', value: 2 }
  ];

  // Elastic Search 
  @Output()
  found: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();
  @Output()
  selected: EventEmitter<any> = new EventEmitter<any>();

  seachTextModel: string;
  results$: Subject<Array<any>> = new Subject<Array<any>>();
  message: string = "";
  active: boolean = false;
  seachText: FormControl = new FormControl("");

  //API CALL
  public actionUrl: string;
  public headers: Headers;
  public options: RequestOptions;

  constructor(public sharedService: SharedService, public router: Router, public AppComponent: AppComponent, public registrationService: RegistrationService,
    public es: Elasticsearch, private _ngZone: NgZone, public auth: UserLoginService, public http: Http, public CreateEventService: CreateEventService) {
    //API 
    this.actionUrl = AppSettings.API_ENDPOINT;
    this.headers = new Headers({ 'Content-Type': 'application/json' });
    this.options = new RequestOptions({ headers: this.headers });


    this.fullImagePath = 'assets/img/logo.png';
    this.getUserdetails();   
    this.sharedService.IsUserLoggedIn.subscribe( value => {
      this.isUserLoggedIn = value;         
    }); 
    this.sharedService.is_login.subscribe( value => {
      this.is_login = value;         
    });      
    let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));    
    if(currentUser != null) {
      this.username = currentUser.username;   
      this.userIdCreateEvent = currentUser.userid;
    }

    let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
    if(currentUserFB != null) {
      this.username = currentUserFB.username;   
      this.userIdCreateEvent = currentUserFB.userid;
    }      
 }
 
 en(){
   this.AppComponent.changeLanguage("en")
 }

  ar(){
   this.AppComponent.changeLanguage("ar")
 }

  ngOnInit() {  
    this.getUserdetails();
    this.checklogin(); 
    this.emailVerifiedstatus();
    /*let emailtest = sessionStorage.getItem('updateemail');
    if(emailtest != null) {
      let emailver = emailtest.toString();
      if( emailver == 'true' ) {
        this.Email_change = true;
      }
    }*/
  }

  emailVerifiedstatus(){
    let emailVerify = JSON.parse(sessionStorage.getItem('currentUser'));    
    if(emailVerify != null) {
      let emailVerified = emailVerify.emailVerified;
      if(emailVerified === true){
        this.Email_change = true;
      }
    }
  }

  private checklogin(){
    let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
    let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    
    if(currentUserFB != null) {
     // console.log("test currentuser",currentUserFB.jwtToken);
      if (currentUserFB && currentUserFB.jwtToken) {
        this.sharedService.IsUserLoggedIn.next(true); 
      } else {
        this.sharedService.IsUserLoggedIn.next(false); 
      }
    } else if(currentUser != null){
      if (currentUser && currentUser.jwtToken) {
        this.sharedService.is_login.next(true); 
      } else {
        this.sharedService.is_login.next(false); 
      }
    }
  }

  fblogoutbutton(){
    this.sharedService.IsUserLoggedIn.next(false); 
      this.router.navigate(['/']);  
      sessionStorage.clear();
      localStorage.clear();
  }

  logout(){
    this.router.navigate(['/auth/logout']);
    this.sharedService.is_login.next(false); 
  }

  onKey(verifyemail) {     
    let verifycodee = verifyemail;
    let email = sessionStorage.getItem('email_id');
    this.css_class = "confirm-noo";

    if(verifycodee.length == 6){   
      this.registrationService.VerifyEmailAddress(email, verifycodee) 
      .subscribe((res) => {
        this.data = res
        //console.log(res);
        if(res.status.toString() === 'OK') {
          this.css_class = "confirm-codee";
          this.showEmailvalid = false;
          this.successMessage = true;
          this.AdminUpdateEmailStatus();
        } else if (res.status.toString() === 'ERROR'){
          this.errorMessage = res.message;
        }
      })
     // console.log('verifyemail', verifycodee);
    }  
  }

  resendVerifyEmail(){
    let email = sessionStorage.getItem('email_id');
    this.registrationService.RequestVerificationEmail(email).subscribe(()=>{ this.resendemailverify = true; this.Email_change = false; })
  }

  GetStarted() {
   // window.location.href = "/auth/GetStarted";
    this.router.navigate(['/auth/GetStarted']);
  }
  // Update Email Status to true
  
  AdminUpdateEmailStatus(){

    let email = sessionStorage.getItem('email_id');

    AWS.config.update({
      accessKeyId: "AKIAJDPMAZUJXANJEJSQ",
      secretAccessKey: "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",
      region: 'eu-central-1' // change region if required
    });   

    let cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

    let params = {
      UserAttributes: [ /* required */
        {
          Name: 'email_verified', /* required */
          Value: 'true'
        },
      ],
      UserPoolId: environment.userPoolId, /* required */
      Username: email /* required */
    };
    var headerClassObj = this;
    cognitoidentityserviceprovider.adminUpdateUserAttributes(params, function(err, data) {
      if (err) { 
        console.log(err, err.stack); // an error occurred
      }else {     
        //console.log(data);    
        headerClassObj.mailidconfirm = 'true';       // successful response
        headerClassObj.getUserdetails();
      }
    });
  }

  isDisabled() {
      return true;
  }

  onKeyUp(emailverify){
    let verifycodee = emailverify;
    let email = sessionStorage.getItem('email_id');
    this.css_class = "confirm-noo";

    let Accesstokenjson = JSON.parse(sessionStorage.getItem('currentUser'));
    let accessToken = Accesstokenjson.jwtToken;  
    let UserID = Accesstokenjson.userid;

      
    let navobj = this;

    AWS.config.update({
      accessKeyId: "AKIAJDPMAZUJXANJEJSQ",
      secretAccessKey: "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",
      region: 'eu-central-1' // change region if required
    });   

    let cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

    if(verifycodee.length == 6){   
      let params = {
        AccessToken: accessToken, /* required */
        AttributeName: 'email', /* required */
        Code: verifycodee /* required */
      };
      cognitoidentityserviceprovider.verifyUserAttribute(params, function(err, data) {
        if (err) {
           console.log(err, err.stack); // an error occurred
        } else {
           navobj.css_class = "confirm-codee";
           navobj.showEmailvalid = false;
           navobj.successMessage = true;
           navobj.registrationService.updateEmailStauts(UserID, email).subscribe();
           navobj.getUserdetails();
           navobj.AdminUpdateEmailStatus();           
        }
      });
    }  
  }

  getUserdetails(){   
    var userMailIdConfirm = this.mailidconfirm;
    let email = sessionStorage.getItem('email_id');

    AWS.config.update({
      accessKeyId: "AKIAJDPMAZUJXANJEJSQ",
      secretAccessKey: "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",
      region: 'eu-central-1' // change region if required
    });   
 
    let cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();
    
    let params = {
        UserPoolId: environment.userPoolId, /* required */
        Username: email /* required */
    };
    //this.mailidconfirm = 'testing';
    var headerClassObj = this;
    cognitoidentityserviceprovider.adminGetUser(params, function(err, data) {
      if (err) {
        // console.log(err, err.stack);    // an error occurred
      }
      else {
        headerClassObj.mailidconfirm = data.UserAttributes[1].Value;
        //console.log(data)
        headerClassObj.loggeduserdata = data;
        // headerClassObj.isUserLoggedIn = true;
      }
    });    
  }
 
  UpdateEmailId(){
    AWS.config.update({
        accessKeyId: "AKIAJDPMAZUJXANJEJSQ",
        secretAccessKey: "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",
        region: 'eu-central-1' // change region if required
    });   

    let cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();    
    let Accesstokenjson = JSON.parse(sessionStorage.getItem('currentUser'));
    let accessToken = Accesstokenjson.jwtToken;
    let email = sessionStorage.getItem('email_id');
    let navobj = this;
    this.loading = true;
    
    //console.log(this.changeEmailID);
    let userdetail = JSON.parse(sessionStorage.getItem('currentUser'));    
    let UserID = userdetail.userid;
   // console.log(UserID);
    this.registrationService.ChangeEmailID(UserID, this.changeEmailID )
    .subscribe((res) =>{
     // console.log(res);
      if(res.status.toString() === 'OK'){
       // console.log(accessToken);      
        let params = {
            AccessToken: accessToken, /* required */
            UserAttributes: [ /* required */
                {
                    Name: 'email', /* required */
                    Value: navobj.changeEmailID
                },
                /* more items */
            ]
        };
        cognitoidentityserviceprovider.updateUserAttributes(params, function(err, data) {
            if (err) { 
               console.log('error',err, err.stack);
            }else {     
              navobj.errorMessage = '';
                navobj.successsMessage = 'Email id changed Successfully';
                //this.Email_change = true;
                navobj.email_fields = false;
                navobj.router.navigate(['/']);     // successful response
                window.location.href = '/';
                sessionStorage.clear();
                localStorage.clear();                                                 
            }
        });        
      } else if(res.status.toString() === 'ERROR') {
        this.errorMessage = res.message
      }      
    },

    (err: any) => {     
      if(err.message != '') {
         this.errorMessage = err.message
      } else {
        this.errorMessage = "Something happend Strange... Please Try again";
      }
     // console.log(err);
      this.loading = false;
    })    
  }

  ngAfterViewInit() {
      this.seachText
          .valueChanges
          .map((ẗext: any) => ẗext ? ẗext.trim() : "")                                             // ignore spaces         
          .do(searchString => searchString ? this.message = "searching..." : this.message = "")
          .debounceTime(500)                                                                      // wait when input completed
          .distinctUntilChanged()
          .switchMap(searchString => {
              return new Promise<Array<any>>((resolve, reject) => {
                  this._ngZone.runOutsideAngular(() => {                                          // perform search operation outside of angular boundaries
                      this.es.search(searchString)
                          .then((searchResult) => {
                              this._ngZone.run(() => {
                                  let results: Array<any> = ((searchResult.hits || {}).hits || [])// extract results from elastic response
                                      .map((hit) => hit._source);
                                  if (results.length > 0) {
                                      this.message = "";
                                  }
                                  else {
                                      if (this.seachTextModel && this.seachTextModel.trim())
                                          this.message = "nothing was found";
                                  }
                                  resolve(results);
                              });
                          })
                          .catch((error) => {
                              this._ngZone.run(() => {
                                  reject(error);
                              });
                          });
                  });
              });
          })
          .catch(this.handleError)
          .subscribe(this.results$);
  }

  resutSelected(result) {
    this.selected.next(result);
  }

  handleError(): any {
    this.message = "something went wrong";
  }

  changebool(){
    this.showtextbox = false;
  }
  
  //EVENT CREATE 
  updateCheckedOptions(value, event) {
    if (event.target.checked) {
      this.lang.push(value);
    }
    else if (!event.target.checked) {
      let indexx = this.lang.indexOf(value);
      this.lang.splice(indexx, 1);
    }
  }

  updateradiovalue(value, event) {
    this.eventtypeID = value;
  }
  
  logincheck() {
    sessionStorage.setItem('langID','');
    sessionStorage.setItem('eventid', '');
    let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
    let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

    if (currentUserFB != null || currentUser != null) {
      jQuery("#createeventmodal").modal("show");      
      this.lang.push(1);
    }
    else {
      
      this.router.navigate(['/eventcreation/eventInformation']);
    }
  }

  getuserID(sub: any) {
    return this.http.get(this.actionUrl + 'user/validate/sub/' + sub).map((response: Response) => response.json())
  }

  createeve() {
    //console.log('this.loggeduserdata',this.loggeduserdata)
    this.getuserID(this.loggeduserdata.Username).subscribe(lang => {
      this.model = lang.data[0].id;
      this.savevalues(this.model);
    });
  }

  savevalues(value: any) {
    let langID;

    sessionStorage.setItem('langID',JSON.stringify(this.lang));

    for (let i = 0; i < this.lang.length; i++) {
      if (i == 0) {
        langID = this.lang[i];
      }
      else {
        langID = langID + "," + this.lang[i];
      }
    }
    
    if(this.eventtypeID == null || this.eventtypeID == ""){
      this.errmsg = true;
    }
    else{      
      this.errmsg = false;
    let body = JSON.stringify({ "createdBy": this.userIdCreateEvent, "siteId": 1, "type": this.eventtypeID, "languages": this.lang });
    
    console.clear();
    console.log(body);
     this.CreateEventService.GenerateEventID(body) .subscribe(
       data => {
          // console.log('data-->',data);
          // console.log('data-->',data.statusCode);                 
       jQuery("#createeventmodal").modal("hide");
       },
       error => {
         alert('PLease try again'); 
       });
    }

  }
}