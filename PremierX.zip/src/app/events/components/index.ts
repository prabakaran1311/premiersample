
import { EventDetailsComponent } from './event-details/event-details.component';
import { EventSearchComponent } from './event-search/event-search.component';

export const EVENTS_COMPONENTS = [  
  EventDetailsComponent,
  EventSearchComponent
];

export const EVENTS_ROUTES = [
  { path: 'EventDetails/:id', component: EventDetailsComponent },
  { path: 'searchEvents', component: EventSearchComponent },
];
