import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";

import { EventsService } from '../../services/events.service';
import {OwlCarousel} from 'ng2-owl-carousel';

import {Location} from '@angular/common';

 
import { DatePipe } from '@angular/common';

declare var jQuery: any;
@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent implements OnInit {
  showOnMap: boolean = false;
  @ViewChild('owlElement') owlElement: OwlCarousel;
  eventId:string;
  eventResult: any = [];
  en:any;
  langId: number = 2;
  web: number = 1;
  preview: boolean = false;
  Facebook: boolean = false;
  twitter: boolean = false;
  instgram: boolean = false;
  linkedin: boolean = false;
  youtube: boolean = false;
  snapchat:boolean = false;
  eventList: any;
  imagess: any;
  useride: any = [];
  emptyValue = null;
  faqQuestions: string;
  faqAnswer: string;
  faqList: any = [];
  socialIcons:boolean;
  event_img: string;

  constructor(public Router: Router, public eventsService:EventsService, private route: ActivatedRoute, private _location: Location) {
    this.socialIcons = false;
    let currentUserFB = JSON.parse(sessionStorage.getItem('currentUserFB'));
    let currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    if( currentUser != null) {
      this.useride = currentUser;
    } else if(currentUserFB != null) {
      this.useride = currentUserFB;
    }
    this.getFaqQuestions();
    this.event_img = 'assets/img/event-bg.jpg';
    this.imagess = [
      { name: 'assets/img/event01.png' },
      { name: 'assets/img/event02.png' },
      { name: 'assets/img/event03.png' },
      { name: 'assets/img/event04.png' },
      { name: 'assets/img/event05.png' },
      { name: 'assets/img/event06.png' },
      { name: 'assets/img/event01.png' },
      { name: 'assets/img/event02.png' },
      { name: 'assets/img/event03.png' },
      { name: 'assets/img/event03.png' },
      { name: 'assets/img/event04.png' },
      { name: 'assets/img/event05.png' },
    ];

   

  }
  


  fun() {
    this.owlElement.next([200]);
    // duration 200ms
  }

  ngOnInit() {

    if(sessionStorage.getItem('preview') == 'false')
    {      
      this.preview = false;
    }
    else{
      this.preview = true;
    }

    this.route.paramMap.subscribe(params => {
      this.eventId = params.get('id');
    });
    this.getEventDetail();
    this.getParticipantEvents();
    window.scrollTo(0, 0);

    jQuery('[data-toggle="popover"]').popover({
      container: '.col-md-3',
      html: true,
      content: function () {
        var clone = jQuery(jQuery(this).data('popover-content')).clone(true).removeClass('hide');
        return clone;
      }
    }).click(function (e) {});

  }  

  oncheckloggedin() {
    this.Router.navigate(['/eventregister/regtype/'+ this.eventId]);
  }
  
  oncheckticket() {
    this.Router.navigate(['/eventregister/ITicketList/'+ this.eventId]);
  }

  getEventDetail(){
   // console.log('this.eventId',this.eventId)
    this.eventsService.getEventById(this.eventId)
    .subscribe((res)=>{      
      if(res.status === 'OK') {
        this.eventResult = res.data;
        if(this.eventResult.socialLinks.facebook != '' && this.eventResult.socialLinks.facebook != undefined){
          this.Facebook = true;
        }
        if(this.eventResult.socialLinks.twitter != '' && this.eventResult.socialLinks.twitter != undefined){
          this.twitter = true;
        }
        if(this.eventResult.socialLinks.instagram != '' && this.eventResult.socialLinks.instagram != undefined){
          this.instgram = true;
        }
        if(this.eventResult.socialLinks.youtube != '' && this.eventResult.socialLinks.youtube != undefined){
          this.youtube = true;
        }
        if(this.eventResult.socialLinks.snapchat != '' && this.eventResult.socialLinks.snapchat != undefined){
          this.snapchat = true;
        }
        if(this.eventResult.socialLinks.linkedin != '' && this.eventResult.socialLinks.linkedin != undefined){
          this.linkedin = true;
        }
        if(this.eventResult.showOnMap === 1){
          this.showOnMap = true;
        }
        console.log(this.eventResult);
        console.log('this.eventResult.socialLinks.facebook',this.eventResult.socialLinks.facebook)
      }
    
    })
  }

  formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
  }

  showSharingbtn(){
    this.socialIcons = !this.socialIcons;
  } 

  backtocreate(){    
    sessionStorage.setItem('preview','false');
    this._location.back();    
  }

  getParticipantEvents() {
    this.eventsService.getParticipantsList(this.eventId, this.useride.userid)
    .subscribe((res) => {
      if(res.status === 'OK') {
        console.log('just => ',res.data);
        this.eventList = res.data;
      }
    });
  }

  getFaqQuestions(){
    this.eventsService.getFaqList().subscribe((res)=>{
      if(res.status === 'OK') {
        this.faqList = res.data;
      }
    })
  }

}
