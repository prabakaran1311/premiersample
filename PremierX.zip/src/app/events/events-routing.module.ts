import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EVENTS_ROUTES } from './components';

const EventsRoutes: Routes = [...EVENTS_ROUTES];

@NgModule({
  imports: [RouterModule.forChild(EventsRoutes)],
  exports: [RouterModule]
})
export class EventsRoutingModule { }
