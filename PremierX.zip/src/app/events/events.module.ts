import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { EventsRoutingModule } from './events-routing.module';
import { OwlModule } from 'ng2-owl-carousel';
import { ShareButtonsModule } from 'ngx-sharebuttons';
import { EVENTS_COMPONENTS } from './components';

@NgModule({
  imports: [
    CommonModule,
    EventsRoutingModule,
    FormsModule,
    OwlModule,
    ShareButtonsModule,
    ReactiveFormsModule
  ],
  declarations: [
    ...EVENTS_COMPONENTS
  ]
})
export class EventsModule { }
