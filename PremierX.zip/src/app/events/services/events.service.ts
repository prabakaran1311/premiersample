import { Component, OnInit, Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions  } from "@angular/http";

import {Router} from "@angular/router";

import { AppSettings } from './../../core/app-setting';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';

@Injectable()
export class EventsService {
    options: RequestOptions;
    headers: Headers;
    actionUrl: string;

    constructor(public http:Http){
        this.actionUrl = AppSettings.API_ENDPOINT;
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
    }


    getAllEvents(): Observable<any>{
        return this.http.get(this.actionUrl+'event')
        .map((response: Response) => response.json())
        .catch((err)=>{
            return Observable.throw(err);
        })
    }

    getEventById(eventid){
        return this.http.get(this.actionUrl+'event/event-info/'+eventid)
        .map((response:Response) => response.json())
        .catch((err)=> { return Observable.throw(err) })
    }

    getParticipantsList(eventid, userid): Observable<any> {
        return this.http.get(this.actionUrl + 'event/participant-event/' + eventid + '/' + userid)
        .map((resp: Response) => resp.json())
        .catch((err) => {
            return Observable.throw(err);
        });
    }

    getFaqList() {    
        return this.http.get(this.actionUrl + "faq/list")
        .map((response: Response) => response.json())
        .catch((err) => {
            return Observable.throw(err);
        });
    }

    getEventListBasedonLocation(lat, lng){        
        let body = ({lat: lat, lang:lng});
        return this.http.post(this.actionUrl+'event/event-list',body, this.options)
        .map((response:Response)=> response.json())
        .catch((err) => {
            return Observable.throw(err);
        });
    }
}