import { ReflectiveInjector } from '@angular/core';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import {Http, Headers, HttpModule} from "@angular/http";

const providers = (<any>HttpModule).decorators[0].args[0].providers;
const injector = ReflectiveInjector.resolveAndCreate(providers);
const http = injector.get(Http);

@Injectable()
export class AppConfigService {
	public _http;
	constructor(){ }

	getConfig(){

		const providers = (<any>HttpModule).decorators[0].args[0].providers;
		const injector = ReflectiveInjector.resolveAndCreate(providers);
		const http = injector.get(Http);
		console.log("Test");
		console.log(http);

		let url = './assets/config.json';	

		return http.get(url)
	    .map((res:Response)=> {
	      console.log(res.json());
	    })
	    .catch((error:any) => Observable.throw(error.json().error || 'Server error'));		
	}
}
