import { RegistrationFacebookUser } from '../auth/components/facebookregister/facebookregister.component';
import { RegistrationService } from '../auth/services/registration.service';
import { AuthGuard } from '../auth/services/auth.guard';
import {UserRegistrationService} from "../service/user-registration.service";
import {UserParametersService} from "../service/user-parameters.service";
import {UserLoginService} from "../service/user-login.service";
import {CognitoUtil} from "../service/cognito.service";
import {AwsUtil} from "../service/aws.service";
import { SharedService } from "../service/shared.service";
import { Elasticsearch } from '../service/elasticsearch.service';
import { CreateEventService } from '../service/create-event.service';
import { EventsService } from '../events/services/events.service';
import { EventRegistrationService } from '../eventreg/service/eventregistration.service';
import { userProfileService } from '../user/service/user.service';

export const ALL_SERVICES = [
    AuthGuard,	
	RegistrationService,
	RegistrationFacebookUser,
    CognitoUtil,
    AwsUtil,
    UserRegistrationService, 
    UserLoginService,
    UserParametersService,
    RegistrationService,
    Elasticsearch,
    SharedService,
    EventsService,
    EventRegistrationService,
    CreateEventService,
    userProfileService
];
