export class AppSettings {
    // public static API_ENDPOINT:string = "https://gpqh06ss49.execute-api.eu-central-1.amazonaws.com/dev/";
    public static API_ENDPOINT:string = "http://192.168.2.130:4000/";
}
