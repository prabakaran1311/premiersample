export const environment = {
      production: true,
  
      region: 'eu-central-1',
  
     /* identityPoolId: 'eu-central-1:6a7886ae-b525-4a85-94f6-589e49c24eb6',
      userPoolId: 'eu-central-1_ez3upGtKp',
      clientId: '59kpta226ap1b2hdl1spavre3l',*/

      identityPoolId: 'eu-central-1:138a1577-4701-43b8-be3c-a68b993a89dc',
      userPoolId: 'eu-central-1_WjYr5juQZ',
      clientId: '29r7jrpf7grp1hcllskjuola7c',
  
      rekognitionBucket: 'rekognition-pics',
      albumName: "usercontent",
      bucketRegion: 'eu-central-1',
  
    //  ddbTableName: 'LoginTrail',result
  
      cognito_idp_endpoint: '',
      cognito_identity_endpoint: '',
      sts_endpoint: '',
    //  dynamodb_endpoint: '',
      s3_endpoint: ''
};
