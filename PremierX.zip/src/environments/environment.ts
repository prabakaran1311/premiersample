// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
      production: false,
  
      region: 'eu-central-1',
  
     /* identityPoolId: 'eu-central-1:6a7886ae-b525-4a85-94f6-589e49c24eb6',
      userPoolId: 'eu-central-1_ez3upGtKp',
      clientId: '59kpta226ap1b2hdl1spavre3l',*/

      identityPoolId: 'eu-central-1:138a1577-4701-43b8-be3c-a68b993a89dc',
      userPoolId: 'eu-central-1_WjYr5juQZ',
      clientId: '29r7jrpf7grp1hcllskjuola7c',
  
      rekognitionBucket: 'rekognition-pics',
      albumName: "usercontent",
      bucketRegion: 'eu-central-1',
  
      apiURL : 'https://urpfbw06yc.execute-api.eu-central-1.amazonaws.com/Dev',
  
     // ddbTableName: 'LoginTrail',
  
      cognito_idp_endpoint: '',
      cognito_identity_endpoint: '',
      sts_endpoint: '',
    //  dynamodb_endpoint: '',
      s3_endpoint: ''
};
