
$(function() {
  var body = $('.banner-main');
  var backgrounds = ['url(assets/img/banner_1.jpg) center center / cover no-repeat fixed', 'url(assets/img/banner_2.jpg) center center / cover no-repeat fixed', 'url(assets/img/banner_3.jpg) center center / cover no-repeat fixed'];
var current = 0;

function nextBackground() {
  body.css(
   'background',
    backgrounds[current = ++current % backgrounds.length]
 );

 setTimeout(nextBackground, 5000);
 }
 setTimeout(nextBackground, 5000);
   body.css('background', backgrounds[0]  );
   body.css('-webkit-background-size', 'cover'  );
   body.css('-moz-background-size', 'cover'  );
   body.css('-o-background-size', 'cover'  );
   body.css('background-size', 'cover'  );
 });

